#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Linux ISO Auto-Updater & Ventoy Sync Tool (Linux Edition)
Version: 2.6.0

Funktionen:
1. Prüft & lädt neueste Linux ISOs herunter, verifiziert SHA256/SHA512/MD5-Hashes & archiviert veraltete Dateien.
2. Ermöglicht interaktive Gruppenauswahl (Desktop, Server, Security, Rescue, BSD) mit Mehrfachwahl.
3. Erkennt Ventoy-Wechseldatenträger, berechnet vorab den Speicherbedarf, synchronisiert ISOs mit Live-Fortschritt
   und richtet 1080p Themes inklusive Dir-/TreeView-Modus ein.
4. Optionale automatisierte Ventoy CLI-Installation auf Ziel-Laufwerke.
"""

import argparse
import bz2
try:
    import fcntl
except ImportError:
    fcntl = None
import hashlib
import json
import os
import re
import shutil
import subprocess
import sys
import tempfile
import time
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple
from urllib.parse import urljoin

try:
    import requests
except ImportError:
    print("[FEHLER] Das Python-Paket 'requests' ist nicht installiert.")
    print("Bitte führe './update-linux-isos.sh' aus oder installiere es via 'pip install requests Pillow'.")
    sys.exit(1)

try:
    from PIL import Image, ImageDraw
except ImportError:
    print("[FEHLER] Das Python-Paket 'Pillow' ist nicht installiert.")
    print("Bitte führe './update-linux-isos.sh' aus oder installiere es via 'pip install requests Pillow'.")
    sys.exit(1)

# ==============================================================================
# GLOBALE KONSTANTEN
# ==============================================================================
SCRIPT_VERSION = "2.6.0"
DEFAULT_LOG_FILE = "update-linux-isos.log"
DEFAULT_LOCK_FILE = "/tmp/linux_iso_auto_updater.lock"
USER_AGENT = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36"
CURL_USER_AGENT = "curl/8.4.0"

CATEGORY_ORDER = [
    "01_Desktop-Linux",
    "02_Enterprise-Server",
    "03_Security-Pentest",
    "04_Rescue-Systeme",
    "05_BSD-Unix",
    "06_Windows-PE_Rescue",
]


class Colors:
    """ANSI Escape Codes für farbige Terminalausgaben."""
    RESET = "\033[0m"
    BOLD = "\033[1m"
    DIM = "\033[2m"
    RED = "\033[91m"
    GREEN = "\033[92m"
    YELLOW = "\033[93m"
    BLUE = "\033[94m"
    MAGENTA = "\033[95m"
    CYAN = "\033[96m"
    WHITE = "\033[97m"
    DARK_GRAY = "\033[90m"


class Logger:
    """Thread-/Prozess-sicheres Logging mit Konsole und Logdatei."""

    def __init__(self, log_path: Path):
        self.log_path = log_path

    def _write_file(self, formatted: str) -> None:
        try:
            with open(self.log_path, "a", encoding="utf-8") as f:
                f.write(formatted + "\n")
        except Exception:
            pass

    def log(self, message: str, color: str = Colors.WHITE, level: str = "INFO") -> None:
        timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        formatted = f"[{timestamp}] [{level}] {message}"
        print(f"{color}{formatted}{Colors.RESET}")
        self._write_file(formatted)

    def detail(self, message: str, color: str = Colors.DARK_GRAY) -> None:
        formatted = f"   {message}"
        print(f"{color}{formatted}{Colors.RESET}")
        self._write_file(formatted)

    def raw(self, message: str, color: str = Colors.WHITE) -> None:
        print(f"{color}{message}{Colors.RESET}")
        self._write_file(message)

    def clear_screen_distro(self, current: int, total: int, name: str) -> None:
        os.system("clear")
        cols = shutil.get_terminal_size(fallback=(80, 24)).columns
        banner_len = min(90, max(40, cols - 1))
        banner_border = "=" * banner_len
        remaining = total - current
        header_text = f" DISTRO-FORTSCHRITT: {current} von {total} verarbeitet | {remaining} verbleibend | Aktuell: {name}"
        if len(header_text) > cols - 1:
            header_text = header_text[: cols - 4] + "..."
        print(f"{Colors.CYAN}{banner_border}{Colors.RESET}")
        print(f"{Colors.YELLOW}{header_text}{Colors.RESET}")
        print(f"{Colors.CYAN}{banner_border}{Colors.RESET}")
        self.log(f"[{current}/{total}] Prüfe Distribution: {name}", color=Colors.YELLOW, level="CHECK")

    def clear_screen_ventoy_copy(self, current: int, total: int, filename: str, size_mb: float) -> None:
        os.system("clear")
        cols = shutil.get_terminal_size(fallback=(80, 24)).columns
        banner_len = min(90, max(40, cols - 1))
        banner_border = "=" * banner_len
        remaining = total - current
        header_text = f" VENTOY-KOPIERSTATUS: {current} von {total} ISOs | {remaining} verbleibend | Aktuell: {filename} ({size_mb:.2f} MB)"
        if len(header_text) > cols - 1:
            header_text = header_text[: cols - 4] + "..."
        print(f"{Colors.CYAN}{banner_border}{Colors.RESET}")
        print(f"{Colors.YELLOW}{header_text}{Colors.RESET}")
        print(f"{Colors.CYAN}{banner_border}{Colors.RESET}")


class SingleInstanceLock:
    """Verhindert Mehrfachstarts mittels fcntl.flock."""

    def __init__(self, lock_file_path: str = DEFAULT_LOCK_FILE):
        self.lock_file_path = lock_file_path
        self.fp = None

    def acquire(self) -> bool:
        try:
            self.fp = open(self.lock_file_path, "w")
            if fcntl: fcntl.flock(self.fp.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
            return True
        except (IOError, BlockingIOError):
            return False

    def release(self) -> None:
        if self.fp:
            try:
                if fcntl: fcntl.flock(self.fp.fileno(), fcntl.LOCK_UN)
                self.fp.close()
                if os.path.exists(self.lock_file_path):
                    os.unlink(self.lock_file_path)
            except Exception:
                pass


def version_sort_key(ver_str: Any) -> Tuple[int, ...]:
    """Wandelt Versionszeichenketten für numerisches Sortieren in Tuple um."""
    parts = re.findall(r"\d+", str(ver_str))
    return tuple(int(p) for p in parts) if parts else (0,)


def format_progress_bar(prefix: str, current_bytes: int, total_bytes: int, speed_bytes_sec: float) -> str:
    """
    Erstellt eine einzeilige Fortschrittsanzeige, die sich dynamisch an die Terminalbreite anpasst
    und niemals umbricht.
    """
    cols = shutil.get_terminal_size(fallback=(80, 24)).columns
    max_len = max(cols - 1, 30)

    speed_mb = speed_bytes_sec / (1024 * 1024)
    trans_mb = current_bytes / (1024 * 1024)

    if total_bytes > 0:
        percent = min(100.0, (current_bytes / total_bytes) * 100.0)
        total_mb = total_bytes / (1024 * 1024)
        stats_full = f"{percent:5.1f}% | {trans_mb:7.2f} / {total_mb:7.2f} MB | {speed_mb:5.2f} MB/s"
        stats_short = f"{percent:5.1f}% | {trans_mb:.1f}/{total_mb:.1f} MB | {speed_mb:.1f} MB/s"

        fixed_len = len(prefix) + len(stats_full) + 4  # 'prefix [bar] stats'
        avail = max_len - fixed_len
        if avail >= 10:
            bar_width = min(25, avail)
            completed = int((percent / 100.0) * bar_width)
            bar_str = "=" * completed + "-" * (bar_width - completed)
            line = f"{prefix} [{bar_str}] {stats_full}"
        else:
            fixed_short = len(prefix) + len(stats_short) + 4
            avail_short = max_len - fixed_short
            if avail_short >= 8:
                bar_width = min(20, avail_short)
                completed = int((percent / 100.0) * bar_width)
                bar_str = "=" * completed + "-" * (bar_width - completed)
                line = f"{prefix} [{bar_str}] {stats_short}"
            elif max_len >= len(prefix) + len(stats_short) + 1:
                line = f"{prefix} {stats_short}"
            else:
                line = f"{prefix} {percent:5.1f}% | {trans_mb:.1f} MB"
    else:
        line = f"{prefix} {trans_mb:7.2f} MB | {speed_mb:5.2f} MB/s"

    return line[:max_len]


def format_duration(seconds: float) -> str:
    """Formatiert Sekunden in eine lesbare Zeichenkette wie '1h 12m 30s', '3m 45s' oder '12.4s'."""
    sec = int(round(seconds))
    if sec < 60:
        return f"{seconds:.1f}s" if seconds < 10 else f"{sec}s"
    minutes = sec // 60
    remaining_sec = sec % 60
    if minutes < 60:
        return f"{minutes}m {remaining_sec:02d}s"
    hours = minutes // 60
    remaining_min = minutes % 60
    return f"{hours}h {remaining_min:02d}m {remaining_sec:02d}s"


class DownloadResult:
    """Ergebnis eines HTTP-Downloads mit Metriken zu Dateigröße, Dauer und Geschwindigkeit."""

    def __init__(self, downloaded_bytes: int, elapsed_seconds: float):
        self.bytes = int(downloaded_bytes)
        self.seconds = max(elapsed_seconds, 0.001)
        self.size_mb = self.bytes / (1024 * 1024)
        self.speed_bytes_sec = self.bytes / self.seconds
        self.speed_mbs = self.speed_bytes_sec / (1024 * 1024)
        self.speed_mbits = (self.bytes * 8) / (self.seconds * 1_000_000)

    @property
    def duration_str(self) -> str:
        return format_duration(self.seconds)

    def __int__(self) -> int:
        return self.bytes

    def __iter__(self):
        return iter((self.bytes, self.seconds))

    def __repr__(self) -> str:
        return f"<DownloadResult {self.size_mb:.2f} MB in {self.duration_str} ({self.speed_mbs:.2f} MB/s)>"


# ==============================================================================
# HTTP & DOWNLOAD MANAGER
# ==============================================================================
class DownloadManager:
    """Verwaltet Web-Content-Abrufe und Streaming-Downloads."""

    def __init__(self, logger: Logger):
        self.logger = logger
        self.session = requests.Session()

    def get_web_content(self, uri: str, timeout: int = 15) -> Optional[str]:
        headers = {
            "User-Agent": CURL_USER_AGENT if "sourceforge.net" in uri else USER_AGENT,
            "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,text/plain,*/*;q=0.8",
        }
        try:
            with self.session.get(uri, headers=headers, stream=True, timeout=timeout) as resp:
                if resp.status_code == 200:
                    cl = int(resp.headers.get("Content-Length", 0))
                    ct = resp.headers.get("Content-Type", "").lower()
                    # Wenn Datei > 2 MB oder Binärarchiv/ISO, Download ablehnen
                    if cl > 2 * 1024 * 1024 or any(b in ct for b in ["octet-stream", "x-iso", "bzip2", "gzip", "zip", "image/"]):
                        return None
                    # Maximal 2 MB Text lesen
                    content_bytes = resp.raw.read(2 * 1024 * 1024, decode_content=True)
                    return content_bytes.decode("utf-8", errors="replace")
        except Exception:
            pass

        # Fallback über systemeigenes curl mit Größen-Limit (max 2 MB)
        try:
            cmd = ["curl", "-sL", "-A", headers["User-Agent"], "--max-time", str(timeout), "--max-filesize", "2097152", uri]
            res = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.DEVNULL, text=True)
            if res.returncode == 0 and res.stdout.strip():
                return res.stdout
        except Exception:
            pass
        return None

    def get_online_file_size(self, url: str, timeout: int = 10) -> int:
        headers = {
            "User-Agent": CURL_USER_AGENT if "sourceforge.net" in url else USER_AGENT,
        }
        try:
            resp = self.session.head(url, headers=headers, allow_redirects=True, timeout=timeout)
            if resp.status_code == 200 and "Content-Length" in resp.headers:
                length = int(resp.headers["Content-Length"])
                if length >= 1024 * 1024:
                    return length
            # Einige Server antworten auf HEAD nicht mit Content-Length
            resp_get = self.session.get(url, headers=headers, stream=True, timeout=timeout)
            if resp_get.status_code == 200 and "Content-Length" in resp_get.headers:
                length = int(resp_get.headers["Content-Length"])
                resp_get.close()
                if length >= 1024 * 1024:
                    return length
        except Exception:
            pass

        # Fallback über curl
        try:
            cmd = ["curl", "-sIL", "-A", headers["User-Agent"], "--max-time", str(timeout), url]
            res = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.DEVNULL, text=True)
            if res.returncode == 0:
                matches = re.findall(r"(?i)content-length:\s*(\d+)", res.stdout)
                if matches:
                    length = int(matches[-1])
                    if length >= 1024 * 1024:
                        return length
        except Exception:
            pass
        return 0

    def download_file(self, url: str, dest_path: Path, filename: str) -> DownloadResult:
        dest_path.parent.mkdir(parents=True, exist_ok=True)
        headers = {
            "User-Agent": CURL_USER_AGENT if "sourceforge.net" in url else USER_AGENT,
            "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8",
        }

        temp_dest = dest_path.with_suffix(dest_path.suffix + ".part")
        try:
            with self.session.get(url, headers=headers, stream=True, timeout=30) as resp:
                resp.raise_for_status()
                total_bytes = int(resp.headers.get("Content-Length", -1))

                start_time = time.monotonic()
                last_report = 0.0
                total_read = 0
                is_tty = sys.stdout.isatty()
                report_interval = 0.2 if is_tty else 5.0

                with open(temp_dest, "wb") as f:
                    for chunk in resp.iter_content(chunk_size=131072):
                        if not chunk:
                            continue
                        f.write(chunk)
                        total_read += len(chunk)

                        now = time.monotonic()
                        if now - last_report >= report_interval or total_read == total_bytes:
                            elapsed = max(now - start_time, 0.001)
                            speed_bytes_sec = total_read / elapsed
                            status = format_progress_bar("   [LADEN]", total_read, total_bytes, speed_bytes_sec)

                            if is_tty:
                                sys.stdout.write(f"\r\033[K{Colors.CYAN}{status}{Colors.RESET}")
                                sys.stdout.flush()
                            else:
                                sys.stdout.write(f"{status}\n")
                                sys.stdout.flush()
                            last_report = now

                if is_tty:
                    sys.stdout.write("\n")
                    sys.stdout.flush()

                if total_bytes > 0 and total_read < total_bytes:
                    raise IOError(f"Download unvollständig: {total_read} von {total_bytes} Bytes empfangen.")

                if dest_path.exists():
                    dest_path.unlink()
                temp_dest.rename(dest_path)
                elapsed_total = max(time.monotonic() - start_time, 0.001)
                return DownloadResult(total_read, elapsed_total)

        except Exception as e:
            if sys.stdout.isatty():
                sys.stdout.write("\n")
                sys.stdout.flush()
            if temp_dest.exists():
                try:
                    temp_dest.unlink()
                except Exception:
                    pass
            # Fallback mit curl falls Python requests scheitert
            try:
                self.logger.raw(f"\n   [DOWNLOAD FALLBACK] Nutze curl für {filename}...", color=Colors.YELLOW)
                curl_start = time.monotonic()
                curl_cmd = ["curl", "-L", "-A", headers["User-Agent"], "--progress-bar", "-o", str(dest_path), url]
                subprocess.run(curl_cmd, check=True)
                curl_elapsed = max(time.monotonic() - curl_start, 0.001)
                if dest_path.exists() and dest_path.stat().st_size > 1024 * 1024:
                    return DownloadResult(dest_path.stat().st_size, curl_elapsed)
            except Exception:
                pass
            raise e


# ==============================================================================
# CHECKSUM VERIFICATION & ARCHIV-MANAGER
# ==============================================================================
class ChecksumVerifier:
    """Prüft SHA256, SHA512 und MD5 Prüfsummen mit negativen Lookarounds."""

    def __init__(self, download_mgr: DownloadManager, logger: Logger):
        self.dm = download_mgr
        self.logger = logger

    def verify_iso_checksum(
        self, file_path: Path, download_url: str, filename: str, explicit_checksum_url: Optional[str] = None
    ) -> bool:
        expected_hash = None
        hash_algo = None

        # Basis-URL ohne Endungen wie .iso, .bz2, .gz etc. ermitteln
        base_url = re.sub(r"(\.iso)?(\.bz2|\.gz|\.xz|\.zip)?$", "", download_url, flags=re.I)

        sha512_candidates = [
            f"{base_url}.iso.sha512sum",
            f"{base_url}.iso.sha512",
            f"{base_url}.sha512sum",
            f"{base_url}.sha512",
            f"{download_url}.sha512sum",
            f"{download_url}.sha512",
        ]
        if explicit_checksum_url and "sha512" in explicit_checksum_url.lower():
            sha512_candidates.insert(0, explicit_checksum_url)

        sha256_candidates = [
            f"{base_url}.iso.sha256",
            f"{base_url}.iso.sha256sum",
            f"{base_url}.iso.SHA256",
            f"{base_url}.sha256",
            f"{base_url}.sha256sum",
            f"{download_url}.sha256",
            f"{download_url}.sha256sum",
            f"{download_url}.SHA256",
        ]
        if explicit_checksum_url and not any(k in explicit_checksum_url.lower() for k in ["sha512", "md5"]):
            sha256_candidates.insert(0, explicit_checksum_url)

        md5_candidates = [
            f"{base_url}.iso.md5",
            f"{base_url}.md5",
            f"{download_url}.md5",
        ]
        if explicit_checksum_url and "md5" in explicit_checksum_url.lower():
            md5_candidates.insert(0, explicit_checksum_url)

        def clean_candidates(c_list: List[str]) -> List[str]:
            res = []
            for c in c_list:
                if not c or c == download_url:
                    continue
                # Niemals ISOs oder Archive selbst als Prüfsummen-URL aufrufen
                if re.search(r"\.(iso|bz2|gz|xz|tar|zip|img)$", c, re.I):
                    continue
                if c not in res:
                    res.append(c)
            return res

        sha512_candidates = clean_candidates(sha512_candidates)
        sha256_candidates = clean_candidates(sha256_candidates)
        md5_candidates = clean_candidates(md5_candidates)

        algo_order = ["SHA256", "SHA512", "MD5"]
        if explicit_checksum_url:
            if "sha512" in explicit_checksum_url.lower():
                algo_order = ["SHA512", "SHA256", "MD5"]
            elif "md5" in explicit_checksum_url.lower():
                algo_order = ["MD5", "SHA256", "SHA512"]

        self.logger.detail(f"Suche Online-Prüfsumme für {filename}...", color=Colors.DARK_GRAY)

        for algo in algo_order:
            if expected_hash:
                break
            candidates = {
                "SHA512": sha512_candidates,
                "SHA256": sha256_candidates,
                "MD5": md5_candidates,
            }[algo]
            hex_len = {"SHA512": 128, "SHA256": 64, "MD5": 32}[algo]

            # Striktes Pattern mit negativen Lookarounds zur Vermeidung von Teilstring-Fehlern
            regex_with_filename_1 = re.compile(
                rf"^.*{re.escape(filename)}.*?(?<![a-fA-F0-9])([a-fA-F0-9]{{{hex_len}}})(?![a-fA-F0-9])",
                re.MULTILINE,
            )
            regex_with_filename_2 = re.compile(
                rf"^(?<![a-fA-F0-9])([a-fA-F0-9]{{{hex_len}}})(?![a-fA-F0-9])\s+.*?{re.escape(filename)}",
                re.MULTILINE,
            )
            regex_generic = re.compile(rf"(?<![a-fA-F0-9])([a-fA-F0-9]{{{hex_len}}})(?![a-fA-F0-9])")

            for c_url in candidates:
                content = self.dm.get_web_content(c_url, timeout=5)
                if content:
                    m1 = regex_with_filename_1.search(content)
                    if m1:
                        expected_hash = m1.group(1).lower()
                        hash_algo = algo
                        break
                    m2 = regex_with_filename_2.search(content)
                    if m2:
                        expected_hash = m2.group(1).lower()
                        hash_algo = algo
                        break
                    # regex_generic nur anwenden, wenn es sich nicht um eine HTML-Seite handelt (z.B. Sourceforge 404/Fehlerseite)
                    is_html = bool(re.search(r"^\s*<(!doctype|html)", content, re.I))
                    if not is_html:
                        m3 = regex_generic.search(content)
                        if m3:
                            expected_hash = m3.group(1).lower()
                            hash_algo = algo
                            break

        if not expected_hash:
            self.logger.detail(
                f"Keine Online-Prüfsumme gefunden für {filename}. Überspringe Hash-Verifikation.",
                color=Colors.DARK_GRAY,
            )
            return True

        file_mb = file_path.stat().st_size / (1024 * 1024)
        self.logger.detail(f"Erwarteter Hash ({hash_algo}): {expected_hash}", color=Colors.DARK_GRAY)
        self.logger.detail(f"Berechne lokalen {hash_algo}-Hash ({file_mb:.2f} MB)... Bitte warten.", color=Colors.DARK_GRAY)

        hasher = {
            "SHA512": hashlib.sha512(),
            "SHA256": hashlib.sha256(),
            "MD5": hashlib.md5(),
        }[hash_algo]

        try:
            with open(file_path, "rb") as f:
                while chunk := f.read(1024 * 1024):
                    hasher.update(chunk)
            actual_hash = hasher.hexdigest().lower()
            self.logger.detail(f"Berechneter Hash: {actual_hash}", color=Colors.DARK_GRAY)

            if actual_hash == expected_hash:
                self.logger.detail(f"{hash_algo}-Prüfsumme VERIFIZIERT: OK", color=Colors.GREEN)
                return True
            else:
                self.logger.log(
                    f"{hash_algo}-Prüfsumme FALSCH! Erwartet: {expected_hash} | Berechnet: {actual_hash}",
                    color=Colors.RED,
                    level="FEHLER",
                )
                return False
        except Exception as e:
            self.logger.log(f"Fehler bei der Berechnung der Prüfsumme: {e}", color=Colors.RED, level="FEHLER")
            return True


def decompress_bz2(bz2_path: Path, dest_iso_path: Path) -> bool:
    """Dekomprimiert .bz2-Archive mit dem integrierten Python bz2-Modul."""
    dest_iso_path.parent.mkdir(parents=True, exist_ok=True)
    try:
        with bz2.BZ2File(bz2_path, "rb") as src, open(dest_iso_path, "wb") as dst:
            shutil.copyfileobj(src, dst, length=1024 * 1024)
        if dest_iso_path.exists() and dest_iso_path.stat().st_size > 1024 * 1024:
            return True
    except Exception:
        pass

    # Fallback tar / bzip2
    try:
        subprocess.run(["tar", "-xf", str(bz2_path), "-C", str(dest_iso_path.parent)], check=True)
        if dest_iso_path.exists():
            return True
    except Exception:
        pass
    return False


# ==============================================================================
# DISTRIBUTIONS SCRAPING ENGINE (ALLE 59 DISTROS)
# ==============================================================================
class DistroScraperEngine:
    """Implementiert native Web-Scraper für alle 80 Distributionen."""

    def __init__(self, download_mgr: DownloadManager):
        self.dm = download_mgr

    def get_latest(self, item: Dict[str, Any]) -> Optional[Dict[str, Any]]:
        name = item.get("Name", "")
        method_name = f"scrape_{re.sub(r'[^a-zA-Z0-9_]', '', name.lower().replace(' ', '_'))}"
        if hasattr(self, method_name):
            try:
                res = getattr(self, method_name)()
                if res and res.get("Filename") and res.get("Url"):
                    return res
            except Exception:
                pass

        # Fallback falls direkte Url hinterlegt ist
        if item.get("Url"):
            direct_url = item["Url"]
            clean_url = direct_url.split("?")[0]
            fn = Path(clean_url).name
            if not fn or not (fn.endswith(".iso") or fn.endswith(".img")):
                fn = f"{name.replace(' ', '_')}.iso"
            vm = re.search(r"(\d+\.\d+(\.\d+)?)", fn)
            ver = vm.group(1) if vm else "Direkt"
            return {"Version": ver, "Url": direct_url, "Filename": fn}

        return None

    # --- 01 Desktop Linux ---
    def scrape_cachyos(self) -> Optional[Dict[str, Any]]:
        for u in ["https://mirror.cachyos.org/ISO/desktop/", "https://cdn.cachyos.org/ISO/desktop/"]:
            html = self.dm.get_web_content(u)
            if html:
                matches = re.findall(r'href="(\d+)/"', html)
                if matches:
                    latest = sorted(matches, key=int, reverse=True)[0]
                    fn = f"cachyos-desktop-linux-{latest}.iso"
                    return {"Version": latest, "Url": f"{u}{latest}/{fn}", "Filename": fn}
        return None

    def scrape_garuda_linux(self) -> Optional[Dict[str, Any]]:
        html = self.dm.get_web_content("https://iso.builds.garudalinux.org/iso/garuda/dr460nized/")
        if html:
            matches = re.findall(r'href="(\d+)/"', html)
            if matches:
                latest = sorted(matches, key=int, reverse=True)[0]
                sub = self.dm.get_web_content(f"https://iso.builds.garudalinux.org/iso/garuda/dr460nized/{latest}/")
                if sub:
                    m = re.search(r'href="(garuda-dr460nized-[^"]*?(\d{6})\.iso)"', sub)
                    if m:
                        return {
                            "Version": m.group(2),
                            "Url": f"https://iso.builds.garudalinux.org/iso/garuda/dr460nized/{latest}/{m.group(1)}",
                            "Filename": m.group(1),
                        }
        return None

    def scrape_linux_mint_cinnamon(self) -> Optional[Dict[str, Any]]:
        for base in [
            "https://ftp.fau.de/mint/iso/stable/",
            "https://mirror.netcologne.de/linuxmint/iso/stable/",
            "https://mirrors.edge.kernel.org/linuxmint/stable/",
        ]:
            html = self.dm.get_web_content(base)
            if html:
                raw_versions = [m[0] for m in re.findall(r'href="(\d+(\.\d+)*)/"', html)]
                sorted_vers = sorted(raw_versions, key=version_sort_key, reverse=True)[:3]
                for v in sorted_vers:
                    sub = self.dm.get_web_content(f"{base}{v}/")
                    if sub:
                        m = re.search(r'href="(linuxmint-[^"]+-cinnamon-64bit\.iso)"', sub)
                        if m:
                            return {"Version": v, "Url": f"{base}{v}/{m.group(1)}", "Filename": m.group(1)}
        return None

    def scrape_omarchy(self) -> Optional[Dict[str, Any]]:
        api = self.dm.get_web_content("https://api.github.com/repos/omacom/omarchy/releases/latest")
        if api:
            try:
                rel = json.loads(api)
                tag = rel["tag_name"].lstrip("v")
                iso_url = f"https://iso.omarchy.org/omarchy-{tag}-x86.iso"
                fn = f"omarchy-{tag}-x86.iso"
                for a in rel.get("assets", []):
                    if a.get("name", "").endswith(".iso"):
                        iso_url = a["browser_download_url"]
                        fn = a["name"]
                        break
                return {"Version": tag, "Url": iso_url, "Filename": fn}
            except Exception:
                pass
        html = self.dm.get_web_content("https://omarchy.org/")
        if html:
            m = re.search(r'href="([^"]*?omarchy-([0-9.]+)-x86\.iso)"', html)
            if m:
                url = m.group(1)
                ver = m.group(2)
                return {"Version": ver, "Url": url, "Filename": os.path.basename(url)}
        return {"Version": "4.5.0", "Url": "https://iso.omarchy.org/omarchy-4.5.0-x86.iso", "Filename": "omarchy-4.5.0-x86.iso"}

    def scrape_ubuntu_desktop(self) -> Optional[Dict[str, Any]]:
        base = "https://ftp.halifax.rwth-aachen.de/ubuntu-releases/"
        html = self.dm.get_web_content(base)
        if html:
            matches = [m[0] for m in re.findall(r'href="(\d+\.\d+(\.\d+)?)/"', html)]
            for v in sorted(matches, key=version_sort_key, reverse=True)[:3]:
                sub = self.dm.get_web_content(f"{base}{v}/")
                if sub:
                    m = re.search(r'href="(ubuntu-\d+\.\d+(\.\d+)?-desktop-amd64\.iso)"', sub)
                    if m:
                        return {"Version": v, "Url": f"{base}{v}/{m.group(1)}", "Filename": m.group(1)}
        return None

    def scrape_ubuntu_cinnamon(self) -> Optional[Dict[str, Any]]:
        base = "https://cdimage.ubuntu.com/ubuntucinnamon/releases/"
        html = self.dm.get_web_content(base)
        if html:
            matches = [m[0] for m in re.findall(r'href="(\d+\.\d+(\.\d+)?)/"', html)]
            for v in sorted(matches, key=version_sort_key, reverse=True)[:3]:
                for sub_dir in [f"{base}{v}/release/", f"{base}{v}/"]:
                    sub = self.dm.get_web_content(sub_dir)
                    if sub:
                        m = re.search(r'href="(ubuntucinnamon-[^"]+-desktop-amd64\.iso)"', sub)
                        if m:
                            return {"Version": v, "Url": f"{sub_dir}{m.group(1)}", "Filename": m.group(1)}
        return None

    def scrape_lubuntu(self) -> Optional[Dict[str, Any]]:
        base = "https://cdimage.ubuntu.com/lubuntu/releases/"
        html = self.dm.get_web_content(base)
        if html:
            matches = [m[0] for m in re.findall(r'href="(\d+\.\d+(\.\d+)?)/"', html)]
            for v in sorted(matches, key=version_sort_key, reverse=True)[:3]:
                for sub_dir in [f"{base}{v}/release/", f"{base}{v}/"]:
                    sub = self.dm.get_web_content(sub_dir)
                    if sub:
                        m = re.search(r'href="(lubuntu-[^"]+-desktop-amd64\.iso)"', sub)
                        if m:
                            return {
                                "Version": v,
                                "Url": f"{sub_dir}{m.group(1)}",
                                "Filename": m.group(1),
                                "ChecksumUrl": f"{sub_dir}SHA256SUMS",
                            }
        return None

    def scrape_winux(self) -> Optional[Dict[str, Any]]:
        raw = self.dm.get_web_content("https://sourceforge.net/projects/windows-linux/best_release.json")
        if raw:
            try:
                obj = json.loads(raw)
                fn_path = obj.get("release", {}).get("filename", "")
                m = re.search(r"winux-([0-9.]+[^/]*?)\.iso$", fn_path)
                if m:
                    ver = m.group(1)
                    fn = Path(fn_path).name
                    url = f"https://downloads.sourceforge.net/project/windows-linux{fn_path}"
                    return {"Version": ver, "Url": url, "Filename": fn}
            except Exception:
                pass
        return {
            "Version": "11.26.10-noble-lts",
            "Url": "https://downloads.sourceforge.net/project/windows-linux/winux-11.26.10-noble-lts.iso",
            "Filename": "winux-11.26.10-noble-lts.iso",
        }

    def scrape_zorin_os_education(self) -> Optional[Dict[str, Any]]:
        html = self.dm.get_web_content("https://zorin.com/os/download/")
        main_ver = "18"
        if html:
            m = re.search(r"/os/download/(\d+)/education/", html)
            if m:
                main_ver = m.group(1)
        dl = self.dm.get_web_content(f"https://zorin.com/os/download/{main_ver}/education/")
        if dl:
            m = re.search(r'href="(https://[^"]*?Zorin-OS-(\d+(\.\d+)?)-Education-64-bit\.iso)"', dl)
            if m:
                return {
                    "Version": m.group(2),
                    "Url": m.group(1),
                    "Filename": f"Zorin-OS-{m.group(2)}-Education-64-bit.iso",
                }
        return None

    def scrape_alpine_linux(self) -> Optional[Dict[str, Any]]:
        html = self.dm.get_web_content("https://dl-cdn.alpinelinux.org/alpine/latest-stable/releases/x86_64/")
        if html:
            m = re.search(r'href="(alpine-standard-(\d+\.\d+\.\d+)-x86_64\.iso)"', html)
            if m:
                return {
                    "Version": m.group(2),
                    "Url": f"https://dl-cdn.alpinelinux.org/alpine/latest-stable/releases/x86_64/{m.group(1)}",
                    "Filename": m.group(1),
                }
        return None

    def scrape_arch_linux(self) -> Optional[Dict[str, Any]]:
        mirrors = [
            "https://ftp.halifax.rwth-aachen.de/archlinux/iso/latest/",
            "https://geo.mirror.pkgbuild.com/iso/latest/",
        ]
        for base in mirrors:
            html = self.dm.get_web_content(base)
            if html:
                m = re.search(r'href=[\"\'](archlinux-(\d{4}\.\d{2}\.\d{2})-x86_64\.iso)[\"\']', html)
                if m:
                    return {
                        "Version": m.group(2),
                        "Url": f"{base}{m.group(1)}",
                        "Filename": m.group(1),
                    }
        return None

    def scrape_debian(self) -> Optional[Dict[str, Any]]:
        base = "https://cdimage.debian.org/debian-cd/current-live/amd64/iso-hybrid/"
        html = self.dm.get_web_content(base)
        if html:
            m = re.search(r'href="(debian-live-(\d+\.\d+\.\d+)-amd64-xfce\.iso)"', html)
            if m:
                return {"Version": m.group(2), "Url": f"{base}{m.group(1)}", "Filename": m.group(1)}
        return None

    def scrape_devuan(self) -> Optional[Dict[str, Any]]:
        for base in ["https://files.devuan.org/devuan_daedalus/installer-iso/", "https://pkgmaster.devuan.org/devuan_daedalus/installer-iso/"]:
            html = self.dm.get_web_content(base)
            if html:
                m = re.search(r'href="(devuan_daedalus_(\d+\.\d+\.\d+)_amd64_cd2\.iso)"', html)
                if m:
                    return {"Version": m.group(2), "Url": f"{base}{m.group(1)}", "Filename": m.group(1)}
                m2 = re.search(r'href="(devuan_daedalus_(\d+\.\d+\.\d+)_amd64_[^"]+\.iso)"', html)
                if m2:
                    return {"Version": m2.group(2), "Url": f"{base}{m2.group(1)}", "Filename": m2.group(1)}
        return None

    def scrape_fedora_workstation(self) -> Optional[Dict[str, Any]]:
        base = "https://ftp.halifax.rwth-aachen.de/fedora/linux/releases/"
        html = self.dm.get_web_content(base)
        if html:
            versions = re.findall(r'href="(\d+)/"', html)
            for v in sorted(versions, key=int, reverse=True)[:3]:
                sub = self.dm.get_web_content(f"{base}{v}/Workstation/x86_64/iso/")
                if sub:
                    m = re.search(r'href="(Fedora-Workstation-Live-[^"]+?\.iso)"', sub)
                    if m:
                        return {"Version": v, "Url": f"{base}{v}/Workstation/x86_64/iso/{m.group(1)}", "Filename": m.group(1)}
        return None

    def scrape_gentoo_livegui(self) -> Optional[Dict[str, Any]]:
        base = "https://distfiles.gentoo.org/releases/amd64/autobuilds/current-livegui-amd64/"
        html = self.dm.get_web_content(base)
        if html:
            m = re.search(r'href="(livegui-amd64-(\d{8}T\d{6}Z)\.iso)"', html)
            if m:
                return {"Version": m.group(2), "Url": f"{base}{m.group(1)}", "Filename": m.group(1)}
        return None

    def scrape_mageia(self) -> Optional[Dict[str, Any]]:
        for base in ["https://ftp.fau.de/mageia/iso/", "https://ftp.gwdg.de/pub/linux/mageia/iso/"]:
            html = self.dm.get_web_content(base)
            if html:
                versions = re.findall(r'href="(\d+)/"', html)
                for v in sorted(versions, key=int, reverse=True)[:3]:
                    sub = self.dm.get_web_content(f"{base}{v}/Mageia-{v}-x86_64/")
                    if sub:
                        m = re.search(r'href="(Mageia-[^"]+?\.iso)"', sub)
                        if m:
                            return {"Version": v, "Url": f"{base}{v}/Mageia-{v}-x86_64/{m.group(1)}", "Filename": m.group(1)}
        return None

    def scrape_endeavouros(self) -> Optional[Dict[str, Any]]:
        for u in ["https://mirror.alpix.eu/endeavouros/iso/", "https://ftp.acc.umu.se/mirror/endeavouros/iso/"]:
            html = self.dm.get_web_content(u)
            if html:
                matches = re.findall(r'href="(EndeavourOS_[^"]*?-(\d{4}\.\d{2}\.\d{2})\.iso)"', html)
                if matches:
                    latest = sorted(matches, key=lambda x: x[1], reverse=True)[0]
                    return {"Version": latest[1], "Url": f"{u}{latest[0]}", "Filename": latest[0]}
        return None

    def scrape_antix(self) -> Optional[Dict[str, Any]]:
        mirrors = [
            "https://ftp.fau.de/mxlinux-cd/ANTIX/Final/",
            "https://ftp.halifax.rwth-aachen.de/mxlinux/isos/ANTIX/Final/",
            "https://ftp.tu-chemnitz.de/pub/linux/MX/Linux/ANTIX/Final/",
            "https://ftp.gwdg.de/pub/linux/mx/iso/ANTIX/Final/",
        ]
        for base in mirrors:
            html = self.dm.get_web_content(base)
            if html:
                dirs = re.findall(r'href="(antiX-[0-9.]+)/?"', html)
                if dirs:
                    latest = sorted(dirs)[-1]
                    sub = f"{base}{latest}/"
                    sub_html = self.dm.get_web_content(sub)
                    if sub_html:
                        m = re.search(r'href="(antiX-([0-9.]+)_x64-full\.iso)"', sub_html)
                        if m:
                            return {
                                "Version": m.group(2),
                                "Url": f"{sub}{m.group(1)}",
                                "Filename": m.group(1),
                                "ChecksumUrl": f"{sub}{m.group(1)}.sha256",
                            }
        return None

    def scrape_calculate_linux(self) -> Optional[Dict[str, Any]]:
        base = "https://mirror.calculate-linux.org/release/"
        html = self.dm.get_web_content(base)
        if html:
            dirs = [d for d in re.findall(r'href="(\d{8})/"', html)]
            if dirs:
                latest = sorted(dirs)[-1]
                sub = f"{base}{latest}/"
                sub_html = self.dm.get_web_content(sub)
                if sub_html:
                    m = re.search(r'href="(cld-(\d+)-x86_64\.iso)"', sub_html)
                    if m:
                        return {
                            "Version": m.group(2),
                            "Url": f"{sub}{m.group(1)}",
                            "Filename": m.group(1),
                            "ChecksumUrl": f"{sub}SHA256SUMS",
                        }
        return None

    def scrape_crux(self) -> Optional[Dict[str, Any]]:
        base = "https://ftp.spline.inf.fu-berlin.de/pub/crux/"
        html = self.dm.get_web_content(base)
        if html:
            dirs = re.findall(r'href="(crux-([0-9.]+))/"', html)
            if dirs:
                latest_dir = sorted(dirs, key=lambda x: [int(p) for p in x[1].split('.')])[-1][0]
                sub = f"{base}{latest_dir}/iso/"
                sub_html = self.dm.get_web_content(sub)
                if sub_html:
                    m = re.search(r'href="(crux-([0-9.]+)\.iso)"', sub_html)
                    if m:
                        return {
                            "Version": m.group(2),
                            "Url": f"{sub}{m.group(1)}",
                            "Filename": m.group(1),
                            "ChecksumUrl": f"{sub}{m.group(1)}.sha256",
                        }
        return None

    def scrape_elementary_os(self) -> Optional[Dict[str, Any]]:
        html = self.dm.get_web_content("https://elementary.io/")
        if html:
            m = re.search(r'href="(https://dl\.elementaryos\.org/[^"]+/elementaryos-([0-9.]+)-stable-amd64\.([0-9]+)\.iso)"', html)
            if m:
                ver = f"{m.group(2)}.{m.group(3)}"
                fn = Path(m.group(1)).name
                return {"Version": ver, "Url": m.group(1), "Filename": fn}
        return None

    def scrape_linux_lite(self) -> Optional[Dict[str, Any]]:
        raw = self.dm.get_web_content("https://sourceforge.net/projects/linux-lite/best_release.json")
        if raw:
            try:
                data = json.loads(raw)
                fn_path = data.get("release", {}).get("filename", "")
                m = re.search(r"linux-lite-([0-9.]+)-64bit\.iso$", fn_path)
                if m:
                    ver = m.group(1)
                    fn = Path(fn_path).name
                    url = f"https://downloads.sourceforge.net/project/linux-lite{fn_path}"
                    return {"Version": ver, "Url": url, "Filename": fn}
            except Exception:
                pass
        return None

    def scrape_manjaro_linux(self) -> Optional[Dict[str, Any]]:
        # Aktuell auf stabile 26.1.3 gepinnt, da SourceForge Release 27.0 extrem gedrosselt wird
        return {
            "Version": "26.1.3",
            "Url": "https://downloads.sourceforge.net/project/manjarolinux/xfce/26.1.3/manjaro-xfce-26.1.3-261028-linux72.iso",
            "Filename": "manjaro-xfce-26.1.3-261028-linux72.iso",
        }

    def scrape_mx_linux(self) -> Optional[Dict[str, Any]]:
        base = "https://ftp.gwdg.de/pub/linux/mx/iso/MX/Final/Xfce/"
        html = self.dm.get_web_content(base)
        if html:
            m = re.findall(r'href="(MX-([0-9.]+)_Xfce_x64\.iso)"', html)
            if m:
                fn, ver = m[-1]
                return {"Version": ver, "Url": f"{base}{fn}", "Filename": fn, "ChecksumUrl": f"{base}{fn}.sha256"}
        return None

    def scrape_nixos(self) -> Optional[Dict[str, Any]]:
        html = self.dm.get_web_content("https://nixos.org/download/")
        if html:
            m = re.search(r'href="(https://channels\.nixos\.org/nixos-([0-9.]+)/latest-nixos-graphical-x86_64-linux\.iso)"', html)
            if m:
                channel_url = m.group(1)
                ver = m.group(2)
                chk_url = f"{channel_url}.sha256"
                resp = self.dm.session.head(channel_url, allow_redirects=True, timeout=10)
                final_url = resp.url if resp.status_code == 200 else channel_url
                fn = Path(final_url).name
                if not fn.endswith(".iso"):
                    fn = f"nixos-graphical-{ver}-x86_64-linux.iso"
                vm = re.search(r"nixos-graphical-([0-9.]+)\.", fn)
                if vm:
                    ver = vm.group(1)
                return {"Version": ver, "Url": channel_url, "Filename": fn, "ChecksumUrl": chk_url}
        return None

    def scrape_opensuse_tumbleweed(self) -> Optional[Dict[str, Any]]:
        base = "https://ftp.halifax.rwth-aachen.de/opensuse/tumbleweed/iso/"
        html = self.dm.get_web_content(base)
        if html:
            m = re.search(r'href="(openSUSE-Tumbleweed-DVD-x86_64-Snapshot([0-9]+)-Media\.iso)"', html)
            if m:
                fn = m.group(1)
                ver = m.group(2)
                return {"Version": ver, "Url": f"{base}{fn}", "Filename": fn, "ChecksumUrl": f"{base}{fn}.sha256"}
        return None

    def scrape_pop_os(self) -> Optional[Dict[str, Any]]:
        html = self.dm.get_web_content("https://system76.com/pop/download")
        if html:
            m = re.search(r"location\.href=\'(https://iso\.pop-os\.org/([0-9.]+)/amd64/intel/([0-9]+)/(pop-os_[^\']+\.iso))\'", html)
            if m:
                url = m.group(1)
                ver = f"{m.group(2)}.{m.group(3)}"
                fn = m.group(4)
                chk = f"https://iso.pop-os.org/{m.group(2)}/amd64/intel/{m.group(3)}/SHA256SUMS"
                return {"Version": ver, "Url": url, "Filename": fn, "ChecksumUrl": chk}
        return None

    def scrape_slackware(self) -> Optional[Dict[str, Any]]:
        base = "https://ftp.gwdg.de/pub/linux/slackware/slackware-iso/"
        html = self.dm.get_web_content(base)
        if html:
            dirs = re.findall(r'href="(slackware64-([0-9.]+)-iso)/?"', html)
            if dirs:
                latest_dir = sorted(dirs, key=lambda x: [int(p) for p in x[1].split('.')])[-1][0]
                sub = f"{base}{latest_dir}/"
                sub_html = self.dm.get_web_content(sub)
                if sub_html:
                    m = re.search(r'href="(slackware64-([0-9.]+)-install-dvd\.iso)"', sub_html)
                    if m:
                        return {
                            "Version": m.group(2),
                            "Url": f"{sub}{m.group(1)}",
                            "Filename": m.group(1),
                            "ChecksumUrl": f"{sub}{m.group(1)}.md5",
                        }
        return None

    def scrape_solus(self) -> Optional[Dict[str, Any]]:
        html = self.dm.get_web_content("https://getsol.us/download/")
        if html:
            m = re.search(r'(https://downloads\.getsol\.us/isos/([^/]+)/(Solus-Budgie-Release-([^\s\"\'&>]+)\.iso))', html)
            if m:
                url = m.group(1)
                fn = m.group(3)
                ver = m.group(4)
                return {"Version": ver, "Url": url, "Filename": fn, "ChecksumUrl": f"{url}.sha256sum"}
        return None

    def scrape_void_linux(self) -> Optional[Dict[str, Any]]:
        base = "https://repo-default.voidlinux.org/live/current/"
        html = self.dm.get_web_content(base)
        if html:
            m = re.search(r'href="(void-live-x86_64-([0-9]+)-xfce\.iso)"', html)
            if m:
                return {
                    "Version": m.group(2),
                    "Url": f"{base}{m.group(1)}",
                    "Filename": m.group(1),
                    "ChecksumUrl": f"{base}sha256sum.txt",
                }
        return None

    # --- 02 Enterprise Server ---
    def scrape_almalinux(self) -> Optional[Dict[str, Any]]:
        mirrors = [
            "https://ftp.halifax.rwth-aachen.de/almalinux/9/isos/x86_64/",
            "https://ftp.fau.de/almalinux/9/isos/x86_64/",
            "https://repo.almalinux.org/almalinux/9/isos/x86_64/",
        ]
        for base in mirrors:
            html = self.dm.get_web_content(base)
            if html:
                m = re.search(r'href=[\"\'](AlmaLinux-9[^\"]*?-x86_64-dvd\.iso)[\"\']', html)
                if m:
                    fn = m.group(1)
                    vm = re.search(r"AlmaLinux-9\.(\d+)", fn)
                    ver = f"9.{vm.group(1)}" if vm else "9"
                    return {"Version": ver, "Url": f"{base}{fn}", "Filename": fn}
        return None

    def scrape_azure_linux(self) -> Optional[Dict[str, Any]]:
        # Azure Linux (vormals CBL-Mariner) von Microsoft
        ver = "3.0"
        api = self.dm.get_web_content("https://api.github.com/repos/microsoft/azurelinux/releases/latest")
        if api:
            try:
                rel = json.loads(api)
                name = rel.get("name") or rel.get("tag_name", "")
                tag = name.split("-")[0].lstrip("v")
                if tag:
                    ver = tag
            except Exception:
                pass

        return {
            "Version": ver,
            "Url": "https://aka.ms/azurelinux-3.0-x86_64.iso",
            "Filename": "AzureLinux-3.0-x86_64.iso",
            "ChecksumUrl": "https://aka.ms/azurelinux-3.0-x86_64-iso-checksum",
        }


    # --- 15 Neue Distributionen (v2.7.0 Parität) ---
    def scrape_nobara_project(self) -> Optional[Dict[str, Any]]:
        html = self.dm.get_web_content("https://nobaraproject.org/download-nobara/")
        if html:
            m = re.search(r'href="([^"]*?(Nobara-(\d+)-Official-([0-9-]+)\.iso))\.sha256sum"', html)
            if m:
                iso_url, fn, ver_num, date_part = m.group(1), m.group(2), m.group(3), m.group(4)
                return {"Version": f"{ver_num} ({date_part})", "Url": iso_url, "Filename": fn, "ChecksumUrl": f"{iso_url}.sha256sum"}
        return {"Version": "44", "Url": "https://nobara-images.nobaraproject.org/Nobara-44-Official-2026-10-13.iso", "Filename": "Nobara-44-Official-2026-10-13.iso", "ChecksumUrl": "https://nobara-images.nobaraproject.org/Nobara-44-Official-2026-10-13.iso.sha256sum"}

    def scrape_bazzite(self) -> Optional[Dict[str, Any]]:
        return {"Version": "stable", "Url": "https://download.bazzite.gg/bazzite-stable-live-amd64.iso", "Filename": "bazzite-stable-live-amd64.iso", "ChecksumUrl": "https://download.bazzite.gg/bazzite-stable-live-amd64.iso-CHECKSUM"}

    def scrape_tuxedo_os(self) -> Optional[Dict[str, Any]]:
        html = self.dm.get_web_content("https://os.tuxedocomputers.com/")
        if html:
            m = re.search(r'href="(TUXEDO-OS-([0-9]+)\.iso)"', html)
            if m:
                fn, ver = m.group(1), m.group(2)
                return {"Version": ver, "Url": f"https://os.tuxedocomputers.com/{fn}", "Filename": fn, "ChecksumUrl": f"https://os.tuxedocomputers.com/{fn}.sha256"}
        return {"Version": "3", "Url": "https://os.tuxedocomputers.com/TUXEDO-OS-202610191505.iso", "Filename": "TUXEDO-OS-202610191505.iso", "ChecksumUrl": "https://os.tuxedocomputers.com/TUXEDO-OS-202610191505.iso.sha256"}

    def scrape_kubuntu(self) -> Optional[Dict[str, Any]]:
        html = self.dm.get_web_content("https://cdimage.ubuntu.com/kubuntu/releases/")
        if html:
            vers = re.findall(r'href="(\d+\.\d+(\.\d+)?)/"', html)
            if vers:
                latest_ver = sorted(list(set(v[0] for v in vers)), key=lambda s: [int(x) for x in s.split(".")])[-1]
                sub = self.dm.get_web_content(f"https://cdimage.ubuntu.com/kubuntu/releases/{latest_ver}/release/")
                if sub:
                    m = re.search(rf'(kubuntu-{re.escape(latest_ver)}-desktop-amd64\.iso)', sub)
                    if m:
                        fn = m.group(1)
                        return {"Version": latest_ver, "Url": f"https://cdimage.ubuntu.com/kubuntu/releases/{latest_ver}/release/{fn}", "Filename": fn, "ChecksumUrl": f"https://cdimage.ubuntu.com/kubuntu/releases/{latest_ver}/release/SHA256SUMS"}
        return {"Version": "26.10", "Url": "https://cdimage.ubuntu.com/kubuntu/releases/26.10/release/kubuntu-26.10-desktop-amd64.iso", "Filename": "kubuntu-26.10-desktop-amd64.iso", "ChecksumUrl": "https://cdimage.ubuntu.com/kubuntu/releases/26.10/release/SHA256SUMS"}

    def scrape_q4os(self) -> Optional[Dict[str, Any]]:
        raw = self.dm.get_web_content("https://sourceforge.net/projects/q4os/best_release.json")
        if raw:
            try:
                data = json.loads(raw)
                rel = data.get("release", {})
                if rel.get("url"):
                    fn = Path(rel.get("filename", "")).name
                    vm = re.search(r'q4os-([0-9.]+)-x64', fn)
                    ver = vm.group(1) if vm else "6.11"
                    exp = rel.get("sha256sum")
                    return {"Version": ver, "Url": rel["url"], "Filename": fn, "ExpectedHash": exp}
            except Exception:
                pass
        return {"Version": "6.11", "Url": "https://sourceforge.net/projects/q4os/files/stable/q4os-6.11-x64.r1.iso/download", "Filename": "q4os-6.11-x64.r1.iso", "ExpectedHash": "e29032193ac73f97184e520935ce6af24dbb2cd3bbf813fe25d4c33b89775463"}

    def scrape_kde_neon(self) -> Optional[Dict[str, Any]]:
        html = self.dm.get_web_content("https://neon.kde.org/download")
        if html:
            m = re.search(r'href="(https://files\.kde\.org/neon/images/desk/user/([0-9-]+)/(neon-user-desk-([0-9-]+)\.iso))"', html)
            if m:
                url, fn, ver = m.group(1), m.group(3), m.group(4)
                return {"Version": ver, "Url": url, "Filename": fn, "ChecksumUrl": f"{url}.sha256sum"}
        return {"Version": "20261025-1825", "Url": "https://files.kde.org/neon/images/desk/user/20261025-1825/neon-user-desk-20261025-1825.iso", "Filename": "neon-user-desk-20261025-1825.iso", "ChecksumUrl": "https://files.kde.org/neon/images/desk/user/20261025-1825/neon-user-desk-20261025-1825.iso.sha256sum"}

    def scrape_proxmox_backup_server_pbs(self) -> Optional[Dict[str, Any]]:
        html = self.dm.get_web_content("https://enterprise.proxmox.com/iso/")
        if html:
            matches = re.findall(r'href="(proxmox-backup-server_([0-9.-]+)\.iso)"', html)
            if matches:
                latest = matches[-1]
                fn, ver = latest[0], latest[1]
                url = f"https://enterprise.proxmox.com/iso/{fn}"
                return {"Version": ver, "Url": url, "Filename": fn, "ChecksumUrl": f"{url}.sha256"}
        return {"Version": "4.2-1", "Url": "https://enterprise.proxmox.com/iso/proxmox-backup-server_4.2-1.iso", "Filename": "proxmox-backup-server_4.2-1.iso", "ChecksumUrl": "https://enterprise.proxmox.com/iso/proxmox-backup-server_4.2-1.iso.sha256"}

    def scrape_oracle_linux(self) -> Optional[Dict[str, Any]]:
        html = self.dm.get_web_content("https://yum.oracle.com/oracle-linux-isos.html")
        if html:
            m = re.search(r'href="([^"]*?(OracleLinux-R(\d+)-U(\d+)-x86_64-(dvd|boot)\.iso))"', html)
            if m:
                url, fn, maj, rel = m.group(1), m.group(2), m.group(3), m.group(4)
                return {"Version": f"{maj}.{rel}", "Url": url, "Filename": fn}
        return {"Version": "9.9", "Url": "https://yum.oracle.com/ISOS/OracleLinux/OL9/u9/x86_64/OracleLinux-R9-U9-x86_64-dvd.iso", "Filename": "OracleLinux-R9-U9-x86_64-dvd.iso"}

    def scrape_xcpng(self) -> Optional[Dict[str, Any]]:
        html = self.dm.get_web_content("https://updates.xcp-ng.org/isos/8.3/")
        if html:
            matches = re.findall(r'href="(xcp-ng-([0-9.]+-[0-9]+)\.iso)"', html)
            if matches:
                fn, ver = matches[-1][0], matches[-1][1]
                return {"Version": ver, "Url": f"https://updates.xcp-ng.org/isos/8.3/{fn}", "Filename": fn, "ChecksumUrl": "https://updates.xcp-ng.org/isos/8.3/SHA256SUMS"}
        return {"Version": "8.3.0", "Url": "https://updates.xcp-ng.org/isos/8.3/xcp-ng-8.3.0-20260806.iso", "Filename": "xcp-ng-8.3.0-20260806.iso", "ChecksumUrl": "https://updates.xcp-ng.org/isos/8.3/SHA256SUMS"}

    def scrape_tails(self) -> Optional[Dict[str, Any]]:
        raw = self.dm.get_web_content("https://tails.net/install/v2/Tails/amd64/stable/latest.json")
        if raw:
            try:
                data = json.loads(raw)
                paths = data.get("installations", [{}])[0].get("installation-paths", [])
                for p in paths:
                    for t in p.get("target-files", []):
                        if t.get("url", "").endswith(".iso"):
                            url = t["url"]
                            fn = Path(url).name
                            m = re.search(r"tails-amd64-([0-9.]+)", fn)
                            ver = m.group(1) if m else "latest"
                            return {"Version": ver, "Url": url, "Filename": fn}
            except Exception:
                pass
        return {"Version": "7.17.1", "Url": "https://download.tails.net/tails/stable/tails-amd64-7.17.1/tails-amd64-7.17.1.iso", "Filename": "tails-amd64-7.17.1.iso"}

    def scrape_athena_os(self) -> Optional[Dict[str, Any]]:
        return {"Version": "latest", "Url": "https://hub.athenaos.org/iso/athenaos-live-x86_64.iso", "Filename": "athenaos-live-x86_64.iso", "ChecksumUrl": "https://hub.athenaos.org/iso/athenaos-live-x86_64.iso.sha256"}

    def scrape_memtest86(self) -> Optional[Dict[str, Any]]:
        html = self.dm.get_web_content("https://www.memtest.org/")
        if html:
            m = re.search(r'href="([^"]*?(mt86plus_([0-9.]+)_x86_64\.iso\.zip))"', html)
            if m:
                path_part, ver = m.group(1), m.group(3)
                url = f"https://www.memtest.org{path_part}"
                return {"Version": ver, "Url": url, "Filename": f"mt86plus_{ver}.iso.zip", "ExtractTo": f"mt86plus-{ver}-x86_64.iso"}
        return {"Version": "9.00", "Url": "https://www.memtest.org/download/v9.00/mt86plus_9.00_x86_64.iso.zip", "Filename": "mt86plus_9.00.iso.zip", "ExtractTo": "mt86plus-9.00-x86_64.iso"}

    def scrape_redo_rescue(self) -> Optional[Dict[str, Any]]:
        raw = self.dm.get_web_content("https://sourceforge.net/projects/redobackup/best_release.json")
        if raw:
            try:
                data = json.loads(raw)
                rel = data.get("release", {})
                if rel.get("url"):
                    fn = Path(rel.get("filename", "redorescue-4.0.0.iso")).name
                    vm = re.search(r'redorescue-([0-9.]+)\.iso', fn)
                    ver = vm.group(1) if vm else "4.0.0"
                    return {"Version": ver, "Url": rel["url"], "Filename": fn}
            except Exception:
                pass
        return {"Version": "4.0.0", "Url": "https://sourceforge.net/projects/redobackup/files/redorescue-4.0.0.iso/download", "Filename": "redorescue-4.0.0.iso"}

    def scrape_ghostbsd(self) -> Optional[Dict[str, Any]]:
        html = self.dm.get_web_content("https://ghostbsd.org/download")
        if html:
            m = re.search(r'href="(https://download\.ghostbsd\.org/releases/amd64/([0-9.a-zA-Z]+)/(GhostBSD-[0-9.a-zA-Z-]+\.iso))"', html)
            if m:
                url, ver, fn = m.group(1), m.group(2), m.group(3)
                return {"Version": ver, "Url": url, "Filename": fn, "ChecksumUrl": f"{url}.sha256"}
        return {"Version": "26.3", "Url": "https://download.ghostbsd.org/releases/amd64/26.3.R15.1p6/GhostBSD-26.3.R15.1p6.iso", "Filename": "GhostBSD-26.3.R15.1p6.iso", "ChecksumUrl": "https://download.ghostbsd.org/releases/amd64/26.3.R15.1p6/GhostBSD-26.3.R15.1p6.iso.sha256"}

    def scrape_opnsense(self) -> Optional[Dict[str, Any]]:
        base = "https://mirror.ams1.nl.leaseweb.net/opnsense/releases/"
        html = self.dm.get_web_content(base)
        if html:
            vers = re.findall(r'href="(\d+\.\d+)/"', html)
            if vers:
                latest = sorted(vers, key=lambda s: [int(x) for x in s.split(".")])[-1]
                sub = self.dm.get_web_content(f"{base}{latest}/")
                if sub:
                    m = re.search(rf'(OPNsense-{re.escape(latest)}-dvd-amd64\.iso\.bz2)', sub)
                    if m:
                        fn = m.group(1)
                        ext_to = fn.replace(".bz2", "")
                        return {"Version": latest, "Url": f"{base}{latest}/{fn}", "Filename": fn, "ExtractTo": ext_to, "ChecksumUrl": f"{base}{latest}/OPNsense-{latest}-checksums-amd64.sha256"}
        return {"Version": "26.7", "Url": "https://mirror.ams1.nl.leaseweb.net/opnsense/releases/26.7/OPNsense-26.7-dvd-amd64.iso.bz2", "Filename": "OPNsense-26.7-dvd-amd64.iso.bz2", "ExtractTo": "OPNsense-26.7-dvd-amd64.iso", "ChecksumUrl": "https://mirror.ams1.nl.leaseweb.net/opnsense/releases/26.7/OPNsense-26.7-checksums-amd64.sha256"}

    def scrape_centos_stream_9(self) -> Optional[Dict[str, Any]]:
        mirrors = [
            "https://ftp.halifax.rwth-aachen.de/centos-stream/9-stream/BaseOS/x86_64/iso/",
            "https://mirrors.almalinux.org/centos-stream/9-stream/BaseOS/x86_64/iso/",
            "https://mirror.stream.centos.org/9-stream/BaseOS/x86_64/iso/",
        ]
        for base in mirrors:
            html = self.dm.get_web_content(base)
            if html:
                m = re.search(r'href=[\"\'](CentOS-Stream-9[^\"]*?-x86_64-dvd1\.iso)[\"\']', html)
                if m:
                    fn = m.group(1)
                    vm = re.search(r"CentOS-Stream-9-(\d+)", fn)
                    ver = vm.group(1) if vm else "9"
                    return {"Version": ver, "Url": f"{base}{fn}", "Filename": fn}
        return None

    def scrape_proxmox_ve(self) -> Optional[Dict[str, Any]]:
        base = "https://enterprise.proxmox.com/iso/"
        html = self.dm.get_web_content(base)
        if html:
            m = re.search(r'href="\./(proxmox-ve_(\d+\.\d+-\d+)\.iso)"', html)
            if m:
                return {"Version": m.group(2), "Url": f"{base}{m.group(1)}", "Filename": m.group(1)}
        return None

    def scrape_rocky_linux(self) -> Optional[Dict[str, Any]]:
        mirrors = [
            "https://ftp.halifax.rwth-aachen.de/rockylinux/9/isos/x86_64/",
            "https://ftp.fau.de/rockylinux/9/isos/x86_64/",
            "https://ftp.gwdg.de/pub/linux/rocky/9/isos/x86_64/",
            "https://download.rockylinux.org/pub/rocky/9/isos/x86_64/",
        ]
        for base in mirrors:
            html = self.dm.get_web_content(base)
            if html:
                m = re.search(r'href=[\"\'](Rocky-9[^\"]*?-x86_64-dvd\.iso)[\"\']', html)
                if m:
                    fn = m.group(1)
                    vm = re.search(r"Rocky-9\.(\d+)", fn)
                    ver = f"9.{vm.group(1)}" if vm else "9"
                    return {"Version": ver, "Url": f"{base}{fn}", "Filename": fn}
        return None

    def scrape_openmediavault(self) -> Optional[Dict[str, Any]]:
        js = self.dm.get_web_content("https://sourceforge.net/projects/openmediavault/best_release.json")
        if js:
            try:
                obj = json.loads(js)
                fn_path = obj.get("release", {}).get("filename", "")
                m = re.search(r"openmediavault_([0-9.]+[^/]*?)-amd64\.iso$", fn_path)
                if m:
                    fn = Path(fn_path).name
                    return {
                        "Version": m.group(1),
                        "Url": f"https://downloads.sourceforge.net/project/openmediavault{fn_path}",
                        "Filename": fn,
                    }
            except Exception:
                pass
        return {
            "Version": "8.3.1",
            "Url": "https://downloads.sourceforge.net/project/openmediavault/iso/8.3.1/openmediavault_8.3.1-amd64.iso",
            "Filename": "openmediavault_8.3.1-amd64.iso",
        }

    def scrape_zimaos(self) -> Optional[Dict[str, Any]]:
        api = self.dm.get_web_content("https://api.github.com/repos/IceWhaleTech/ZimaOS/releases/latest")
        if api:
            try:
                rel = json.loads(api)
                tag = rel["tag_name"].lstrip("v")
                for a in rel.get("assets", []):
                    if a.get("name", "").endswith(".iso"):
                        return {"Version": tag, "Url": a["browser_download_url"], "Filename": a["name"]}
            except Exception:
                pass
        return None

    def scrape_freenas_truenas(self) -> Optional[Dict[str, Any]]:
        html = self.dm.get_web_content("https://download.truenas.com/")
        if html:
            matches = re.findall(r'href="([^"]*?(TrueNAS-(?:SCALE|CORE)-(\d+\.\d+(\.\d+)*))\.iso)"', html)
            if matches:
                rel_url, _, ver, _ = matches[-1]
                fn = Path(rel_url).name
                return {"Version": ver, "Url": f"https://download.truenas.com/{rel_url}", "Filename": fn}
        return {
            "Version": "25.10.7",
            "Url": "https://download.truenas.com/TrueNAS-SCALE-Goldeye/25.10.7/TrueNAS-SCALE-25.10.7.iso",
            "Filename": "TrueNAS-SCALE-25.10.7.iso",
        }

    def scrape_ubuntu_server_lts(self) -> Optional[Dict[str, Any]]:
        base = "https://releases.ubuntu.com/"
        html = self.dm.get_web_content(base)
        if html:
            matches = [m[0] for m in re.findall(r'href="(\d+\.04(\.\d+)?)/"', html)]
            for v in sorted(matches, key=version_sort_key, reverse=True)[:3]:
                sub = self.dm.get_web_content(f"{base}{v}/")
                if sub:
                    m = re.search(r'href="(ubuntu-\d+\.04(\.\d+)?-live-server-amd64\.iso)"', sub)
                    if m:
                        return {"Version": v, "Url": f"{base}{v}/{m.group(1)}", "Filename": m.group(1)}
        return None

    def scrape_rockstor(self) -> Optional[Dict[str, Any]]:
        html = self.dm.get_web_content("https://rockstor.com/dls/index.html")
        if html:
            m = re.search(r'href=["\']([^"\']*(Rockstor-Leap[0-9.]+-generic\.x86_64-([0-9.-]+)\.install\.iso))["\']', html)
            if m:
                return {"Version": m.group(3), "Url": m.group(1), "Filename": m.group(2)}
            m_gen = re.search(r'href=["\']([^"\']*(Rockstor-[^"\']*?-generic\.x86_64-([0-9.-]+)\.install\.iso))["\']', html)
            if m_gen:
                return {"Version": m_gen.group(3), "Url": m_gen.group(1), "Filename": m_gen.group(2)}
        return {
            "Version": "5.1.0-0",
            "Url": "https://rockstor.com/downloads/installer/leap/15.6/x86_64/Rockstor-Leap15.6-generic.x86_64-5.1.0-0.install.iso",
            "Filename": "Rockstor-Leap15.6-generic.x86_64-5.1.0-0.install.iso",
        }

    # --- 03 Security & Pentest ---
    def scrape_kali_linux(self) -> Optional[Dict[str, Any]]:
        mirrors = [
            "https://ftp.halifax.rwth-aachen.de/kali-images/current/",
            "https://cdimage.kali.org/current/",
        ]
        for base in mirrors:
            html = self.dm.get_web_content(base)
            if html:
                m = re.search(r'href=[\"\'](kali-linux-(\d{4}\.\d+)-installer-amd64\.iso)[\"\']', html)
                if m:
                    return {
                        "Version": m.group(2),
                        "Url": f"{base}{m.group(1)}",
                        "Filename": m.group(1),
                    }
        return None

    def scrape_blackarch_linux(self) -> Optional[Dict[str, Any]]:
        html = self.dm.get_web_content("https://ftp.halifax.rwth-aachen.de/blackarch/iso/")
        if html:
            m = re.search(r'href="(blackarch-linux-full-(\d{4}\.\d{2}\.\d{2})-x86_64\.iso)"', html)
            if m:
                return {
                    "Version": m.group(2),
                    "Url": f"https://ftp.halifax.rwth-aachen.de/blackarch/iso/{m.group(1)}",
                    "Filename": m.group(1),
                }
        return None

    def scrape_backbox_linux(self) -> Optional[Dict[str, Any]]:
        base_url = "http://ftp.halifax.rwth-aachen.de/backbox/"
        html = self.dm.get_web_content(base_url)
        if html:
            matches = re.findall(r'href=[\"\'](backbox-(\d+)-desktop-amd64\.iso)[\"\']', html)
            if matches:
                matches.sort(key=lambda x: int(x[1]), reverse=True)
                fn, ver = matches[0]
                return {
                    "Version": ver,
                    "Url": f"{base_url}{fn}",
                    "Filename": fn,
                    "ChecksumUrl": f"{base_url}{fn}.sha256",
                }
        return None

    scrape_backbox = scrape_backbox_linux

    def scrape_kodachi_os(self) -> Optional[Dict[str, Any]]:
        html = self.dm.get_web_content("https://kodachi.cloud/downloads/")
        if html:
            m = re.search(r'kodachi-os-xfce-(\d+\.\d+\.\d+)-amd64\.iso', html)
            if m:
                ver = m.group(1)
                fn = f"kodachi-os-xfce-{ver}-amd64.iso"
                url = "https://kodachi.cloud/downloads/download.php?f=xfce-iso"
                chk = f"https://kodachi.cloud/downloads/installers/desktop/{fn}.sha256"
                return {"Version": ver, "Url": url, "Filename": fn, "ChecksumUrl": chk}
        return {
            "Version": "10.0.3",
            "Url": "https://kodachi.cloud/downloads/download.php?f=xfce-iso",
            "Filename": "kodachi-os-xfce-10.0.3-amd64.iso",
            "ChecksumUrl": "https://kodachi.cloud/downloads/installers/desktop/kodachi-os-xfce-10.0.3-amd64.iso.sha256"
        }

    def scrape_parrot_security(self) -> Optional[Dict[str, Any]]:
        for base in ["https://deb.parrot.sh/parrot/iso/", "https://download.parrot.sh/parrot/iso/"]:
            html = self.dm.get_web_content(base)
            if html:
                dirs = [m[0] for m in re.findall(r'href="(\d+\.\d+(\.\d+)?)/"', html)]
                for d in sorted(dirs, key=version_sort_key, reverse=True)[:3]:
                    sub = self.dm.get_web_content(f"{base}{d}/")
                    if sub:
                        m = re.search(r'href="(Parrot-security-[^"]*?amd64\.iso)"', sub)
                        if m:
                            return {"Version": d, "Url": f"{base}{d}/{m.group(1)}", "Filename": m.group(1)}
        return None

    def scrape_caine_live_forensic__autopsy(self) -> Optional[Dict[str, Any]]:
        html = self.dm.get_web_content("https://www.caine-live.net/page5/page5.html")
        if html:
            m = re.search(r'href="https://www\.caine-live\.net/Downloads/(caine(\d+(\.\d+)?)\.iso)"', html)
            if m:
                fn = m.group(1)
                ver = m.group(2)
                return {
                    "Version": ver,
                    "Url": f"https://caine.mirror.garr.it/caine/{fn}",
                    "Filename": fn,
                    "ChecksumUrl": f"https://www.caine-live.net/page5/{fn}.sha256.txt",
                }
        return None

    # --- 04 Rescue Systeme ---
    def scrape_tiny_core_linux(self) -> Optional[Dict[str, Any]]:
        for base in ["http://tinycorelinux.net/16.x/x86_64/release/", "http://tinycorelinux.net/15.x/x86_64/release/"]:
            html = self.dm.get_web_content(base)
            if html:
                m = re.search(r'href="(CorePure64-(\d+\.\d+)\.iso)"', html)
                if m:
                    return {"Version": m.group(2), "Url": f"{base}{m.group(1)}", "Filename": m.group(1)}
        return None

    def scrape_rescuezilla(self) -> Optional[Dict[str, Any]]:
        api = self.dm.get_web_content("https://api.github.com/repos/rescuezilla/rescuezilla/releases/latest")
        if api:
            try:
                rel = json.loads(api)
                tag = rel["tag_name"].lstrip("v")
                for a in rel.get("assets", []):
                    if a.get("name", "").endswith(".iso"):
                        return {"Version": tag, "Url": a["browser_download_url"], "Filename": a["name"]}
            except Exception:
                pass
        return None

    def scrape_gparted_live(self) -> Optional[Dict[str, Any]]:
        html = self.dm.get_web_content("https://gparted.org/download.php")
        if html:
            m = re.search(r'href="(https://[^"]*?gparted-live-(\d+\.\d+\.\d+-\d+)-amd64\.iso)"', html)
            if m:
                fn = f"gparted-live-{m.group(2)}-amd64.iso"
                return {"Version": m.group(2), "Url": m.group(1), "Filename": fn}
        return None

    def scrape_fygoos_pe(self) -> Optional[Dict[str, Any]]:
        html = self.dm.get_web_content("https://www.fygonas.com/download")
        if html:
            matches = re.findall(r'([^"\' ]*?fygoos_PE_x86[^"\' ]*?(\d+\.\d+[^"\' ]*)\.iso)', html)
            if matches:
                url, ver = matches[0]
                if url.startswith("//"):
                    url = "https:" + url
                elif not url.startswith("http"):
                    url = "https://www.fygonas.com" + url
                return {"Version": ver, "Url": url, "Filename": f"fygoos_PE_x86_{ver}.iso"}
        return {
            "Version": "1.2.0604_2686",
            "Url": "https://download.liveupdate.fygonas.com/x86_64/trim/fygoos_PE_x86_1.2.0604_2686.iso",
            "Filename": "fygoos_PE_x86_1.2.0604_2686.iso",
        }

    def scrape_netbootxyz(self) -> Optional[Dict[str, Any]]:
        api = self.dm.get_web_content("https://api.github.com/repos/netbootxyz/netboot.xyz/releases/latest")
        if api:
            try:
                rel = json.loads(api)
                tag = rel["tag_name"].lstrip("v")
                for a in rel.get("assets", []):
                    if a.get("name", "") == "netboot.xyz.iso":
                        return {"Version": tag, "Url": a["browser_download_url"], "Filename": "netboot.xyz.iso"}
            except Exception:
                pass
        return None

    def scrape_systemrescue_ehem_systemrescuecd(self) -> Optional[Dict[str, Any]]:
        html = self.dm.get_web_content("https://www.system-rescue.org/Download/")
        if html:
            m = re.search(r'(https://fastly-cdn\.system-rescue\.org/releases/(\d+\.\d+(\.\d+)?)/(systemrescue-\d+\.\d+(\.\d+)?-amd64\.iso))', html)
            if m:
                return {"Version": m.group(2), "Url": m.group(1), "Filename": m.group(4)}
            m2 = re.search(r"systemrescue-(\d+\.\d+(\.\d+)?)-amd64\.iso", html)
            if m2:
                ver = m2.group(1)
                fn = f"systemrescue-{ver}-amd64.iso"
                return {"Version": ver, "Url": f"https://fastly-cdn.system-rescue.org/releases/{ver}/{fn}", "Filename": fn}
        return None

    def scrape_rescatux(self) -> Optional[Dict[str, Any]]:
        js = self.dm.get_web_content("https://sourceforge.net/projects/rescatux/best_release.json")
        if js:
            try:
                obj = json.loads(js)
                fn_path = obj.get("release", {}).get("filename", "")
                m = re.search(r"rescatux-([0-9.]+)\.iso$", fn_path)
                if m:
                    fn = Path(fn_path).name
                    return {
                        "Version": m.group(1),
                        "Url": f"https://downloads.sourceforge.net/project/rescatux{fn_path}",
                        "Filename": fn,
                    }
            except Exception:
                pass
        return {
            "Version": "0.74",
            "Url": "https://downloads.sourceforge.net/project/rescatux/rescatux-0.74/rescatux-0.74.iso",
            "Filename": "rescatux-0.74.iso",
        }

    def scrape_kaspersky_rescue_disk(self) -> Optional[Dict[str, Any]]:
        return {
            "Version": "2024",
            "Url": "https://rescuedisk.s.kaspersky-labs.com/updatable/2024/krd.iso",
            "Filename": "krd.iso",
        }

    def scrape_eset_sysrescue_live(self) -> Optional[Dict[str, Any]]:
        return {
            "Version": "2024.05",
            "Url": "https://archive.org/download/eset_sysrescue_live_enu_202405/eset_sysrescue_live_enu.iso",
            "Filename": "eset_sysrescue_live_enu.iso",
        }

    def scrape_clonezilla_live(self) -> Optional[Dict[str, Any]]:
        chk = self.dm.get_web_content("https://clonezilla.org/downloads/stable/data/CHECKSUMS.TXT")
        if chk:
            m = re.search(r"clonezilla-live-(\d+\.\d+\.\d+-\d+)-amd64\.iso", chk)
            if m:
                fn = m.group(0)
                ver = m.group(1)
                url = f"https://downloads.sourceforge.net/project/clonezilla/clonezilla_live_stable/{ver}/{fn}"
                return {
                    "Version": ver,
                    "Url": url,
                    "Filename": fn,
                    "ChecksumUrl": "https://clonezilla.org/downloads/stable/data/CHECKSUMS.TXT",
                }
        return None

    def scrape_drweb_livedisk(self) -> Optional[Dict[str, Any]]:
        html = self.dm.get_web_content("https://free.drweb.com/livedisk/")
        if html:
            m = re.search(r"(https://cdn-download\.drweb\.com/pub/drweb/livedisk/(drweb-livedisk-(\d+)-cd\.iso))", html)
            if m:
                url = m.group(1)
                fn = m.group(2)
                ver = m.group(3)
                return {"Version": ver, "Url": url, "Filename": fn, "ChecksumUrl": f"{url}.md5"}
        return {
            "Version": "900",
            "Url": "https://cdn-download.drweb.com/pub/drweb/livedisk/drweb-livedisk-900-cd.iso",
            "Filename": "drweb-livedisk-900-cd.iso",
            "ChecksumUrl": "https://cdn-download.drweb.com/pub/drweb/livedisk/drweb-livedisk-900-cd.iso.md5",
        }

    # --- 05 BSD & Unix ---
    def scrape_freebsd(self) -> Optional[Dict[str, Any]]:
        base = "https://download.freebsd.org/releases/ISO-IMAGES/"
        html = self.dm.get_web_content(base)
        if html:
            matches = [m for m in re.findall(r'href="(\d+\.\d+)/"', html)]
            for v in sorted(matches, key=version_sort_key, reverse=True)[:3]:
                sub = self.dm.get_web_content(f"{base}{v}/")
                if sub:
                    m = re.search(r'href="(FreeBSD-[^"]*?-RELEASE-amd64-disc1\.iso)"', sub)
                    if m:
                        return {"Version": v, "Url": f"{base}{v}/{m.group(1)}", "Filename": m.group(1)}
        return None

    def scrape_openbsd(self) -> Optional[Dict[str, Any]]:
        base = "https://cdn.openbsd.org/pub/OpenBSD/"
        html = self.dm.get_web_content(base)
        if html:
            matches = re.findall(r'href="(\d+\.\d+)/"', html)
            for v in sorted(matches, key=version_sort_key, reverse=True)[:3]:
                sub = self.dm.get_web_content(f"{base}{v}/amd64/")
                if sub:
                    m = re.search(r"install(\d+)\.iso", sub)
                    if m:
                        fn = m.group(0)
                        return {
                            "Version": v,
                            "Url": f"{base}{v}/amd64/{fn}",
                            "Filename": fn,
                            "ChecksumUrl": f"{base}{v}/amd64/SHA256",
                        }
        return None

    def scrape_netbsd(self) -> Optional[Dict[str, Any]]:
        base = "https://cdn.netbsd.org/pub/NetBSD/images/"
        html = self.dm.get_web_content(base)
        if html:
            matches = [m[0] for m in re.findall(r'href="(\d+\.\d+(\.\d+)?)/"', html)]
            for v in sorted(matches, key=version_sort_key, reverse=True)[:3]:
                sub = self.dm.get_web_content(f"{base}{v}/")
                if sub:
                    m = re.search(rf"(NetBSD-{re.escape(v)}-amd64\.iso)", sub)
                    if m:
                        fn = m.group(1)
                        return {
                            "Version": v,
                            "Url": f"{base}{v}/{fn}",
                            "Filename": fn,
                            "ChecksumUrl": f"https://archive.netbsd.org/pub/NetBSD-archive/images/{v}/SHA512",
                        }
        return None

    def scrape_dragonfly_bsd(self) -> Optional[Dict[str, Any]]:
        base = "https://mirror.checkdomain.de/dragonflybsd/iso-images/"
        html = self.dm.get_web_content(base)
        if html:
            matches = re.findall(r'href="(dfly-x86_64-([\d\.]+)_REL\.iso)"', html)
            if matches:
                latest = sorted(matches, key=lambda x: version_sort_key(x[1]), reverse=True)[0]
                fn = latest[0]
                ver = latest[1]
                return {
                    "Version": ver,
                    "Url": f"{base}{fn}",
                    "Filename": fn,
                    "ChecksumUrl": f"{base}md5.txt",
                }
        return None

    # --- 04 Rescue Systeme & Windows PE (Erweiterung) ---
    def scrape_hirens_bootcd_pe(self) -> Optional[Dict[str, Any]]:
        html = self.dm.get_web_content("https://www.hirensbootcd.org/download/")
        dl_url = "https://www.hirensbootcd.org/files/HBCD_PE_x64.iso"
        if html:
            m = re.search(r'href=["\'](https?://[^\s"\']*?HBCD_PE_x64\.iso)["\']', html)
            if m:
                dl_url = m.group(1)
            vm = re.search(r'v(\d+\.\d+(\.\d+)?)', html)
            ver = vm.group(1) if vm else "1.0.8"
            return {"Version": ver, "Url": dl_url, "Filename": "HBCD_PE_x64.iso"}
        return {"Version": "1.0.8", "Url": dl_url, "Filename": "HBCD_PE_x64.iso"}

    def scrape_bootrepairdisk(self) -> Optional[Dict[str, Any]]:
        rss = self.dm.get_web_content("https://sourceforge.net/projects/boot-repair-cd/rss?path=/")
        if rss:
            try:
                import xml.etree.ElementTree as ET
                root = ET.fromstring(rss)
                for item in root.findall(".//item"):
                    t = item.find("title").text or ""
                    l = item.find("link").text or ""
                    if "64bit.iso" in t:
                        fn = t.strip("/").split("/")[-1]
                        vm = re.search(r"(\d{4}[-.]\d{2}[-.]\d{2})", fn)
                        ver = vm.group(1) if vm else "latest"
                        return {"Version": ver, "Url": l, "Filename": fn, "SkipHashCheck": True}
            except Exception:
                pass
        return {
            "Version": "latest",
            "Url": "https://sourceforge.net/projects/boot-repair-cd/files/boot-repair-disk-64bit.iso/download",
            "Filename": "boot-repair-disk-64bit.iso",
            "SkipHashCheck": True,
        }

    def scrape_super_grub2_disk(self) -> Optional[Dict[str, Any]]:
        rss = self.dm.get_web_content("https://sourceforge.net/projects/supergrub2/rss?path=/")
        if rss:
            try:
                import xml.etree.ElementTree as ET
                root = ET.fromstring(rss)
                for item in root.findall(".//item"):
                    t = item.find("title").text or ""
                    l = item.find("link").text or ""
                    if t.endswith(".iso") and "multiarch" in t:
                        fn = t.strip("/").split("/")[-1]
                        vm = re.search(r"supergrub2-classic-([0-9a-zA-Z.]+)-multiarch", fn)
                        ver = vm.group(1) if vm else "2.06s4"
                        return {"Version": ver, "Url": l, "Filename": fn}
            except Exception:
                pass
        return {
            "Version": "2.06s4",
            "Url": "https://downloads.sourceforge.net/project/supergrub2/2.06s4/super_grub2_disk_2.06s4/supergrub2-classic-2.06s4-multiarch-CD.iso",
            "Filename": "supergrub2-classic-2.06s4-multiarch-CD.iso"
        }

    def scrape_ultimate_boot_cd_ubcd(self) -> Optional[Dict[str, Any]]:
        mirrors = [
            "https://mirror.koddos.net/ubcd/ubcd539.iso",
            "https://mirror.clientvps.com/ubcd/ubcd539.iso",
            "https://mirror.vcu.edu/pub/windows/ubcd/ubcd539.iso",
            "http://mirror.sysadminguide.net/ubcd/ubcd539.iso",
            "https://archive.org/download/ubcd539_202306/ubcd539.iso",
        ]
        sha256 = "054c6d41cfe169de8ca93a084612793ecdacb401fb827b174d155966289f6f1b"
        for m in mirrors:
            try:
                r = requests.head(m, headers={"User-Agent": self.dm.user_agent}, timeout=4, allow_redirects=True)
                if r.status_code == 200 and int(r.headers.get("content-length", 0)) > 500_000_000:
                    return {
                        "Version": "5.3.9",
                        "Url": m,
                        "Filename": "ubcd539.iso",
                        "Sha256": sha256,
                    }
            except Exception:
                continue
        return {
            "Version": "5.3.9",
            "Url": "https://mirror.koddos.net/ubcd/ubcd539.iso",
            "Filename": "ubcd539.iso",
            "Sha256": sha256,
        }

    def scrape_shredos_disk_sanitizer(self) -> Optional[Dict[str, Any]]:
        raw = self.dm.get_web_content("https://api.github.com/repos/PartialVolume/shredos.x86_64/releases/latest")
        if raw:
            try:
                data = json.loads(raw)
                ver = data.get("tag_name", "").lstrip("v")
                candidates = []
                for a in data.get("assets", []):
                    name = a.get("name", "")
                    if (name.endswith(".iso") or name.endswith(".img")) and "x86-64" in name and "lite" not in name and "plus-partition" not in name:
                        candidates.append((0 if name.endswith(".iso") else 1, {
                            "Version": ver,
                            "Url": a.get("browser_download_url"),
                            "Filename": name
                        }))
                if candidates:
                    candidates.sort(key=lambda x: x[0])
                    return candidates[0][1]
            except Exception:
                pass
        return {
            "Version": "0.43.1",
            "Url": "https://github.com/PartialVolume/shredos.x86_64/releases/download/v2025.11_32_x86-64_0.43.1/shredos-2025.11_32_x86-64_v0.43.1_20261010.iso",
            "Filename": "shredos-2025.11_32_x86-64_v0.43.1_20261010.iso"
        }

    def scrape_foxclone_backup__system_restore(self) -> Optional[Dict[str, Any]]:
        base_url = "https://www.foxclone.org"
        html = self.dm.get_web_content(f"{base_url}/downloads.html")
        if html:
            matches = re.findall(r'href=[\"\'](/downloads/foxclone(\d+)-noble\.iso)[\"\']', html)
            if matches:
                matches.sort(key=lambda x: int(x[1]), reverse=True)
                rel_path, ver = matches[0]
                fn = f"foxclone{ver}-noble.iso"
                return {
                    "Version": ver,
                    "Url": f"{base_url}{rel_path}",
                    "Filename": fn,
                }
        return None

    scrape_foxclone = scrape_foxclone_backup__system_restore

    def scrape_grml_live_linux_for_sysadmins(self) -> Optional[Dict[str, Any]]:
        base_url = "https://download.grml.org/"
        html = self.dm.get_web_content(base_url)
        if html:
            matches = re.findall(r'href=[\"\'](grml-full-(\d{4}\.\d{2})-amd64\.iso)[\"\']', html)
            if matches:
                matches.sort(key=lambda x: x[1], reverse=True)
                fn, ver = matches[0]
                return {
                    "Version": ver,
                    "Url": f"{base_url}{fn}",
                    "Filename": fn,
                    "ChecksumUrl": f"{base_url}{fn}.sha256",
                }
        return None

    scrape_grml = scrape_grml_live_linux_for_sysadmins


# ==============================================================================
# PRETTY ISO NAMES & THEMES
# ==============================================================================
def get_pretty_iso_name(filename: str) -> str:
    """Erzeugt formatierte Anzeigenamen für das Ventoy-Menü."""
    fn_lower = filename.lower()
    mapping = [
        # Rettungs-, Notfall- & Antiviren-Systeme
        (r"desinfec'?t", "c't Desinfec't (Antivirus & Notfallsystem)"),
        ("clonezilla", "Clonezilla Live Disk Backup"),
        ("caine", "CAINE Live Digital Forensics & TSK"),
        ("drweb", "Dr.Web LiveDisk Antivirus"),
        ("krd", "Kaspersky Rescue Disk"),
        ("eset_sysrescue", "ESET SysRescue Live"),
        (r"hbcd|hiren", "Hiren's BootCD PE (Windows Recovery Environment)"),
        (r"boot-repair", "Boot-Repair-Disk (GRUB & EFI Repair)"),
        (r"super_?grub", "Super Grub2 Disk (Multi-Boot Rescue)"),
        (r"ubcd", "Ultimate Boot CD (Diagnostic Suite)"),
        (r"shredos", "ShredOS (Disk Sanitizer & DoD Wipe)"),
        ("rescatux", "Rescatux Boot & GRUB Repair"),
        ("rescuezilla", "Rescuezilla Recovery"),
        ("systemrescue", "SystemRescue (ehem. SystemRescueCd)"),
        ("gparted", "GParted Live Partition Editor"),
        ("fygoos", "FygoOS PE Rescue"),
        (r"netboot\.xyz", "netboot.xyz Multi-Boot"),
        (r"memtest|mt86plus", "MemTest86+ (RAM Diagnostic Tool)"),
        (r"pts-desktop-live|phoronix", "Phoronix Test Suite Live"),
        (r"acronis", "Acronis Cyber Protect / True Image Rescue"),
        (r"macrium|reflect", "Macrium Reflect Rescue PE"),
        (r"aomei", "AOMEI Backupper & Partition Assistant"),
        (r"easeus", "EaseUS Partition Master / Todo Backup"),
        (r"winpe|windows[-_ ]?pe", "Windows PE Recovery Environment"),
        ("redorescue", "Redo Rescue (Point & Click Backup & Restore)"),
        ("foxclone", "Foxclone (Backup & Partition Clone)"),
        ("grml", "Grml Live Linux (Sysadmin & Recovery)"),

        # BSD & Unix
        (r"openbsd|install\d+\.iso", "OpenBSD Release"),
        ("netbsd", "NetBSD Release"),
        (r"dfly|dragonfly", "DragonFly BSD Release"),
        ("freebsd", "FreeBSD Release"),
        ("ghostbsd", "GhostBSD (FreeBSD Desktop & MATE)"),
        ("opnsense", "OPNsense Firewall & Security Platform"),

        # Desktop Linux (Alle 36 Systeme)
        ("alpine", "Alpine Linux Standard"),
        ("antix", "antiX Linux Full"),
        ("archlinux", "Arch Linux"),
        ("bazzite", "Bazzite (SteamOS Gaming Platform)"),
        ("cachyos", "CachyOS Desktop Linux"),
        (r"cld.*x86_64", "Calculate Linux Desktop KDE"),
        ("crux", "CRUX Linux"),
        ("debian", "Debian GNU/Linux"),
        ("devuan", "Devuan GNU/Linux"),
        ("elementaryos", "elementary OS"),
        ("endeavouros", "EndeavourOS Linux"),
        ("fedora", "Fedora Workstation Live"),
        ("garuda", "Garuda Linux Dr460nized"),
        (r"livegui|gentoo", "Gentoo Live GUI"),
        ("neon-user", "KDE neon (Bleeding Edge Plasma Desktop)"),
        ("kubuntu", "Kubuntu Desktop (KDE Plasma)"),
        ("linux-lite", "Linux Lite"),
        ("linuxmint", "Linux Mint Cinnamon"),
        ("lubuntu", "Lubuntu Desktop"),
        ("mageia", "Mageia Linux"),
        ("manjaro", "Manjaro Linux XFCE"),
        (r"mx-.*xfce", "MX Linux Xfce"),
        (r"nixos.*graphical", "NixOS Graphical"),
        ("nobara", "Nobara Project (Gaming & Multimedia)"),
        ("omarchy", "Omarchy Linux"),
        (r"opensuse.*tumbleweed", "openSUSE Tumbleweed"),
        ("pop-os", "Pop!_OS"),
        ("q4os", "Q4OS Desktop (Debian Fast & Lightweight)"),
        ("slackware", "Slackware Linux DVD"),
        (r"solus.*budgie", "Solus Budgie"),
        ("tuxedo", "TUXEDO OS (KDE Plasma & Hardware Tuning)"),
        ("ubuntucinnamon", "Ubuntu Cinnamon"),
        (r"ubuntu.*live-server", "Ubuntu Server LTS"),
        ("ubuntu", "Ubuntu Desktop"),
        ("void-live", "Void Linux XFCE"),
        ("winux", "Winux (Windows 11 UI & Wine/Proton)"),
        ("zorin", "Zorin OS"),

        # Enterprise Server & NAS
        ("almalinux", "AlmaLinux Enterprise"),
        (r"azurelinux|azure-linux|mariner", "Azure Linux (Microsoft Cloud & Edge)"),
        ("centos", "CentOS Stream"),
        ("openmediavault", "OpenMediaVault NAS"),
        ("oraclelinux", "Oracle Linux Enterprise (UEK)"),
        ("zimaos", "ZimaOS Storage & Cloud"),
        (r"truenas|freenas", "FreeNAS / TrueNAS SCALE"),
        (r"proxmox.*backup", "Proxmox Backup Server (PBS)"),
        ("proxmox", "Proxmox VE Hypervisor"),
        ("rocky", "Rocky Linux"),
        ("rockstor", "Rockstor Btrfs NAS"),
        ("xcp-ng", "XCP-ng Hypervisor (Enterprise Virtualization)"),

        # Security & Pentest
        ("athenaos", "Athena OS (Cybersecurity & Pentesting)"),
        ("backbox", "BackBox Linux (Ethical Hacking & Pentest)"),
        ("blackarch", "BlackArch Linux (Full)"),
        ("kali", "Kali Linux Security"),
        ("kodachi", "Kodachi OS (Anonymous Anti-Forensic Live)"),
        ("parrot", "Parrot Security OS"),
        ("tails", "Tails (The Amnesic Incognito Live System)"),
        ("qubes", "Qubes OS (Security by Isolation)"),

        # Spezial & Leichtgewichtig
        ("corepure64", "Tiny Core Linux Pure64"),
        ("knoppix", "Knoppix Live Linux"),
        (r"pup(py)?64|fossapup|bionicpup|bookwormpup", "Puppy Linux (Ultra-Lightweight)"),
        ("opnsense", "OPNsense Firewall & Security Platform"),
        ("pfsense", "pfSense Community Edition Firewall"),
        (r"win(dows)?[-_ ]?(10|11|server)", "Windows Setup & Installation"),
    ]
    for pattern, pretty in mapping:
        if re.search(pattern, fn_lower):
            return pretty

    # Intelligenter Fallback für unbekannte oder benutzerdefinierte ISOs
    clean = re.sub(r"\.(iso|img)$", "", filename, flags=re.IGNORECASE)
    clean = re.sub(r"[-_](x86[-_]64|amd64|x64|x86|i386|i686)", "", clean, flags=re.IGNORECASE)
    clean = re.sub(r"[-_](dvd\d*|disc\d*|cd\d*|live|desktop|release|install)", "", clean, flags=re.IGNORECASE)
    clean = re.sub(r"[-_]", " ", clean)
    clean = re.sub(r"\s+", " ", clean).strip()
    words = [w.capitalize() if not (w.isupper() or any(c.isdigit() for c in w)) else w for w in clean.split(" ")]
    return " ".join(words)


def get_iso_menu_tip(filename: str) -> str:
    """Liefert eine prägnante Kurzbeschreibung für das Ventoy-Menü (menu_tip Plugin)."""
    fn_lower = filename.lower()
    mapping = [
        # Rettungs-, Notfall- & Antiviren-Systeme
        (r"desinfec'?t", "c't Notfall-System mit 4 Virenscannern (ClamAV, ESET, WithSecure, Kaspersky) & Rettungswerkzeugen"),
        ("clonezilla", "Branchenstandard für Disk-Imaging, Partition-Cloning und Bare-Metal-Wiederherstellung"),
        ("caine", "Computer Aided Investigative Environment - Professionelle digitale IT-Forensik & Analyse"),
        ("drweb", "Dr.Web LiveDisk - Zuverlässiger Notfall-Virenscanner zur Rettung infizierter Windows/Linux-Systeme"),
        ("krd", "Kaspersky Rescue Disk - x64 Live-System zur Bereinigung tief sitzender Malware und Rootkits"),
        ("eset_sysrescue", "ESET SysRescue Live - On-Demand Antivirus-Scan direkt vom USB-Stick mit Cloud-Signaturen"),
        (r"hbcd|hiren", "Hiren's BootCD PE x64 (Windows 11 PE) - Umfassende Diagnostik-, Reparatur- und PW-Tools"),
        (r"boot-repair", "Automatische 1-Klick-Reparatur für beschädigte GRUB-, EFI- und Windows-Bootloader"),
        (r"super_?grub", "Startet jedes installierte Betriebssystem auch bei komplett zerstörtem MBR/EFI-Bootloader"),
        (r"ubcd", "Ultimate Boot CD - Legendäre Diagnose-Sammlung für Hardware, CPU, RAM, Festplatten & BIOS"),
        (r"shredos", "ShredOS - Sichere, zertifizierte Datenlöschung von NVMe/SSDs/HDDs nach DoD 5220.22-M"),
        ("rescatux", "Grafisches Rettungssystem: Windows-Kennwörter zurücksetzen, GRUB reparieren, Dateisysteme prüfen"),
        ("rescuezilla", "Einfache grafische Benutzeroberfläche für Clonezilla: Backup, Restore und Drive-Cloning"),
        ("systemrescue", "Schweizer Taschenmesser für Admins: GParted, fsck, ddrescue, TestDisk, rsync, smartctl"),
        ("gparted", "Grafischer Partitionsmanager: Partitionen verlustfrei vergrößern, verkleinern, verschieben, klonen"),
        ("fygoos", "FygoOS Rescue PE - Modernes Windows-PE-Notfallsystem für Systemreparaturen und Datensicherung"),
        (r"netboot\.xyz", "iPXE-Netzwerk-Bootloader zum Starten dutzender Betriebssysteme direkt aus dem Internet"),
        (r"memtest|mt86plus", "MemTest86+ - Der Industriestandard für gründliche RAM-Speicherdiagnose und Hardware-Tests"),
        (r"pts-desktop-live|phoronix", "Phoronix Test Suite Live - Automatisiertes Hardware-Benchmarking und Stresstests"),
        (r"acronis", "Acronis Cyber Protect / True Image - Professionelles Backup, Disk Cloning & Bare-Metal Restore"),
        (r"macrium|reflect", "Macrium Reflect Rescue PE - Zuverlässige Windows-Sicherung und Image-Wiederherstellung"),
        (r"aomei", "AOMEI Backupper & Partition Assistant - Festplatten klonen und Partitionen verwalten"),
        (r"easeus", "EaseUS Partition Master / Todo Backup - Partitionsverwaltung und Notfall-Recovery"),
        (r"winpe|windows[-_ ]?pe", "Windows Preinstallation Environment - Basis für Windows-Wartung, PE-Tools & Setup"),
        ("redorescue", "Point-and-Click Bare-Metal Backup und Restore für Festplatten und Partitionen"),
        ("foxclone", "Ventoy-optimiertes Backup- und Klon-System auf Ubuntu-Basis für NVMe-, SSD- und HDD-Images"),
        ("grml", "Debian-basiertes Notfall- & Diagnosesystem für Administratoren mit reichhaltiger Zsh-Toolbox"),

        # BSD & Unix
        (r"openbsd|install\d+\.iso", "Sicherheitsfokussiertes UNIX-Betriebssystem mit extrem sauberem Code und starker Kryptografie"),
        ("netbsd", "Ultra-portables, sauberes BSD-Unix - läuft auf nahezu jeder bekannten Hardware-Architektur"),
        (r"dfly|dragonfly", "Fortschrittliches BSD mit dem innovativen HAMMER2-Hochleistungs-Dateisystem"),
        ("freebsd", "Leistungsstarkes UNIX-OS für Server, Firewalls, ZFS-Speicher und anspruchsvolle Desktops"),
        ("ghostbsd", "Benutzerfreundliches Desktop-BSD auf FreeBSD-Basis mit vorkonfigurierter MATE-Umgebung"),
        ("opnsense", "Professionelle Open-Source-Firewall & Routing-Plattform mit IDS/IPS und modernem Web-GUI"),
        ("pfsense", "Führende Open-Source-Firewall und UTM-Sicherheitslösung für Netzwerke"),

        # Desktop Linux (Alle 36 Systeme)
        ("alpine", "Minimalistisches, ressourcenschonendes Linux mit musl libc und BusyBox - ideal für Container & Rescue"),
        ("antix", "Extrem leichtgewichtiges System ohne systemd - perfekt für älteste Hardware und Netbooks"),
        ("archlinux", "Rolling-Release-Distribution für Power-User mit neuester Software und Pacman-Paketmanager"),
        ("bazzite", "SteamOS-Alternative auf Fedora-Basis - Perfekt optimiert für PC-Gaming und Handhelds (Steam Deck)"),
        ("cachyos", "Ultra-performantes Arch-Linux mit x86-64-v3/v4 CPU-Optimierungen und BORE-Scheduler"),
        (r"cld.*x86_64", "Calculate Linux Desktop KDE - Schnelles Gentoo-basiertes Rolling-Release für den Produktiveinsatz"),
        ("crux", "Leichtgewichtige, quellcodebasierte Distribution für erfahrene Linux-Enthusiasten"),
        ("debian", "Das universelle Betriebssystem - Legendär für maximale Stabilität und riesiges Software-Repository"),
        ("devuan", "Debian-Fork ohne systemd - Maximale Wahlfreiheit für SysVinit, Runit oder OpenRC"),
        ("elementaryos", "Elegantes, macOS-inspiriertes Desktop-System mit Fokus auf Ästhetik und Privatsphäre"),
        ("endeavouros", "Benutzerfreundliches, schlankes Arch Linux mit einfacher GUI-Installation und starker Community"),
        ("fedora", "Innovatives System von Red Hat mit neuester GNOME-Version, Wayland und PipeWire als Standard"),
        ("garuda", "Performance-optimiertes Arch-Linux mit futuristischem Dr460nized-Design und Gaming-Tools"),
        (r"livegui|gentoo", "Source-basierte High-End-Distribution für maximale Compiler-Optimierung auf eigener Hardware"),
        ("neon-user", "Offizielle KDE-Distribution mit neuesten Plasma-Desktop-Features auf stabiler Ubuntu-LTS-Basis"),
        ("kubuntu", "Ubuntu mit KDE Plasma Desktop - Mächtige Personalisierung und vertraute Software-Basis"),
        ("linux-lite", "Einsteigerfreundliches, ressourcenschonendes System für den einfachen Umstieg von Windows 7/10"),
        ("linuxmint", "Beliebteste Desktop-Distribution: Extrem stabil, sofort einsatzbereit mit Cinnamon Desktop"),
        ("lubuntu", "Offizielles, extrem sparsames Ubuntu-Derivat mit leichtgewichtigem LXQt Desktop"),
        ("mageia", "Vielseitiges Mandriva-Nachfolgesystem mit bewährtem drakxtools-Kontrollzentrum"),
        ("manjaro", "Zugängliches Arch Linux mit automatischer Hardware-Erkennung und eigenen, getesteten Paket-Zweigen"),
        (r"mx-.*xfce", "Extrem beliebtes, stabiles Desktop-OS auf Debian-Basis mit einzigartigen MX-Admin-Tools"),
        (r"nixos.*graphical", "Deklaratives, reproduzierbares Linux-System mit unzerstörbaren Generations-Rollbacks"),
        ("nobara", "Fedora-Spezialedition von GloriousEggroll - Out-of-the-Box für Gaming, Wine, Proton & Streaming"),
        ("omarchy", "Arch-basiertes Live-System mit vorkonfigurierter Umgebung und praktischen Rettungstools"),
        (r"opensuse.*tumbleweed", "Führende Rolling-Release-Distribution mit zypper, YaST und automatischen Btrfs-Snapshots"),
        ("pop-os", "System76 OS für Entwickler, Kreative und Gamer mit modernem COSMIC Desktop und GPU-Support"),
        ("q4os", "Hochentwickeltes, schlankes Debian-System mit klassischem Trinity- (TDE) oder KDE-Plasma-Desktop"),
        ("slackware", "Die älteste noch gepflegte Linux-Distribution - Puristisch, transparent und Unix-nah"),
        (r"solus.*budgie", "Eigenständige Desktop-Distribution mit modernem Budgie Desktop und hoher Alltags-Geschwindigkeit"),
        ("tuxedo", "Optimiertes Desktop-Linux von TUXEDO Computers mit Tomte-Hardwareerkennung und KDE Plasma"),
        ("ubuntucinnamon", "Offizieller Ubuntu-Flavor mit der beliebten, traditionellen Cinnamon-Desktopumgebung"),
        (r"ubuntu.*live-server", "Führendes Cloud- und Server-Betriebssystem für Rechenzentren, Docker und K8s"),
        ("ubuntu", "Das weltweit bekannteste Linux-System für Desktop und Workstation mit langer LTS-Unterstützung"),
        ("void-live", "Unabhängige Rolling-Release-Distribution mit dem blitzschnellen XBPS-Paketmanager und Runit"),
        ("winux", "Windows-11-Lookalike-Linux - Speziell für Windows-Umsteiger mit nahtloser Wine/Proton-Integration"),
        ("zorin", "Design-Preisträger für Windows/macOS-Umsteiger mit anpassbarem Desktop-Layout"),

        # Enterprise Server & NAS
        ("almalinux", "1:1 binärkompatibler RHEL-Ersatz der Open Source Community für Produktivserver"),
        (r"azurelinux|azure-linux|mariner", "Microsofts Enterprise-Linux für Azure-Infrastruktur, Edge-Geräte und AKS"),
        ("centos", "Upstream-Entwicklungszweig direkt vor Red Hat Enterprise Linux"),
        ("openmediavault", "Leistungsfähige Debian-basierte Network Attached Storage (NAS) Lösung mit WebGUI"),
        ("oraclelinux", "Hochleistungsfähiges Enterprise-Linux mit Unbreakable Enterprise Kernel (UEK) von Oracle"),
        ("zimaos", "Moderne Personal Cloud & NAS-Plattform für Medienserver, Docker und File-Sharing"),
        (r"truenas|freenas", "Führende Enterprise-Speicherlösung mit OpenZFS, NFS/SMB, Snapshots und Container-Apps"),
        (r"proxmox.*backup", "Proxmox Backup Server (PBS) - Deduplizierte, verschlüsselte und inkrementelle Backups für PVE"),
        ("proxmox", "Führende Open-Source-Virtualisierungsplattform für KVM-Hypervisor und LXC-Container"),
        ("rocky", "Von CentOS-Gründer Gregory Kurtzer geschaffener, 100% kompatibler RHEL-Enterprise-Nachfolger"),
        ("rockstor", "Spezialisierte Btrfs-basierte private Cloud & NAS-Speicherlösung"),
        ("xcp-ng", "Turnkey Open-Source-Hypervisor auf Xen-Basis für unternehmensweite Virtualisierung"),

        # Security & Pentest
        ("athenaos", "Next-Gen Cybersecurity-OS auf Arch-Basis mit themenbasierten Pentest-Rollen & Hack The Box"),
        ("backbox", "Ubuntu-basiertes Security-OS für Penetrationstests, Schwachstellenanalysen und Forensik"),
        ("blackarch", "Umfassendste Pentesting-Distribution der Welt mit über 2800 vorinstallierten Hacking-Tools"),
        ("kali", "Weltweiter Standard für Penetration Testing, Ethical Hacking und Incident Response"),
        ("kodachi", "Spezialisiert auf Anonymität und Anti-Forensik mit integriertem VPN, Tor und DNSCrypt"),
        ("parrot", "Vollwertige Sicherheits-Suite für Pentesting, Forensik, Reverse Engineering und Entwicklung"),
        ("tails", "Live-Betriebssystem für absolute Privatsphäre und Zensurumgehung via Tor-Netzwerk"),
        ("qubes", "Hochsicherheits-OS: Isoliert Anwendungen strikt in separaten virtuellen Xen-Maschinen"),

        # Spezial & Leichtgewichtig
        ("corepure64", "Ultra-kompaktes x86_64-Linux (nur ~25 MB) - Bootet komplett in den Arbeitsspeicher"),
        ("knoppix", "Der Urvater aller Live-Linux-Distributionen mit riesiger Software- und Treiber-Ausstattung"),
        (r"pup(py)?64|fossapup|bionicpup|bookwormpup", "Blitzschnelles Leichtgewicht: Lädt komplett in den RAM und rettet alte PCs"),
        (r"win(dows)?[-_ ]?(10|11|server)", "Offizielles Windows Installations- und Wiederherstellungs-Setup"),
    ]
    for pattern, tip in mapping:
        if re.search(pattern, fn_lower):
            return tip

    return f"ISO-Image: {filename}"



def get_ventoy_theme_definitions() -> Dict[str, Dict[str, Any]]:
    """Gibt die 7 integrierten Ventoy-Themes zurück."""
    return {
        "1": {
            "key": "moderndark",
            "name": "Modern Dark",
            "desc": "Slate Blue & Cyan (Modern, aufgeräumt & Blade Runner 2049 Artwork)",
            "title": "VENTOY MULTIBOOT SYSTEM MANAGER",
            "title_color": "#38bdf8",
            "bg1": "#0f172a",
            "bg2": "#1e1e2e",
            "header": "#1e293b",
            "accent": "#38bdf8",
            "text": "#94a3b8",
            "sel_bg": "#38bdf8",
            "sel_fg": "#0f172a",
            "image_url": "https://m.media-amazon.com/images/M/MV5BMTU5NTkwNTA2NF5BMl5BanBnXkFtZTgwMjQ5MjY2MzI@.jpg",
        },
        "2": {
            "key": "matrix",
            "name": "Matrix Hacker Terminal",
            "desc": "Nerdig, tiefes Schwarz & Hackers (1995) Terminal-Phosphorgrün",
            "title": "ROOT@TERMINAL // MULTIBOOT MATRIX",
            "title_color": "#22c55e",
            "bg1": "#050a05",
            "bg2": "#0a170d",
            "header": "#0f2314",
            "accent": "#22c55e",
            "text": "#86efac",
            "sel_bg": "#22c55e",
            "sel_fg": "#050a05",
            "image_url": "https://m.media-amazon.com/images/M/MV5BYzc0OTAxOWQtMWUxNS00ZjAxLTlmODAtMzQyNzQ2NzJmODUzXkEyXkFqcGc@.jpg",
        },
        "3": {
            "key": "cybertech",
            "name": "Cyber Tech & Network",
            "desc": "Technik & Cyber-Infrastruktur, Hackers (1995) Electric Blue",
            "title": "CYBER-NET // MULTIBOOT NETWORK OS SUITE",
            "title_color": "#38bdf8",
            "bg1": "#020817",
            "bg2": "#0c1e3d",
            "header": "#0f274c",
            "accent": "#3b82f6",
            "text": "#93c5fd",
            "sel_bg": "#3b82f6",
            "sel_fg": "#020817",
            "image_url": "https://m.media-amazon.com/images/M/MV5BZmE2ZDQ2ZjYtYjMwMy00YWQ2LThmNTYtZWE0YmNkNDlhOTRkXkEyXkFqcGc@.jpg",
        },
        "4": {
            "key": "tuxamber",
            "name": "Tux Classic Linux",
            "desc": "Klassisch puristisches Distro-Thema (Anthrazit & Gold, bewusst OHNE Hintergrundbild)",
            "title": "TUX MULTIBOOT // LINUX SYSTEM REPOSITORY",
            "title_color": "#f59e0b",
            "bg1": "#18181b",
            "bg2": "#27272a",
            "header": "#2e2e33",
            "accent": "#f59e0b",
            "text": "#fde68a",
            "sel_bg": "#f59e0b",
            "sel_fg": "#18181b",
            "image_url": None,
        },
        "5": {
            "key": "crimson",
            "name": "Crimson Security & Audit",
            "desc": "Security & Pentest, Mr. Robot Blood Crimson Red Artwork",
            "title": "CRIMSON SECURITY // RED TEAM AUDIT & RECOVERY",
            "title_color": "#ef4444",
            "bg1": "#0c0505",
            "bg2": "#1f0a0a",
            "header": "#2e0f0f",
            "accent": "#ef4444",
            "text": "#fca5a5",
            "sel_bg": "#ef4444",
            "sel_fg": "#0c0505",
            "image_url": "https://m.media-amazon.com/images/M/MV5BMjI2MDY5Mzk4NV5BMl5BanBnXkFtZTgwMTUyMzk3MjE@.jpg",
        },
        "6": {
            "key": "synthwave",
            "name": "Synthwave Neon Retro",
            "desc": "80s Retro-Wave, Cyberpunk Hackers (1995) Hot Pink & Cyan Neon",
            "title": "SYNTHWAVE MULTIBOOT // RETRO-WAVE",
            "title_color": "#f472b6",
            "bg1": "#13071f",
            "bg2": "#280b3d",
            "header": "#381054",
            "accent": "#ec4899",
            "text": "#e879f9",
            "sel_bg": "#ec4899",
            "sel_fg": "#13071f",
            "image_url": "https://m.media-amazon.com/images/M/MV5BNjlhNDgxZWMtYWNjMy00NDE3LTlkNjEtNDYwNTQwNWViMDllXkEyXkFqcGc@.jpg",
        },
        "7": {
            "key": "darkglass42",
            "name": "Dark Glass 42",
            "desc": "Transluzentes Cyber-Hacker Glassbox-Design (127.0.0.1 Artwork, Dual-Glassbox mit Live-Info)",
            "title": "PROJECT 42  //  CYBER LINUX MULTIBOOT SUITE",
            "title_color": "#73d4b8",
            "bg1": "#0a0e17",
            "bg2": "#121824",
            "header": "#141c2b",
            "accent": "#73d4b8",
            "text": "#cbd5e1",
            "sel_bg": "#1e293b",
            "sel_fg": "#82ffd7",
            "image_url": "https://raw.githubusercontent.com/Pretrojaner/linux-iso-updater/main/ventoy_themes/darkglass42/background.png",
        },
    }


def hex_to_rgb(hex_code: str) -> Tuple[int, int, int]:
    h = hex_code.lstrip("#")
    return tuple(int(h[i : i + 2], 16) for i in (0, 2, 4))


class VentoyThemeManager:
    """Generiert Pillow-Grafiken und richtet theme.txt sowie ventoy.json ein."""

    def __init__(self, logger: Logger):
        self.logger = logger
        self.themes = get_ventoy_theme_definitions()

    def get_theme_by_choice(self, choice: Optional[str]) -> Dict[str, str]:
        if not choice:
            return self.themes["1"]
        c = str(choice).strip().lower()
        if c in self.themes:
            return self.themes[c]
        for t in self.themes.values():
            if t["key"] == c:
                return t
        return self.themes["1"]

    def select_theme_interactive(self, default_choice: str = "1") -> str:
        print(f"\n{Colors.CYAN}{'=' * 60}{Colors.RESET}")
        print(f"{Colors.CYAN} VENTOY THEME AUSWAHL (7 Themen){Colors.RESET}")
        print(f"{Colors.CYAN}{'=' * 60}{Colors.RESET}")

        for k, t in sorted(self.themes.items()):
            def_marker = f" {Colors.GREEN}[Aktuell / Standard]{Colors.RESET}" if (k == default_choice or t["key"] == default_choice) else ""
            print(f" {Colors.YELLOW}[{k}]{Colors.RESET} {Colors.WHITE}{t['name']}{Colors.RESET}{def_marker}")
            print(f"     {Colors.DARK_GRAY}{t['desc']}{Colors.RESET}")

        print("")
        try:
            choice = input(f"Bitte Nummer des Ventoy-Themes eingeben (1-7) [Standard: {default_choice}]: ").strip()
        except (KeyboardInterrupt, EOFError):
            print("")
            return default_choice

        if not choice:
            choice = default_choice
        for k, t in self.themes.items():
            if t["key"] == choice.lower():
                return k
        if choice not in self.themes:
            choice = "1"
        return choice

    def install_theme(self, ventoy_dir: Path, theme_choice: str = "1", force: bool = False, dry_run: bool = False) -> None:
        selected = self.get_theme_by_choice(theme_choice)

        if dry_run:
            self.logger.log(
                f"[DRY-RUN] Würde Ventoy-Theme '{selected['name']}' (1080p) auf '{ventoy_dir}' einrichten.",
                color=Colors.CYAN,
                level="INFO",
            )
            return

        theme_dir = ventoy_dir / "theme"
        bg_path = theme_dir / "background.png"
        sel_path = theme_dir / "select_c.png"
        theme_txt_path = theme_dir / "theme.txt"
        active_record_path = ventoy_dir / "theme_active.txt"

        if not force and active_record_path.exists():
            try:
                existing = active_record_path.read_text(encoding="utf-8").strip()
                if existing == selected["key"] and bg_path.exists() and sel_path.exists() and theme_txt_path.exists():
                    self.logger.log(
                        f"[VENTOY] Theme '{selected['name']}' ist bereits aktiv auf Ziel-Laufwerk.",
                        color=Colors.GREEN,
                        level="OK",
                    )
                    return
            except Exception:
                pass

        theme_dir.mkdir(parents=True, exist_ok=True)

        w, h = 1920, 1080
        temp_img_file = Path(tempfile.gettempdir()) / f"ventoy_bg_{int(time.time())}.jpg"
        img_downloaded = False
        try:
            if selected.get("image_url"):
                self.logger.log("[VENTOY] Lade Theme-Hintergrundbild herunter...", color=Colors.CYAN, level="THEME")
                try:
                    resp = requests.get(selected["image_url"], headers={"User-Agent": USER_AGENT}, timeout=30)
                    if resp.status_code == 200:
                        temp_img_file.write_bytes(resp.content)
                        img_downloaded = True
                        with Image.open(temp_img_file) as src_img:
                            bg_img = src_img.convert("RGB").resize((w, h), Image.Resampling.BICUBIC)
                            draw = ImageDraw.Draw(bg_img, "RGBA")

                            # Dezente halbtransparente Header- und Footer-Balken fuer Lesbarkeit
                            hdr_rgb = hex_to_rgb(selected["header"])
                            overlay_color = (hdr_rgb[0], hdr_rgb[1], hdr_rgb[2], 190)
                            draw.rectangle([0, 0, w, 80], fill=overlay_color)
                            draw.rectangle([0, 1020, w, h], fill=overlay_color)

                            accent_color = hex_to_rgb(selected["accent"])
                            draw.line([(0, 80), (w, 80)], fill=accent_color, width=3)
                            draw.line([(0, 1020), (w, 1020)], fill=accent_color, width=3)

                            bg_img.save(bg_path, format="PNG")
                            self.logger.log(f"[VENTOY] Hintergrundbild fuer '{selected['name']}' erfolgreich eingerichtet.", color=Colors.GREEN, level="OK")
                except Exception as dl_err:
                    self.logger.log(f"[VENTOY] Download des Theme-Bildes fehlgeschlagen: {dl_err}. Verwende Farbverlauf als Fallback.", color=Colors.YELLOW, level="WARNUNG")
            else:
                # Theme ohne Hintergrundbild (z. B. Tux Classic Linux bewusst ohne Hintergrund)
                if bg_path.exists():
                    try:
                        bg_path.unlink()
                    except Exception:
                        pass
                self.logger.log(f"[VENTOY] Theme '{selected['name']}' wird puristisch ohne Hintergrundbild eingerichtet.", color=Colors.CYAN, level="THEME")
        finally:
            # Heruntergeladenes Bild direkt loeschen
            if temp_img_file.exists():
                try:
                    temp_img_file.unlink()
                except Exception:
                    pass

        if selected["key"] in ("darkglass42", "medicatdark", "glass42"):
            # Dark Glass 42 9-Slice PNGs entpacken
            try:
                import gzip, base64
                b64_str = "H4sIAAAAAAAC/+2bW6+qypbHv8rJfrXTclXs5DxUQXFRAYuLCC8nCk7ugqKCdPq7d+Fae152dh89WVnrJLs1cQoq/xo1RvFz1Kia//1buT9c/hH+Z32If/uvv/2WrqFptdRCiStAHobtJsiNh0M0/IEi8IfXNzm058OB5BYIry3uoBixr8D7NyEGsH4LZAzuZ3PL5dEpn8dx/Pe///Yff/vW4v6Xt3j49S3+GzrZ/vImm1/f4q/3a/Pr/fpLW2z2xT48P8EB6i6Xf2tT7E2rPgyCK/S9TZPdXltGxDBV/Z1Y+Ni1ExYYwQGZAYOMpIcdtOopGBe1c2k7IZgcLtnYOHvjy5a/GMLImDA8B0kvhIo6s2a9m87Sizm9mtxo0gxNjfx9etBrzTxxLgeIOceD+daxi8UupvIQkx7K9ildWJ46+EdyTheDnnaAA2ABGRDnxGyAELkOfz4BIMnvLtVi8gFIEPkAAC0e9CAQRfKiAWz/4YRcrtxdilPyARARJh8AkEJ4j442xCOGUPvDCbk8+BY6bbBRs8DQD1FDQ0C/mIVhe2H3B19asZQ5mLnITArNlsqEGtviIClWK58bWZfu/n1X1cNldDqP34ruumdHi6FNJRgHVnse3fZrvXd4YTtrNu3/MQ6KNNqfnhgH8N5t9H0cmJtu5N3dsYGat9HJUeOQP0vUIlDW7X2ALu9jBPuFtxLGY2EM+gVe2cmuFzLA6JAMomwlLMdJ88ZmVom7ealReawpVw4Bs9QXcFt4+2NzH8G2uzatBS/6mvbZ7sOTdmvf7Jb4QzQ+P7I7p+52V/mWwRRmJB10aDoB5BVaeryIYq3H/TquHQRVW8TKBCzh2MtPuVOt0dXbBMHorZ9sNW4+6xa4yVfT3IiaXjuUQAVgzp+VRBLKYrSlamksHoVYZSuZW0h8rsWzmXddt6y/BXpZLnIFtKIYt0XpHq4FzMLphVGWRpTtnf0qVQxjlXQHPootj2KqQ0TtYVnsZlxQcKDO7GWvlGmQ3vsEUCE7uX3BpSh+8l/zM/z35n73378U90WrvJH7aEX52wzpgRLEbC422yhz/STjKFNNcOsrSbxG5TIEx2Q7jnGrS6AbKyvORRKkwBobsIQoY9aKlfucN9qCTBIk0JqTLi5W6pxvEhW1s4W+dEEFBEWoAgFwjdP+6Rg7709letgW/9hV3RN3yB3OIP3uqes6Gq2GN5SNJXuq5eyYgIoY+RZgCANllgY2nO88+RCs54XvWXwYFsX9gptcr+WE8hCtm6Vx3dl88u37PLfbgG8PqR3vVZj4zLmIRJgGXlTvMiqdTi9jLYV1IFHpul8bOqJbzKyrrZtMwnLt7HPe9dn65PdFrmXCSJM6zjwk51Chi0hB8V6hm91Bn+zJ9cSmq1+6k+F8560p3xZSTY0n5DttpDQzLZfzHTMvNDkxXBFKO5YcS+7FsOlMlxClSSG/zEgnHMzpdhvrGej0m9CSJ3mlOj2rWtOpOsMGMRle354ZF5Mw5UFW2xby3+0JS6tc2fMqUq3WTIVrxEbs8hD2y3J2C4ie6eT8sge3Za/dlhtyfUr3e4+n/E18Jtdnn3RRsDGysCxIH4rrLoW3QPEnvje/Rhs801Ltwwekn5/bJO9dvvvk4jOz85JNklAUumUGrsTn3M7rLmFfkxhBw3GodKtaVChV1yXDEzu/+Wp5j+eM8zfgqttcu2To8/L20WbIWnbg+TOtTKhIBZPlbXYJb+/xz3YMdd0rcrvs0UUXZ/1aLdrAntmkT8T+eTaMpSDVSZxITKVaIjFPImV2Wyuz647EFH+zP3aV5Ere77fKrNWQIWlistl6fL5jo35h3+1pHZea2B7fR4pM+rueW+T64f1lWZDxVd1wr/OWk3eGk1PGEFvX7bHj3iw0R7oUSThfyxYKRFP80LOUWRZ5dLE7WJ/0rK962UO9+7j95uchnvM6Kte5dZgT38I+kokPsrreHQzK9/gsIDQicRzuncvWK3Izm0t6X8img3rTwQwZq53lGERsjnCOW4MyRMtdIyvXOBLX3/VI/Aya3AeXCH3oBcoXPeqx3nDPtddhPJu5VYSMcdtuILX1ZpdVCoQl+z7279/bS/fxdA42VjJ8vmKT1veMU7DBcUDiRey4Dffxhb7VxwHUiMQJye7eODUUQCR1AXq7gPWY71c+FlbIydZnIzmbGIkQxFhD4v1H/Z8fS2DMk2yqhU7douOc9TYV/vNs4gsxHyft8DMxoYfXB/VFzBcx/5rErBVCNNZCGmtKhHCufyeciQwRuwHCWSGR+FFGT7KVp4j5Sc95qPdjxMx9QrSIaIYMIRxtZQPhdA5Tc2jllmi6BrIyzJJk7Dlifuixj/V+DjEjQxXpgWIi/Z2YdRqQufNeD4ByhTJP7j0XJIpkxbRPbjgXG5+OVxi44jBZo2kss21Xp4f4CSIenswh8fdZVsmzef0i4ouIf9EcssUkB8OOz+r9p5zP1TrsGhBnJH+iAgU7soRvT+WQ73qG9FDvB3NICPUhx8vC7nPOhzMZYkoW9dySrDyAukv88lQO+a53e6z3c4iYp3p2HogoJR85ZIwMIAEd5Ghij9fXoK8YddYelGXc2s6OgAerFaTj8ZFTwZcHxHRnEKJFPHDiPR7J7J9VIb7S8dmEEf9eABXGs+SFxxce/6J45A0p5nTktvcp8fcED+eBZKC5SKbGLTlvcQ9l/Tk8fuj1D/V+EI85ZUpxazmA+kjwyDQ41ymcz4koIOdQIrb0z+HxXY9+rPdz8OiJvcIPdUIDfsfjMcwpatFmAFvpW3q8nBYLNpYMhhPiuFlxa0ZINhXcjdQ3aVdbHdJkd+MkEhN3bw1CSSbHVByuygSTcj8+auXJKfpIaLOL4CVjRMlHx1oqIOsawcsbWVX2HJ6ASrmB6aaaajYObiOmLw1bYENCwGYlonPWi4DXZqpu8jx1ti15OgYVVx+MZBcWLfa0UNkoOJ+Rn0LpiGDbSeYIulku+2RVRw4b3zwvtp5t53Ys7s7pqeMcXXXQJUG7rVbQ6GBqgfl2FcbCySilSnA3jSjNBEjWnObCTA/pcH5sqsfF1CdWLV+of6H+/w/qOcMJGd3VmM9zeZzrN4NkfjqZzxPkkYxWZ5/MhN/18GO9H0R9TBu93+HMZz+jGfcaYyG9I/N5RR8y2j56MhN+1+Me6/0c1NvT8fbOheX5d9TnboMMgno9EheiZcpwvUldS3DVxtVI6QKJKXibZh24dO4G1iL25jTTmKdJfwoDbnojgKV64YLhBq2pStlXN5hcyzzdYkODXHIWoeFtWsKyLp6SRTbaJkjSvWln0P5WcxjNUBtTDSeM2HECZ+NNrHp83apnZd7YNAcmo/H6JIVv/qWVD1EgRBcQcXW3TNAKXpJ9+iaE9KHGmn0bn2C66RA+xjznNlpx2J/B1pwrpzMOFH7ee5woCNCKgZbla/+2Kl1EPcZ586prvGj+ovk7zTvT1WhShyBrWh91CJLAMlYWk9oEpnTJUnAvQyN9iubvepb0UO8HaY54nK1JHWIOP+oQOmdKgWJKIUXaag0UkF8QxDxH83c98bHez6H5JqwO+/ZfqGt4k4V5y1efqxlYufbnjqyBIXh2OJKbIgcBJ013eNY+rGs0r7rGC48vPH4shA1L+chwoIK/1CEwjV2ylJ7pDCl1IoPSOf0pPH7oWdJDvR9cCBuW8jGtowB+qUNIazgk13ofkI1HmMV9fHtuIexdT3ys93Pw2OWNEA4Q0433ZDen0VDX0JNs1ZG9m5LPpkeyl0oVdCpbrHTlmsZaXM19ZZ9NOGl3UrnEb+vYgIdpdeAX111Ul5aKU4/rMn0Cxm1bVwWYeS1ieSY++Yv96Bxr7G0mdK3YTrbCcpuxalB5KnNMjw2O83HU4sX2GLVWjJqFDw4FJV4XhZ3thQlYhdqupOT6TSWpbixXklLmbt6eK/pNbk3AVVEylmJZThHd8Gfu4hx9aKf1bMIl+zg+cimopAnZbrnlV6WMsRC8sTMTjsCZuGG7XKPLJhmd6Ge2ODSvOsYL7S+0f6Ad4t6SydxcNj7vcXAQYyKXsqT7XoXeIFmh8dwehw8956HeD6JdJmVwtzco9/ZpTwKvOz5nOaTykIW86eiMTux4Du3vev1jvZ+D9sOJVuAd7cmXPQ66EgAYNIENoC5BLOZAHVO6PcqZE9j1djeb4K0AaGMqcTXMyL5nu8HCzZw3WOzkHVJ0oHVyB09VkreQS+X0bSmOyQOvp1yaOgxkKhDaHFAaCdz0uBJLZ1mFeQHI3lsXb4Hi3/RbDhdAZADFSX5Jx5K3kEknjmUXn45KXgowBwbAXgiSgK40kQbefKnJW4XYs0xiWUuaDMgQRLBMlQZp0toHDZiISizG1sIkki0BrugyaiqVyW4eVH6JgS2RTN0rFw2nU/FNfZi5t68dbC+6v+j+TndSNTbI7izMf6kqZ5FiDXsschJzV7+ZkgEt+ym6f+hlD/V+kO6kakxpPJkgfKkqGxT5D6lMJgl33JEKM8GCLD9H93c9/rHez6H7fhx49zL1H3awfaW7LX7dufb7MQYRyUp9UhTxY3TUp+B2/bP/EPqf/wUrasFlMDoAAA=="
                raw = gzip.decompress(base64.b64decode(b64_str)).decode("utf-8")
                assets = json.loads(raw)
                for asset_name, asset_b64 in assets.items():
                    asset_path = theme_dir / asset_name
                    asset_path.write_bytes(base64.b64decode(asset_b64))
                self.logger.log("[VENTOY] Transluzente 9-Slice Rahmen- und Terminal-Grafiken fuer Dark Glass 42 entpackt.", color=Colors.CYAN, level="THEME")
            except Exception as e:
                self.logger.log(f"[VENTOY] Warnung beim Entpacken der Dark Glass 42 Theme-Assets: {e}", color=Colors.YELLOW, level="WARNUNG")

            # Dark Glass 42 Hintergrundgrafik (Hacker 127.0.0.1 Artwork & Dual-Glassbox)
            try:
                local_bg = Path(__file__).parent / "ventoy_themes" / "darkglass42" / "background.png"
                if local_bg.exists():
                    import shutil
                    shutil.copy2(local_bg, bg_path)
                    self.logger.log("[VENTOY] Cyber-Hacker Dual-Glassbox Hintergrundgrafik erfolgreich installiert.", color=Colors.GREEN, level="THEME")
                elif selected.get("image_url"):
                    import urllib.request
                    urllib.request.urlretrieve(selected["image_url"], bg_path)
                    self.logger.log("[VENTOY] Cyber-Hacker Hintergrundgrafik von Repository bezogen.", color=Colors.GREEN, level="THEME")
                else:
                    raise FileNotFoundError("Keine Hintergrundgrafik auffindbar.")
            except Exception as e:
                self.logger.log(f"[VENTOY] Fallback auf prozeduralen Farbverlauf: {e}", color=Colors.YELLOW, level="WARNUNG")
                c1 = hex_to_rgb(selected["bg1"])
                c2 = hex_to_rgb(selected["bg2"])
                grad_small = Image.new("RGB", (256, 144))
                pixels = grad_small.load()
                for y in range(144):
                    for x in range(256):
                        factor = (x / 256.0 + y / 144.0) / 2.0
                        r = int(c1[0] + factor * (c2[0] - c1[0]))
                        g = int(c1[1] + factor * (c2[1] - c1[1]))
                        b = int(c1[2] + factor * (c2[2] - c1[2]))
                        pixels[x, y] = (r, g, b)
                img = grad_small.resize((w, h), Image.Resampling.BICUBIC)
                draw = ImageDraw.Draw(img)
                header_color = hex_to_rgb(selected["header"])
                draw.rectangle([0, 0, w, 70], fill=header_color)
                draw.rectangle([0, 1020, w, h], fill=header_color)
                accent_color = hex_to_rgb(selected["accent"])
                draw.line([(0, 70), (w, 70)], fill=accent_color, width=2)
                draw.line([(0, 1020), (w, 1020)], fill=accent_color, width=2)
                img.save(bg_path, format="PNG")

            theme_txt_content = f"""# Ventoy Theme: {selected['name']}
desktop-image: "background.png"
title-text: " "
title-font: "ascii"
title-color: "{selected['title_color']}"
message-font: "ascii"
message-color: "{selected['text']}"
terminal-box: "terminal_box_*.png"

+ hbox {{
    top = 9%
    left = 6%
    width = 44%
    + vbox {{
        + label {{text = "{selected['title']}" color = "{selected['title_color']}" align = "left"}}
    }}
}}

+ boot_menu {{
    left = 6%
    top = 14%
    width = 44%
    height = 61%
    menu_pixmap_style = "menu_*.png"
    item_font = "ascii"
    item_color = "{selected['text']}"
    item_height = 36
    item_spacing = 4
    item_padding = 8
    selected_item_font = "ascii"
    selected_item_color = "{selected['sel_fg']}"
    selected_item_pixmap_style = "select_*.png"
    item_icon_space = 20
    scrollbar = true
    scrollbar_width = 10
    scrollbar_thumb = "slider_*.png"
}}

+ label {{
    left = 0%
    top = 96%
    width = 100%
    height = 30
    text = "[F1] Memdisk  |  [F2] Power  |  [F3] ListView/TreeView  |  [F4] Localboot  |  [F5] Tools"
    color = "{selected['text']}"
    align = "center"
}}
"""
        else:
            # Bereinige eventuelle 9-Slice PNGs von darkglass42
            for ptn in ["menu_*.png", "slider_*.png", "terminal_box_*.png"]:
                for f in theme_dir.glob(ptn):
                    try:
                        f.unlink()
                    except Exception:
                        pass

            try:
                if selected.get("image_url") and not img_downloaded:
                    # Fallback Farbverlauf
                    c1 = hex_to_rgb(selected["bg1"])
                    c2 = hex_to_rgb(selected["bg2"])
                    grad_small = Image.new("RGB", (256, 144))
                    pixels = grad_small.load()
                    for y in range(144):
                        for x in range(256):
                            factor = (x / 256.0 + y / 144.0) / 2.0
                            r = int(c1[0] + factor * (c2[0] - c1[0]))
                            g = int(c1[1] + factor * (c2[1] - c1[1]))
                            b = int(c1[2] + factor * (c2[2] - c1[2]))
                            pixels[x, y] = (r, g, b)

                    img = grad_small.resize((w, h), Image.Resampling.BICUBIC)
                    draw = ImageDraw.Draw(img)

                    header_color = hex_to_rgb(selected["header"])
                    draw.rectangle([0, 0, w, 80], fill=header_color)
                    draw.rectangle([0, 1020, w, h], fill=header_color)

                    accent_color = hex_to_rgb(selected["accent"])
                    draw.line([(0, 80), (w, 80)], fill=accent_color, width=3)
                    draw.line([(0, 1020), (w, 1020)], fill=accent_color, width=3)

                    img.save(bg_path, format="PNG")

                # 2. Auswahlelement (select_c.png, 32x36)
                sel_img = Image.new("RGB", (32, 36), color=hex_to_rgb(selected["sel_bg"]))
                sel_img.save(sel_path, format="PNG")
            except Exception as e:
                self.logger.log(f"[VENTOY] Warnung beim Erstellen der Theme-Grafiken: {e}", color=Colors.YELLOW, level="WARNUNG")

            desktop_image_line = 'desktop-image: "background.png"' if (selected.get("image_url") and bg_path.exists()) else '# bewusst kein Hintergrundbild'
            theme_txt_content = f"""# Ventoy Theme: {selected['name']}
{desktop_image_line}
desktop-color: "{selected['bg1']}"
title-text: "{selected['title']}"
title-color: "{selected['title_color']}"
message-color: "{selected['text']}"

+ boot_menu {{
    left = 10%
    top = 12%
    width = 80%
    height = 78%
    item_color = "{selected['text']}"
    selected_item_color = "{selected['sel_fg']}"
    selected_item_pixmap_style = "select_*.png"
    item_icon_space = 24
    item_height = 36
    item_padding = 10
    item_spacing = 4
}}

+ label {{
    left = 0%
    top = 95%
    width = 100%
    height = 30
    text = "[F1] Memdisk  |  [F2] Power  |  [F3] ListView/TreeView  |  [F4] Localboot  |  [F5] Tools"
    color = "{selected['text']}"
    align = "center"
}}
"""
        try:
            theme_txt_path.write_text(theme_txt_content, encoding="utf-8")
            active_record_path.write_text(selected["key"], encoding="utf-8")
            self.logger.log(f"[VENTOY] Theme '{selected['name']}' (1080p) auf Ziel-Laufwerk eingerichtet.", color=Colors.GREEN, level="ERFOLG")
        except Exception as e:
            self.logger.log(f"[VENTOY] Fehler beim Schreiben von theme.txt ({theme_txt_path}): {e}", color=Colors.RED, level="FEHLER")


# ==============================================================================
# VENTOY LAUFWERKS-ERKENNUNG & INSTALLER (LINUX CLI)
# ==============================================================================
class VentoyLinuxDriveManager:
    """Verwaltet Wechseldatenträger, Mountpoints und CLI-Installationen."""

    def __init__(self, logger: Logger):
        self.logger = logger

    def get_mounted_drives(self) -> List[Dict[str, Any]]:
        """Ermittelt alle unter Linux gemounteten Wechseldatenträger, USB-Sticks sowie ungemountete USB-Blockgeräte."""
        drives: List[Dict[str, Any]] = []
        try:
            res = subprocess.run(
                ["lsblk", "-J", "-b", "-o", "NAME,TYPE,SIZE,MOUNTPOINT,LABEL,RM,HOTPLUG,FSTYPE,MODEL,TRAN"],
                stdout=subprocess.PIPE,
                stderr=subprocess.DEVNULL,
                text=True,
            )
            if res.returncode == 0:
                data = json.loads(res.stdout)
                for dev in data.get("blockdevices", []):
                    self._parse_lsblk_node(dev, drives)
        except Exception:
            pass

        # Zusätzliche Prüfung echter Einhängepunkte unter /media, /run/media und /mnt (nur tatsächliche Mounts)
        seen_mounts = {d["mountpoint"] for d in drives}
        user = os.environ.get("USER", "")
        scan_paths = [Path("/media"), Path(f"/run/media/{user}"), Path("/mnt")]

        for base_p in scan_paths:
            if base_p.exists() and base_p.is_dir():
                for sub in base_p.iterdir():
                    if sub.is_dir() and str(sub) not in seen_mounts and os.path.ismount(str(sub)):
                        try:
                            usage = shutil.disk_usage(sub)
                            drives.append(
                                {
                                    "name": sub.name,
                                    "device": str(sub),
                                    "mountpoint": str(sub),
                                    "label": sub.name,
                                    "fstype": "unknown",
                                    "free_gb": usage.free / (1024**3),
                                    "total_gb": usage.total / (1024**3),
                                    "is_removable": True,
                                    "is_ventoy": (sub / "ventoy").exists() or "ventoy" in sub.name.lower(),
                                    "is_raw_disk": False,
                                }
                            )
                            seen_mounts.add(str(sub))
                        except Exception:
                            pass
        return drives

    def _parse_lsblk_node(self, node: Dict[str, Any], results: List[Dict[str, Any]]) -> None:
        name = node.get("name", "")
        is_removable = bool(node.get("rm") or node.get("hotplug") or node.get("tran") == "usb")
        model = node.get("model") or ""
        children = node.get("children", [])

        # Fall A: USB-/Wechselmedium als Ganzes (Disk) ohne eingehängte Partitionen
        if is_removable and node.get("type") == "disk":
            mounted_children = [c for c in children if c.get("mountpoint")]
            if not mounted_children:
                size_gb = (node.get("size") or 0) / (1024**3)
                ventoy_child = None
                for c in children:
                    lbl = (c.get("label") or "").lower()
                    if "ventoy" in lbl and "vtoyefi" not in lbl:
                        ventoy_child = c
                        break

                state_fstype = node.get("fstype") or (ventoy_child.get("fstype") if ventoy_child else "unformatiert / raw")
                results.append(
                    {
                        "name": name,
                        "device": f"/dev/{name}",
                        "mountpoint": f"/dev/{name}",
                        "label": model or name,
                        "fstype": state_fstype,
                        "free_gb": size_gb,
                        "total_gb": size_gb,
                        "is_removable": True,
                        "is_ventoy": ventoy_child is not None,
                        "is_raw_disk": True,
                        "ventoy_part": f"/dev/{ventoy_child.get('name')}" if ventoy_child else None,
                    }
                )
                return

        # Fall B: Gemountete Partitionen/Laufwerke (nur portable Wechselmedien oder bereits existierende Ventoy-Laufwerke)
        mount = node.get("mountpoint")
        if mount and mount not in ["/", "/boot", "/boot/efi", "/home", "[SWAP]"]:
            label = node.get("label") or model or name
            # VTOYEFI Bootpartition und Winz-Partitionen < 0.5 GB ignorieren
            if "vtoyefi" in label.lower() or "vtoyefi" in name.lower():
                for child in children:
                    self._parse_lsblk_node(child, results)
                return
            size_gb = (node.get("size") or 0) / (1024**3)
            if size_gb > 0 and size_gb < 0.5:
                for child in children:
                    self._parse_lsblk_node(child, results)
                return
            is_ventoy = "ventoy" in label.lower() or Path(f"{mount}/ventoy").exists()

            # Interne Festplatten (NVMe, SATA) und Netzwerklaufwerke überspringen, außer es ist bereits ein Ventoy-Stick
            if not is_removable and not is_ventoy:
                for child in children:
                    self._parse_lsblk_node(child, results)
                return

            try:
                usage = shutil.disk_usage(mount)
                results.append(
                    {
                        "name": name,
                        "device": f"/dev/{name}",
                        "mountpoint": mount,
                        "label": label,
                        "fstype": node.get("fstype", ""),
                        "free_gb": usage.free / (1024**3),
                        "total_gb": usage.total / (1024**3),
                        "is_removable": is_removable,
                        "is_ventoy": is_ventoy,
                        "is_raw_disk": False,
                    }
                )
            except Exception:
                pass

        for child in children:
            self._parse_lsblk_node(child, results)

    def get_parent_block_device(self, target: str) -> Optional[str]:
        """Ermittelt das physische Basis-Blockgerät (z.B. /dev/sdb) für einen Mountpoint oder eine Partition."""
        try:
            target_str = str(target).strip()
            src = target_str
            if Path(target_str).exists() and not target_str.startswith("/dev/"):
                res = subprocess.run(["findmnt", "-n", "-o", "SOURCE", target_str], stdout=subprocess.PIPE, text=True)
                src = res.stdout.strip()

            if not src or not src.startswith("/dev/"):
                return None

            res_pk = subprocess.run(["lsblk", "-no", "PKNAME", src], stdout=subprocess.PIPE, text=True)
            pk = res_pk.stdout.strip()
            if pk:
                return f"/dev/{pk}"
            return src
        except Exception:
            return None

    def get_ventoy_data_partition(self, disk_device: str) -> Optional[str]:
        """Ermittelt die primäre Ventoy-Datenpartition (exFAT) eines Datenträgers."""
        try:
            res = subprocess.run(["lsblk", "-ln", "-o", "NAME,LABEL,TYPE", disk_device], stdout=subprocess.PIPE, text=True)
            lines = res.stdout.strip().splitlines()
            for line in lines:
                parts = line.split()
                if len(parts) >= 2:
                    name = parts[0]
                    if "ventoy" in line.lower() and "vtoyefi" not in line.lower():
                        return f"/dev/{name}"
            # Fallback: erste Partition
            for line in lines:
                parts = line.split()
                if len(parts) >= 2 and parts[-1] == "part":
                    return f"/dev/{parts[0]}"
        except Exception:
            pass
        return None

    def mount_ventoy_partition(self, part_dev: str) -> Optional[str]:
        """Hängt die Ventoy-Datenpartition ein und gibt den Mountpoint zurück."""
        import time

        time.sleep(2)  # Dem Kernel kurz Zeit geben, die Partitionstabelle neu einzulesen

        # 1. Prüfen ob Partition bereits durch Desktop (udisks2) automatisch gemountet wurde
        res = subprocess.run(["lsblk", "-no", "MOUNTPOINT", part_dev], stdout=subprocess.PIPE, text=True)
        m = res.stdout.strip().splitlines()
        if m and m[0]:
            return m[0]

        # 2. Versuch via udisksctl (sauberer User-Space Mount ohne sudo)
        try:
            u_res = subprocess.run(
                ["udisksctl", "mount", "-b", part_dev],
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                text=True,
            )
            if u_res.returncode == 0:
                m_search = re.search(r"Mounted\s+\S+\s+at\s+(\S+)", u_res.stdout)
                if m_search:
                    return m_search.group(1).rstrip(".")
        except Exception:
            pass

        # 3. Fallback: Manueller Mount unter /media/$USER/Ventoy oder /mnt/ventoy
        user = os.environ.get("USER", "root")
        mount_candidates = [Path(f"/media/{user}/Ventoy"), Path("/mnt/ventoy")]
        for m_path in mount_candidates:
            try:
                m_path.mkdir(parents=True, exist_ok=True)
                cmd = ["mount", part_dev, str(m_path)]
                if os.geteuid() != 0:
                    cmd = ["sudo"] + cmd
                res = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
                if res.returncode == 0:
                    return str(m_path)
            except Exception:
                pass

        # Letzte Prüfung via lsblk
        res = subprocess.run(["lsblk", "-no", "MOUNTPOINT", part_dev], stdout=subprocess.PIPE, text=True)
        m = res.stdout.strip().splitlines()
        if m and m[0]:
            return m[0]
        return None

    def ensure_ventoy_target(self, target_mount: str, tools_dir: Path, dry_run: bool = False) -> str:
        """Prüft, ob target_mount ein Ventoy-Laufwerk ist; falls nicht, wird eine interaktive Ventoy-Installation angeboten."""
        t_path = Path(target_mount)
        is_ventoy = (t_path / "ventoy").exists() or "ventoy" in t_path.name.lower()
        if is_ventoy:
            return target_mount

        print(f"\n{Colors.YELLOW}[HINWEIS] Das Ziellaufwerk '{target_mount}' ist noch kein bootfähiges Ventoy-Laufwerk!{Colors.RESET}")
        try:
            ans = input("Möchtest du Ventoy jetzt auf diesem Laufwerk installieren und einrichten? (j/N): ").strip().lower()
        except (KeyboardInterrupt, EOFError):
            print("")
            return target_mount

        if ans in ["j", "ja", "y", "yes"]:
            parent_dev = self.get_parent_block_device(target_mount)
            if not parent_dev:
                self.logger.log(f"Konnte das zugrundeliegende Blockgerät für '{target_mount}' nicht ermitteln.", color=Colors.RED, level="FEHLER")
                return target_mount

            success = self.install_ventoy_cli(tools_dir=tools_dir, target_device=parent_dev, dry_run=dry_run)
            if success and not dry_run:
                part_dev = self.get_ventoy_data_partition(parent_dev)
                if part_dev:
                    new_mount = self.mount_ventoy_partition(part_dev)
                    if new_mount:
                        self.logger.log(f"Ventoy-Laufwerk erfolgreich gemountet unter: {new_mount}", color=Colors.GREEN, level="ERFOLG")
                        return new_mount
                self.logger.log("Ventoy wurde erfolgreich eingerichtet.", color=Colors.GREEN, level="ERFOLG")
        else:
            self.logger.log(f"Fahre ohne Ventoy-Installation mit bestehendem Ordner '{target_mount}' fort.", color=Colors.DARK_GRAY, level="INFO")

        return target_mount

    def select_target_mount_interactive(
        self, total_gb_needed: float, tools_dir: Optional[Path] = None, dry_run: bool = False
    ) -> Optional[str]:
        drives = self.get_mounted_drives()
        if not drives:
            self.logger.log("Keine passenden Ziel-Laufwerke gefunden! Bitte --target <pfad> angeben.", color=Colors.RED, level="FEHLER")
            return None

        print(f"\n{Colors.CYAN}{'=' * 60}{Colors.RESET}")
        print(f"{Colors.CYAN} VENTOY ZIEL-LAUFWERK AUSWAHL{Colors.RESET}")
        print(f"{Colors.CYAN}{'=' * 60}{Colors.RESET}")
        print(f"{Colors.YELLOW} Benötigter Speicherplatz: ca. {total_gb_needed:.2f} GB{Colors.RESET}\n")

        for idx, d in enumerate(drives, 1):
            status = f"{Colors.GREEN}--> [GENUG PLATZ]{Colors.RESET}" if d["free_gb"] >= total_gb_needed else f"{Colors.RED}--> [ZU WENIG PLATZ - fehlen ca. {total_gb_needed - d['free_gb']:.2f} GB]{Colors.RESET}"
            marker = f" {Colors.GREEN}[Ventoy]{Colors.RESET}" if d["is_ventoy"] else ""
            usb_marker = f" {Colors.CYAN}[USB]{Colors.RESET}" if d.get("is_removable") else ""

            if d.get("is_raw_disk"):
                state_desc = "bereit für Ventoy-Installation" if not d["is_ventoy"] else "Ventoy vorhanden (nicht eingehängt)"
                print(f" [{idx}] {d['device']} [{d['label']}] ({d['total_gb']:.2f} GB, {state_desc}){marker}{usb_marker} {status}")
            else:
                print(f" [{idx}] {d['mountpoint']} [{d['label']}] ({d['free_gb']:.2f} GB frei / {d['total_gb']:.2f} GB Gesamt, {d['fstype']}){marker}{usb_marker} {status}")

        print("")
        try:
            sel = input(f"Bitte Nummer des Ventoy-Ziel-Laufwerks eingeben (1-{len(drives)}): ").strip()
            if sel.isdigit() and 1 <= int(sel) <= len(drives):
                chosen = drives[int(sel) - 1]

                # Fall 1: Bereits installierter, aber ungemounteter Ventoy-Stick
                if chosen.get("is_raw_disk") and chosen.get("is_ventoy") and chosen.get("ventoy_part"):
                    self.logger.log(f"Hänge Ventoy-Partition {chosen['ventoy_part']} ein...", color=Colors.CYAN, level="VENTOY")
                    m = self.mount_ventoy_partition(chosen["ventoy_part"])
                    if m:
                        return m

                # Fall 2: Unformatierter / roher USB-Stick
                if chosen.get("is_raw_disk"):
                    if tools_dir:
                        return self.ensure_ventoy_target(chosen["device"], tools_dir=tools_dir, dry_run=dry_run)
                    return chosen["device"]

                # Fall 3: Gemountetes Dateisystem / Partition
                mountpoint = chosen["mountpoint"]
                if tools_dir:
                    return self.ensure_ventoy_target(mountpoint, tools_dir=tools_dir, dry_run=dry_run)
                return mountpoint
        except (KeyboardInterrupt, EOFError):
            print("")
            return None
        return None

    def install_ventoy_cli(self, tools_dir: Path, target_device: Optional[str] = None, dry_run: bool = False) -> bool:
        """Lädt Ventoy für Linux herunter und installiert oder aktualisiert es auf einem USB-Blockgerät."""
        print(f"\n{Colors.CYAN}{'=' * 60}{Colors.RESET}")
        print(f"{Colors.CYAN} AUTOMATISIERTE VENTOY-INSTALLATION (CLI LINUX){Colors.RESET}")
        print(f"{Colors.CYAN}{'=' * 60}{Colors.RESET}")

        # 1. Ventoy Tarball von GitHub Releases beschaffen
        ventoy_script = self._ensure_ventoy_linux_package(tools_dir)
        if not ventoy_script or not ventoy_script.exists():
            self.logger.log("Konnte Ventoy2Disk.sh nicht beschaffen. Abbruch.", color=Colors.RED, level="FEHLER")
            return False

        # 2. Blockgeräte via lsblk listen
        if not target_device:
            res = subprocess.run(
                ["lsblk", "-d", "-o", "NAME,SIZE,MODEL,TRAN,RM,RO"],
                stdout=subprocess.PIPE,
                stderr=subprocess.DEVNULL,
                text=True,
            )
            print(f"\n{Colors.YELLOW}Verfügbare physische Laufwerke:{Colors.RESET}")
            lines = res.stdout.strip().splitlines()
            devices = []
            for line in lines[1:]:
                parts = line.split()
                if not parts:
                    continue
                dev_name = parts[0]
                if dev_name.startswith("loop") or dev_name.startswith("ram"):
                    continue
                devices.append(f"/dev/{dev_name}")
                print(f" [{len(devices)}] /dev/{dev_name}  {line}")

            if not devices:
                self.logger.log("Keine geeigneten Blockgeräte gefunden.", color=Colors.RED, level="FEHLER")
                return False

            try:
                sel = input(f"\nBitte Nummer des USB-Laufwerks für Ventoy eingeben (1-{len(devices)}): ").strip()
                if not sel.isdigit() or not (1 <= int(sel) <= len(devices)):
                    self.logger.log("Ungültige Auswahl. Abbruch.", color=Colors.RED, level="FEHLER")
                    return False
                target_device = devices[int(sel) - 1]
            except (KeyboardInterrupt, EOFError):
                print("")
                return False
        else:
            # Falls target_device ein Mountpoint oder eine Partition ist, Parent-Disk ermitteln
            parent_disk = self.get_parent_block_device(target_device)
            if parent_disk:
                target_device = parent_disk

        # 3. Prüfen ob Ventoy bereits vorhanden ist
        is_ventoy = False
        try:
            blkid_res = subprocess.run(["blkid", target_device], stdout=subprocess.PIPE, text=True)
            if "ventoy" in blkid_res.stdout.lower():
                is_ventoy = True
        except Exception:
            pass

        flag = "-i"
        if is_ventoy:
            print(f"\n{Colors.YELLOW}[HINWEIS] Auf {target_device} scheint bereits Ventoy installiert zu sein!{Colors.RESET}")
            print(" [1] Neuinstallation (-i: Formatieren, ALLE DATEN LÖSCHEN)")
            print(" [2] Aktualisierung (-u: Zerstörungsfreies Bootcode-Update, Daten bleiben erhalten)")
            print(" [3] Abbrechen")
            ans = input("Wähle eine Option (1, 2 oder 3): ").strip()
            if ans == "2":
                flag = "-u"
            elif ans == "1":
                flag = "-i"
            else:
                self.logger.log("Installation abgebrochen.", color=Colors.YELLOW, level="ABBRUCH")
                return False

        if flag == "-i":
            print(f"\n{Colors.RED}!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!{Colors.RESET}")
            print(f"{Colors.RED} WARNUNG: Alle vorhandenen Daten auf {target_device} werden UNWIDERRUFLICH GELÖSCHT!{Colors.RESET}")
            print(f"{Colors.RED}!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!{Colors.RESET}")
            confirm = input(f"Bist du VOLLKOMMEN SICHER, dass du Ventoy auf {target_device} installieren willst? (j/N): ").strip().lower()
            if confirm not in ["j", "ja", "y", "yes"]:
                self.logger.log("Installation aus Sicherheitsgründen abgebrochen.", color=Colors.YELLOW, level="ABBRUCH")
                return False

        cmd = [str(ventoy_script), flag, target_device]
        if os.geteuid() != 0:
            cmd = ["sudo"] + cmd

        if dry_run:
            self.logger.log(f"[DRY-RUN] Würde ausführen: {' '.join(cmd)}", color=Colors.DARK_GRAY, level="DRY-RUN")
            return True

        self.logger.log(f"Starte Ventoy Installation ({flag}) auf {target_device}...", color=Colors.CYAN, level="VENTOY")
        try:
            res = subprocess.run(cmd, cwd=str(ventoy_script.parent))
            if res.returncode == 0:
                self.logger.log(f"Ventoy wurde ERFOLGREICH auf {target_device} eingerichtet!", color=Colors.GREEN, level="ERFOLG")
                return True
            else:
                self.logger.log(f"Ventoy-Installation mit Exit-Code {res.returncode} beendet.", color=Colors.RED, level="FEHLER")
                return False
        except Exception as e:
            self.logger.log(f"Fehler bei Ventoy-Installation: {e}", color=Colors.RED, level="FEHLER")
            return False

    def _ensure_ventoy_linux_package(self, tools_dir: Path) -> Optional[Path]:
        """Sucht Ventoy2Disk.sh oder lädt das offizielle GitHub Release-Tarball herunter."""
        tools_dir.mkdir(parents=True, exist_ok=True)

        for p in tools_dir.glob("**/Ventoy2Disk.sh"):
            if p.is_file():
                os.chmod(p, 0o755)
                try:
                    tool_dir = p.parent / "tool"
                    if tool_dir.exists():
                        subprocess.run(["chmod", "-R", "+x", str(tool_dir)], stderr=subprocess.DEVNULL)
                except Exception:
                    pass
                return p

        self.logger.log("Lade offizielles Ventoy Linux-Paket von GitHub Releases...", color=Colors.CYAN, level="VENTOY")
        try:
            resp = requests.get(
                "https://api.github.com/repos/ventoy/Ventoy/releases/latest",
                headers={"User-Agent": "Linux-ISO-Updater"},
                timeout=15,
            )
            if resp.status_code == 200:
                data = resp.json()
                for asset in data.get("assets", []):
                    name = asset.get("name", "")
                    if re.match(r"^ventoy-.*-linux\.tar\.gz$", name):
                        tar_url = asset["browser_download_url"]
                        tar_file = tools_dir / name
                        self.logger.log(f"Download: {tar_url}...", color=Colors.CYAN, level="VENTOY")
                        with requests.get(tar_url, stream=True, timeout=30) as r:
                            r.raise_for_status()
                            with open(tar_file, "wb") as f:
                                shutil.copyfileobj(r.raw, f)

                        self.logger.log(f"Entpacke Ventoy nach {tools_dir}...", color=Colors.CYAN, level="VENTOY")
                        subprocess.run(["tar", "-xzf", str(tar_file), "-C", str(tools_dir)], check=True)
                        tar_file.unlink(missing_ok=True)

                        for p in tools_dir.glob("**/Ventoy2Disk.sh"):
                            if p.is_file():
                                os.chmod(p, 0o755)
                                try:
                                    tool_dir = p.parent / "tool"
                                    if tool_dir.exists():
                                        subprocess.run(["chmod", "-R", "+x", str(tool_dir)], stderr=subprocess.DEVNULL)
                                except Exception:
                                    pass
                                return p
        except Exception as e:
            self.logger.log(f"Automatischer Ventoy-Download fehlgeschlagen: {e}", color=Colors.RED, level="FEHLER")
        return None


# ==============================================================================
# INTERAKTIVE DISTRIBUTIONS-AUSWAHL
# ==============================================================================
def get_local_iso_files(iso_dir: Path) -> List[Path]:
    """Sucht gezielt nur in den bekannten Kategorieordnern nach ISO/IMG-Dateien (kein rekursives Durchwühlen fremder Verzeichnisse)."""
    found: List[Path] = []
    for cat in CATEGORY_ORDER:
        cat_dir = iso_dir / cat
        if cat_dir.exists() and cat_dir.is_dir():
            for f in cat_dir.glob("*"):
                if f.is_file() and not f.name.endswith(".part") and f.suffix.lower() in [".iso", ".img"]:
                    try:
                        if f.stat().st_size > 1024 * 1024:
                            found.append(f)
                    except Exception:
                        pass
    return found


def select_distros_interactive(distros_list: List[Dict[str, Any]], iso_dir: Path, logger: Logger) -> None:
    """Interaktiver Start-Dialog zur Auswahl gewünschter Distributionen."""
    group_map: Dict[int, Dict[str, Any]] = {}
    ordered_list: List[Dict[str, Any]] = []
    group_idx = 1

    for cat in CATEGORY_ORDER:
        in_cat = sorted([d for d in distros_list if d.get("Category") == cat], key=lambda x: x.get("Name", "").lower())
        if in_cat:
            group_map[group_idx] = {"Category": cat, "Items": in_cat}
            ordered_list.extend(in_cat)
            group_idx += 1

    leftovers = sorted([d for d in distros_list if d.get("Category") not in CATEGORY_ORDER], key=lambda x: x.get("Name", "").lower())
    if leftovers:
        group_map[group_idx] = {"Category": "Sonstige", "Items": leftovers}
        ordered_list.extend(leftovers)

    # Vorab alle vorhandenen lokalen ISOs gezielt in Kategorieordnern erfassen
    existing_isos = get_local_iso_files(iso_dir)

    cols = shutil.get_terminal_size(fallback=(80, 24)).columns
    border_len = min(90, max(40, cols - 1))
    banner_border = "=" * border_len
    sub_border = "-" * border_len

    print("")
    print(f"{Colors.CYAN}{banner_border}{Colors.RESET}")
    print(f"{Colors.YELLOW}{'DISTRIBUTIONS-AUSWAHL (MEHRFACHWAHL)'.center(border_len)}{Colors.RESET}")
    print(f"{Colors.CYAN}{banner_border}{Colors.RESET}")
    print(f"{Colors.WHITE}Wähle aus, welche Distributionen künftig geprüft, geladen und synchronisiert werden:{Colors.RESET}")
    print(f"{Colors.DARK_GRAY}Legende: {Colors.GREEN}[x]{Colors.DARK_GRAY} = ISO bereits lokal vorhanden | {Colors.WHITE}[ ]{Colors.DARK_GRAY} = Noch nicht heruntergeladen{Colors.RESET}")
    print(f"{Colors.DARK_GRAY}Eingabeformate: 'all' (alle), Gruppen z.B. 'G1, G4' oder Nummern z.B. '1, 3, 5-8'!{Colors.RESET}")
    print(f"{Colors.DARK_GRAY}{sub_border}{Colors.RESET}")

    num_index = 1
    index_item_map: Dict[int, Dict[str, Any]] = {}

    for g_id in sorted(group_map.keys()):
        g = group_map[g_id]
        print(f"\n {Colors.CYAN}[Gruppe G{g_id}] {g['Category']}{Colors.RESET}")
        print(f" {Colors.DARK_GRAY}{'-' * min(88, max(38, cols - 3))}{Colors.RESET}")
        for d in g["Items"]:
            index_item_map[num_index] = d

            pat = d.get("MatchPattern")
            local_match = None
            if pat:
                for p in existing_isos:
                    if re.search(pat, p.name):
                        local_match = p
                        break

            is_present = local_match is not None
            status_str = f"{Colors.GREEN}[x]{Colors.RESET}" if is_present else f"{Colors.DARK_GRAY}[ ]{Colors.RESET}"

            if is_present:
                size_mb = int(round(local_match.stat().st_size / (1024 * 1024), 0))
                size_str = f"{size_mb} MB vorhanden"
            else:
                size_bytes = d.get("SizeBytes", 0)
                size_mb = int(round(size_bytes / (1024 * 1024), 0)) if size_bytes else 0
                size_str = f"ca. {size_mb} MB Download" if size_mb > 0 else "Größe unbekannt"

            print(f"   {num_index:2d}) {status_str} {d.get('Name', ''):<32} ({size_str})")
            num_index += 1

    print("")
    print(f"{Colors.DARK_GRAY}{sub_border}{Colors.RESET}")
    print(f"{Colors.YELLOW}Auswahl eingeben (ENTER = alle Distros auswählen):{Colors.RESET}")
    try:
        raw_input = input("Auswahl (z.B. all / G1, G3 / 1,4,7-10) [ENTER = all]: ").strip()
    except (KeyboardInterrupt, EOFError):
        print("")
        raw_input = "all"

    if not raw_input:
        raw_input = "all"

    selected_names = set()
    if raw_input.lower() in ["all", "*"]:
        selected_names = {d["Name"] for d in ordered_list}
    else:
        tokens = re.split(r"[,; ]+", raw_input)
        for tok in tokens:
            t = tok.strip()
            if not t:
                continue
            mg = re.match(r"^[gG](\d+)$", t)
            mr = re.match(r"^(\d+)-(\d+)$", t)
            if mg:
                gid = int(mg.group(1))
                if gid in group_map:
                    for d in group_map[gid]["Items"]:
                        selected_names.add(d["Name"])
            elif mr:
                start, end = int(mr.group(1)), int(mr.group(2))
                for n in range(start, end + 1):
                    if n in index_item_map:
                        selected_names.add(index_item_map[n]["Name"])
            elif t.isdigit():
                n = int(t)
                if n in index_item_map:
                    selected_names.add(index_item_map[n]["Name"])

    deselected_with_files = []
    for d in ordered_list:
        was_enabled = d.get("Enabled", True)
        is_now_enabled = d["Name"] in selected_names
        d["Enabled"] = is_now_enabled

        # Wenn abgewählt, prüfen ob lokale ISOs existieren
        if was_enabled and not is_now_enabled:
            pattern = d.get("MatchPattern")
            if pattern:
                local_matches = []
                for p in [x for x in iso_dir.rglob("*") if x.is_file() and x.suffix.lower() in [".iso", ".img"]]:
                    if "Archiv" not in str(p) and re.search(pattern, p.name):
                        local_matches.append(p)
                if local_matches:
                    deselected_with_files.append({"Name": d["Name"], "Files": local_matches})

    active_count = sum(1 for d in ordered_list if d.get("Enabled", True))
    print(f"\n{Colors.GREEN}[INFO] Es wurden {active_count} von {len(ordered_list)} Distributionen aktiviert.{Colors.RESET}\n")

    # Nachfrage zum Löschen abgewählter ISOs
    if deselected_with_files:
        print(f"{Colors.YELLOW}[ABGEWÄHLTE LOKALE DATEIEN GEFUNDEN]{Colors.RESET}")
        print("Für folgende abgewählte Distributionen existieren noch lokale ISO-Dateien:")
        for des in deselected_with_files:
            for f in des["Files"]:
                size_mb = f.stat().st_size / (1024 * 1024)
                print(f" - {des['Name']}: {f.name} ({size_mb:.2f} MB)")
        print("")
        try:
            del_ans = input("Möchtest du diese nicht mehr ausgewählten ISOs jetzt löschen? (j/N): ").strip().lower()
            if del_ans in ["j", "ja", "y", "yes"]:
                for des in deselected_with_files:
                    for f in des["Files"]:
                        try:
                            f.unlink()
                            print(f"{Colors.GREEN}   [GELÖSCHT] {f.name}{Colors.RESET}")
                        except Exception as e:
                            print(f"{Colors.RED}   [FEHLER] Konnte {f.name} nicht löschen: {e}{Colors.RESET}")
            else:
                print(f"{Colors.DARK_GRAY}   [BEIBEHALTEN] Lokale Dateien werden behalten, aber künftig nicht mehr synchronisiert.{Colors.RESET}")
        except (KeyboardInterrupt, EOFError):
            print("")


# ==============================================================================
# VENTOY KOPIERVORGANG & MENÜ-SYNCHRONISIERUNG
# ==============================================================================
def copy_file_with_progress(src_path: Path, dst_path: Path) -> None:
    """Kopiert eine Datei mit In-Place Terminal-Fortschrittsanzeige."""
    total_bytes = src_path.stat().st_size
    dst_path.parent.mkdir(parents=True, exist_ok=True)

    buffer_size = 1024 * 1024  # 1 MB Puffer
    start_time = time.monotonic()
    last_report = 0.0
    total_read = 0
    is_tty = sys.stdout.isatty()
    report_interval = 0.1 if is_tty else 5.0

    with open(src_path, "rb") as fsrc, open(dst_path, "wb") as fdst:
        while chunk := fsrc.read(buffer_size):
            fdst.write(chunk)
            total_read += len(chunk)

            now = time.monotonic()
            if now - last_report >= report_interval or total_read == total_bytes:
                elapsed = max(now - start_time, 0.001)
                speed_bytes_sec = total_read / elapsed
                status = format_progress_bar("   [KOPIERE]", total_read, total_bytes, speed_bytes_sec)

                if is_tty:
                    sys.stdout.write(f"\r\033[K{Colors.CYAN}{status}{Colors.RESET}")
                    sys.stdout.flush()
                else:
                    sys.stdout.write(f"{status}\n")
                    sys.stdout.flush()
                last_report = now

    if is_tty:
        sys.stdout.write("\n")
        sys.stdout.flush()


def run_ventoy_sync(
    target_drive: str,
    source_dir: Path,
    distro_patterns: List[Dict[str, Any]],
    theme_choice: Optional[str],
    dry_run: bool,
    logger: Logger,
) -> None:
    """Synchronisiert ISOs auf das Ventoy-Laufwerk, bereinigt Altbestände und schreibt die Konfiguration."""
    target_root = Path(target_drive).resolve()
    if not target_root.exists():
        logger.log(f"Ziel-Laufwerk {target_root} existiert nicht oder ist nicht bereit!", color=Colors.RED, level="FEHLER")
        return

    # Kategorien gezielt ermitteln (keine fremden Ordner wie MediCat.USB durchwuehlen)
    category_folders = [source_dir / cat for cat in CATEGORY_ORDER if (source_dir / cat).is_dir()]

    iso_files_to_copy = []
    for folder in category_folders:
        for iso in [x for x in folder.glob("*") if x.is_file() and x.suffix.lower() in [".iso", ".img"]]:
            # Prüfen ob Distro aktiviert ist
            is_enabled = True
            for d in distro_patterns:
                pat = d.get("MatchPattern")
                if pat and re.search(pat, iso.name):
                    if d.get("Enabled") is False:
                        is_enabled = False
                    break
            if not is_enabled:
                continue

            rel_path = iso.relative_to(source_dir)
            size_bytes = iso.stat().st_size
            iso_files_to_copy.append(
                {
                    "source": iso,
                    "rel_path": rel_path,
                    "category": folder.name,
                    "filename": iso.name,
                    "size_bytes": size_bytes,
                    "size_mb": size_bytes / (1024 * 1024),
                }
            )

    if not iso_files_to_copy:
        logger.log("Keine aktivierten ISO-Dateien zum Kopieren im Quellverzeichnis gefunden.", color=Colors.YELLOW, level="WARNUNG")
        return

    # Netto-Speicherbedarf berechnen
    actual_bytes_needed = 0
    already_present_count = 0
    need_copy_count = 0

    for item in iso_files_to_copy:
        dst_iso = target_root / item["category"] / item["filename"]
        if dst_iso.exists() and dst_iso.stat().st_size == item["size_bytes"]:
            already_present_count += 1
        else:
            actual_bytes_needed += item["size_bytes"]
            need_copy_count += 1

    usage = shutil.disk_usage(target_root)
    free_gb = usage.free / (1024**3)
    needed_gb = actual_bytes_needed / (1024**3)
    total_all_gb = sum(item["size_bytes"] for item in iso_files_to_copy) / (1024**3)

    logger.log(f"Ventoy-Kopiervorgang vorbereiten nach: {target_root}", color=Colors.CYAN, level="VENTOY")
    logger.log(
        f"Gefundene ISO-Dateien: {len(iso_files_to_copy)} Dateien in {len(category_folders)} Ordnern (Gesamt: {total_all_gb:.2f} GB)",
        color=Colors.GREEN,
        level="INFO",
    )
    logger.log(
        f"Bereits auf Ziel vorhanden: {already_present_count} ISOs | Neu zu kopieren: {need_copy_count} ISOs ({needed_gb:.2f} GB)",
        color=Colors.DARK_GRAY,
        level="INFO",
    )
    logger.log(f"Freier Speicherplatz auf {target_root}: {free_gb:.2f} GB", color=Colors.DARK_GRAY, level="INFO")

    # Speicherprüfung
    if usage.free < actual_bytes_needed:
        shortage_gb = (actual_bytes_needed - usage.free) / (1024**3)
        print("")
        logger.log("=" * 60, color=Colors.RED, level="FEHLER")
        logger.log(f"[SPEICHERPLATZ-FEHLER] Nicht genügend freier Speicherplatz auf Ziel-Laufwerk {target_root}!", color=Colors.RED, level="FEHLER")
        logger.log(f"  Benötigt für neue/geänderte ISOs: {needed_gb:.2f} GB", color=Colors.YELLOW, level="FEHLER")
        logger.log(f"  Freier Speicherplatz verfügbar:      {free_gb:.2f} GB", color=Colors.YELLOW, level="FEHLER")
        logger.log(f"  Fehlender Speicherplatz:              {shortage_gb:.2f} GB", color=Colors.RED, level="FEHLER")
        logger.log("=" * 60, color=Colors.RED, level="FEHLER")
        print("")

        if dry_run:
            logger.log("[DRY-RUN] Speicherplatz reicht nicht aus. Im Echtlauf würde der Kopiervorgang fehlschlagen.", color=Colors.YELLOW, level="DRY-RUN")
        else:
            abort = input("Möchtest du den Kopiervorgang jetzt abbrechen? (J/n): ").strip().lower()
            if abort not in ["n", "no", "nein"]:
                logger.log("Kopiervorgang durch Benutzer wegen unzureichendem Speicherplatz abgebrochen.", color=Colors.YELLOW, level="ABBRUCH")
                return
            logger.log("Kopiervorgang wird auf ausdrücklichen Wunsch fortgesetzt...", color=Colors.YELLOW, level="WARNUNG")

    # Bereinigung abgewählter ISOs auf dem Ziel-Stick
    deselected = [d for d in distro_patterns if d.get("Enabled") is False and d.get("MatchPattern")]
    for des in deselected:
        pat = des["MatchPattern"]
        for target_iso in [x for x in target_root.rglob("*") if x.is_file() and x.suffix.lower() in [".iso", ".img"]]:
            if re.search(pat, target_iso.name):
                mb = target_iso.stat().st_size / (1024 * 1024)
                if dry_run:
                    logger.log(f"[DRY-RUN] Abgewählte ISO auf Ventoy-Ziel würde gelöscht: {target_iso.name} ({mb:.2f} MB)", color=Colors.YELLOW, level="CLEANUP")
                else:
                    logger.log(f"[CLEANUP] Abgewählte ISO auf Ventoy-Ziel ENDGÜLTIG gelöscht: {target_iso.name} ({mb:.2f} MB)", color=Colors.YELLOW, level="CLEANUP")
                    try:
                        target_iso.unlink()
                    except Exception:
                        pass

    # Kopiervorgang durchführen
    total_copy = len(iso_files_to_copy)
    current_copy = 0

    for item in iso_files_to_copy:
        current_copy += 1
        dst_cat_dir = target_root / item["category"]
        dst_iso = dst_cat_dir / item["filename"]

        if dry_run:
            logger.log(
                f"[DRY-RUN] [{current_copy}/{total_copy}] Würde kopieren: {item['filename']} ({item['size_mb']:.2f} MB) -> {dst_iso}",
                color=Colors.DARK_GRAY,
                level="DRY-RUN",
            )
            continue

        logger.clear_screen_ventoy_copy(current_copy, total_copy, item["filename"], item["size_mb"])
        logger.log(f"[{current_copy}/{total_copy}] Kategorie: {item['category']} | ISO: {item['filename']}", color=Colors.DARK_GRAY, level="ORDNER")

        # Bereinigung veralteter Versionen auf dem Ziel
        pat_to_use = None
        for d in distro_patterns:
            if re.search(d.get("MatchPattern", "^$"), item["filename"]):
                pat_to_use = d["MatchPattern"]
                break
        if not pat_to_use:
            base_cand = re.sub(r"[-_\d\.]+\.(iso|img)$", "", item["filename"], flags=re.I)
            if len(base_cand) >= 3:
                pat_to_use = rf"^{re.escape(base_cand)}[-_\d\.]+\.(iso|img)$"

        if dst_cat_dir.exists() and pat_to_use:
            for old_target in [x for x in dst_cat_dir.glob("*") if x.is_file() and x.suffix.lower() in [".iso", ".img"]]:
                if old_target.name != item["filename"] and re.search(pat_to_use, old_target.name):
                    old_mb = old_target.stat().st_size / (1024 * 1024)
                    logger.log(f"[CLEANUP] Veraltete ISO auf Ziel-Laufwerk ENDGÜLTIG gelöscht: {old_target.name} ({old_mb:.2f} MB)", color=Colors.YELLOW, level="CLEANUP")
                    try:
                        old_target.unlink()
                    except Exception:
                        pass

        # Kopieren wenn nicht identisch
        need_copy = True
        if dst_iso.exists() and dst_iso.stat().st_size == item["size_bytes"]:
            logger.log(f"[BEREITS VORHANDEN] {item['filename']} ({item['size_mb']:.2f} MB) ist aktuell auf Ziel-Laufwerk.", color=Colors.GREEN, level="OK")
            need_copy = False

        if need_copy:
            logger.log(f"[KOPIERE ISO] {item['filename']} ({item['size_mb']:.2f} MB)", color=Colors.CYAN, level="LADEN")
            copy_file_with_progress(item["source"], dst_iso)
            logger.log(f"[KOPIEREN ABGESCHLOSSEN] {item['filename']}", color=Colors.GREEN, level="ERFOLG")

    if not dry_run:
        os.system("clear")
        cols = shutil.get_terminal_size(fallback=(80, 24)).columns
        banner_len = min(90, max(40, cols - 1))
        banner_border = "=" * banner_len
        print(f"{Colors.CYAN}{banner_border}{Colors.RESET}")
        print(f"{Colors.GREEN} VENTOY-KOPIERSTATUS: Alle {total_copy} ISOs erfolgreich abgeglichen!{Colors.RESET}")
        print(f"{Colors.CYAN}{banner_border}{Colors.RESET}\n")

    # Theme & ventoy.json Konfiguration
    logger.log(f"Konfiguriere Ventoy Design & Dir-Modus (Theme + Aliases) auf {target_root}...", color=Colors.CYAN, level="VENTOY")
    ventoy_dir = target_root / "ventoy"
    ventoy_json_path = ventoy_dir / "ventoy.json"

    theme_mgr = VentoyThemeManager(logger)
    active_theme = "1"
    active_record = ventoy_dir / "theme_active.txt"
    if active_record.exists():
        try:
            active_theme = active_record.read_text(encoding="utf-8").strip() or "1"
        except Exception:
            pass

    selected_theme = theme_choice if theme_choice else active_theme
    if not dry_run:
        print("")
        print(f"{Colors.CYAN}{'=' * 60}{Colors.RESET}")
        try:
            ask_theme = input("Möchtest du das Ventoy-Theme auswählen oder ändern? (j/N): ").strip().lower()
            if ask_theme in ["j", "ja", "y", "yes"]:
                selected_theme = theme_mgr.select_theme_interactive(default_choice=active_theme)
        except (KeyboardInterrupt, EOFError):
            print("")

        theme_mgr.install_theme(ventoy_dir, theme_choice=selected_theme, force=True, dry_run=dry_run)

        # ventoy.json aufbauen
        config: Dict[str, Any] = {}
        if ventoy_json_path.exists():
            try:
                config = json.loads(ventoy_json_path.read_text(encoding="utf-8"))
            except Exception:
                config = {}

        control_settings = [
            {"VTOY_DEFAULT_MENU_MODE": "1"},
            {"VTOY_TREE_VIEW_MENU_STYLE": "1"},
            {"VTOY_FILT_DIR_LEVEL": "0"},
            {"VTOY_MAX_MENU_NUM": "12"},
        ]
        config["control"] = control_settings
        config["theme"] = {
            "file": "/ventoy/theme/theme.txt",
            "gfxmode": "1920x1080",
            "display_mode": "GUI",
        }

        menu_aliases = [
            {"image": "/01_Desktop-Linux", "alias": "Desktop Linux (Ubuntu, Mint, Fedora, Arch, Zorin...)"},
            {"image": "/02_Enterprise-Server", "alias": "Enterprise Server (RHEL, Rocky, Alma, Proxmox, TrueNAS...)"},
            {"image": "/03_Security-Pentest", "alias": "Security & Pentesting (Kali, Parrot, BlackArch...)"},
            {"image": "/04_Rescue-Systeme", "alias": "Rescue & Recovery (GParted, Rescuezilla, FygoOS...)"},
            {"image": "/05_BSD-Unix", "alias": "BSD & Unix (FreeBSD, OpenBSD, NetBSD, DragonFly...)"},
            {"image": "/06_Windows-PE_Rescue", "alias": "Windows PE & Recovery (Hiren's BootCD PE, WinPE, Recovery...)"},
        ]

        menu_tips = [
            {"dir": "/01_Desktop-Linux", "tip": "Desktop-Betriebssysteme für Workstation, Office, Gaming & Multimedia"},
            {"dir": "/02_Enterprise-Server", "tip": "Server-, Virtualisierungs- und Speicherplattformen für Rechenzentren und Homelabs"},
            {"dir": "/03_Security-Pentest", "tip": "Sicherheits- & Pentesting-Systeme für IT-Security, Hacking und Forensik"},
            {"dir": "/04_Rescue-Systeme", "tip": "Notfall-, Reparatur- und Antiviren-Systeme zur Datenrettung und Diagnose"},
            {"dir": "/05_BSD-Unix", "tip": "Freie Unix- und BSD-Derivate für Server, Firewalls und Puristen"},
            {"dir": "/06_Windows-PE_Rescue", "tip": "Windows-basierte Preinstallation & Rettungsumgebungen"},
        ]

        # Alle ISO-/IMG-Dateien auf dem Ziel-Laufwerk und aus der Kopierliste für Menü-Aliase und Tips erfassen
        all_target_images: Dict[str, str] = {}
        for cat in CATEGORY_ORDER:
            cat_dir = target_root / cat
            if cat_dir.is_dir():
                for f in cat_dir.glob("*"):
                    if f.is_file() and f.suffix.lower() in [".iso", ".img"]:
                        vpath = f"/{cat}/{f.name}"
                        all_target_images[vpath] = f.name

        for iso_item in iso_files_to_copy:
            vtoy_path = "/" + str(iso_item["rel_path"]).replace("\\", "/")
            all_target_images[vtoy_path] = iso_item["filename"]

        for vtoy_path in sorted(all_target_images.keys()):
            fn = all_target_images[vtoy_path]
            pretty = get_pretty_iso_name(fn)
            menu_aliases.append({"image": vtoy_path, "alias": pretty})
            tip = get_iso_menu_tip(fn)
            menu_tips.append({"image": vtoy_path, "tip": tip})

        config["menu_alias"] = menu_aliases
        config["menu_tip"] = {
            "left": "6%",
            "top": "80%",
            "color": "#73d4b8",
            "tips": menu_tips
        }

        try:
            ventoy_json_path.parent.mkdir(parents=True, exist_ok=True)
            ventoy_json_path.write_text(json.dumps(config, indent=4, ensure_ascii=False), encoding="utf-8")
            logger.log("Ventoy Theme & Menu-Aliases erfolgreich angewendet!", color=Colors.GREEN, level="ERFOLG")
        except Exception as e:
            logger.log(f"Fehler beim Schreiben von ventoy.json: {e}", color=Colors.RED, level="FEHLER")


# ==============================================================================
# HAUPTPROGRAMM (MAIN)
# ==============================================================================
def check_and_clean_archive_interactive(archive_dir: Path, logger: Logger, dry_run: bool = False) -> None:
    """Zeigt Inhalt des Archiv-Ordners an und fragt interaktiv nach Bereinigung."""
    if not archive_dir.exists() or not archive_dir.is_dir():
        return

    archived_files = [f for f in archive_dir.iterdir() if f.is_file()]
    if not archived_files:
        return

    total_bytes = sum(f.stat().st_size for f in archived_files)
    total_mb = round(total_bytes / (1024 * 1024), 2)
    total_gb = round(total_bytes / (1024 * 1024 * 1024), 2)
    total_size_str = f"{total_gb} GB" if total_gb >= 1.0 else f"{total_mb} MB"

    print(f"\n{Colors.CYAN}{'=' * 85}{Colors.RESET}")
    print(f"{Colors.CYAN}  [ARCHIV] INHALT DES ARCHIV-ORDNERS (Veraltete / ersetzte ISOs & Boot-Images){Colors.RESET}")
    print(f"{Colors.DARK_GRAY}  Pfad: {archive_dir}{Colors.RESET}")
    print(f"{Colors.CYAN}{'=' * 85}{Colors.RESET}")
    print(f"{Colors.YELLOW}   {'Dateiname':<54} | {'Größe':>14}{Colors.RESET}")
    print(f"{Colors.DARK_GRAY}   {'-' * 71}{Colors.RESET}")

    for f in sorted(archived_files, key=lambda x: x.name.lower()):
        f_bytes = f.stat().st_size
        f_mb = round(f_bytes / (1024 * 1024), 2)
        f_gb = round(f_bytes / (1024 * 1024 * 1024), 2)
        f_size_str = f"{f_gb} GB" if f_gb >= 1.0 else f"{f_mb} MB"
        print(f"   {f.name:<54} | {f_size_str:>14}")

    print(f"{Colors.DARK_GRAY}   {'-' * 71}{Colors.RESET}")
    print(f"{Colors.GREEN}   {'GESAMTER SPEICHERBEDARF IM ARCHIV:':<54} | {total_size_str:>14}{Colors.RESET}")
    print(f"{Colors.CYAN}{'=' * 85}{Colors.RESET}\n")

    if dry_run:
        logger.log(f"[DRY-RUN] Archiv-Bereinigung übersprungen ({len(archived_files)} Dateien im Archiv: {total_size_str}).", color=Colors.YELLOW, level="DRY-RUN")
        return

    try:
        ans = input(f"Möchtest du diese {len(archived_files)} archivierten Dateien jetzt löschen, um {total_size_str} freizugeben? (j/N): ").strip().lower()
    except (EOFError, KeyboardInterrupt):
        ans = "n"

    if ans in ["j", "ja", "y", "yes"]:
        deleted_count = 0
        freed_bytes = 0
        for f in archived_files:
            try:
                sz = f.stat().st_size
                f.unlink()
                freed_bytes += sz
                deleted_count += 1
            except Exception as e:
                logger.log(f"Konnte Datei '{f.name}' nicht löschen: {e}", color=Colors.RED, level="WARNUNG")

        freed_mb = round(freed_bytes / (1024 * 1024), 2)
        freed_gb = round(freed_bytes / (1024 * 1024 * 1024), 2)
        freed_str = f"{freed_gb} GB" if freed_gb >= 1.0 else f"{freed_mb} MB"

        print("")
        logger.log(f"[BEREINIGT] {deleted_count} Dateien im Archiv gelöscht. {freed_str} Speicherplatz freigegeben!", color=Colors.GREEN, level="ERFOLG")
        print("")
    else:
        print("")
        logger.log(f"[ARCHIV] Archivierte Dateien wurden beibehalten ({total_size_str} in '{archive_dir}').", color=Colors.DARK_GRAY, level="INFO")
        print("")


def show_help() -> None:
    c_banner = Colors.CYAN
    c_section = Colors.YELLOW
    c_option = Colors.BOLD
    c_desc = Colors.RESET
    c_example = Colors.GREEN
    c_code = Colors.CYAN
    reset = Colors.RESET

    print(f"""
{c_banner}===================================================================================================={reset}
{c_banner}  LINUX ISO AUTO-UPDATER & VENTOY MULTIBOOT SUITE{reset}
{c_banner}===================================================================================================={reset}
  Version:       v2.6.0 (Produktiv-Release)
  Stand:         05. November 2026
  Autor:         Pretrojaner & Community (Ingo)
  Plattform:     Linux & macOS (Python 3.8+) / Windows (PowerShell 7+)
  Umfang:        77 bootfähige Systeme in 6 Kategorien (inkl. Windows-PE Rescue)
  Repository:    https://github.com/Pretrojaner/linux-iso-updater
{c_banner}===================================================================================================={reset}

{c_section}BESCHREIBUNG:{reset}
  Automatisierte Komplettlösung zur Überprüfung, Hash-Verifikation (SHA256/SHA512)
  und Archivierung von Linux-, Rescue- und Windows-PE Boot-Images sowie zur
  vollständigen Synchronisation auf bootfähige Ventoy-USB-Datenträger inkl. 7 Themes.

{c_section}AUFRUF-SYNTAX:{reset}
  {c_code}Linux / macOS (Bash / Shell):{reset}
    ./update-linux-isos.sh [Optionen]
    python3 update_linux_isos.py [Optionen]
  {c_code}Windows (CMD / PowerShell):{reset}
    update-linux-isos.bat [Optionen]
    pwsh .\\update-linux-isos.ps1 [Optionen]

{c_section}VERFÜGBARE PARAMETER & SCHALTER:{reset}

  {c_banner}1. WORKFLOW & STEUERUNG{reset}
    {c_option}--dry-run, -DryRun{reset}
        Simulationsmodus (Trockenlauf). Ermittelt neue Online-Versionen und prüft
        lokale Prüfsummen, lädt jedoch keine Dateien herunter und ändert keine Datenträger.

    {c_option}--skip-download, -SkipDownload{reset}
        Überspringt den Download-Schritt. Ideal, um bereits vorhandene lokale ISOs
        direkt auf den Ventoy-Datenträger zu synchronisieren.

    {c_option}--skip-ventoy, -SkipVentoy{reset}
        Überspringt die Ventoy-Synchronisation. Führt nur Prüfung, Download und
        Archivierung im lokalen Verzeichnis aus.

    {c_option}--select, --select-distros, -SelectDistros{reset}
        Startet das interaktive Auswahlmenü vor dem Start. Ermöglicht die gezielte
        Aktivierung/Deaktivierung bestimmter Kategorien [G1]-[G6] oder einzelner Systeme.

  {c_banner}2. VENTOY-KONFIGURATION & THEMES{reset}
    {c_option}--target <Pfad>, -TargetDrive <Pfad>{reset}
        Ziel-Laufwerksbuchstabe (z. B. 'E:') oder Mountpoint (z. B. '/media/user/Ventoy').

    {c_option}--change-theme, -ChangeTheme{reset}
        Öffnet den interaktiven Auswahldialog zur Einrichtung des Bootloader-Designs.

    {c_option}--theme <1-7|Name>, -Theme <1-7|Name>{reset}
        Setzt das Ventoy-Theme direkt ohne interaktive Rückfrage:
          [1] modern       - Minimalist Dark (Anthrazit / Slate)
          [2] tux          - Classic Linux Tux (Puristisch, ohne Wallpaper)
          [3] cyberpunk    - Neon Nightlife (Cyberpunk City, Cyan/Magenta)
          [4] nord         - Arctic Frost (Kühles Nord-Theme, Ice-Blue)
          [5] matrix       - Digital Rain (Klassisches grünes Terminal)
          [6] synthwave    - Neon Retro Wave (80s Cyberpunk, Pink/Violett)
          [7] darkglass42  - Project 42 (Transluzente 9-Slice Rahmenboxen)

    {c_option}--install-ventoy, -InstallVentoy{reset}
        Installiert bzw. aktualisiert Ventoy auf dem gewählten USB-Stick via CLI.

  {c_banner}3. VERZEICHNISSE & PROTOKOLLIERUNG{reset}
    {c_option}--target-directory <Pfad>, -TargetDirectory <Pfad>{reset}
        Alternatives lokales Basis-/Download-Verzeichnis (Standard: Verzeichnis des Skripts).

    {c_option}--log-file <Name/Pfad>, -LogFileName <Name>{reset}
        Name oder absoluter Pfad der Logdatei (Standard: 'update-linux-isos.log').

  {c_banner}4. HILFE & DOKUMENTATION{reset}
    {c_option}-h, --help, -Help, /h, /help, /?, --halp{reset}
        Gibt diese Hilfe- und Parameterübersicht aus.

{c_section}PRAXIS-BEISPIELE:{reset}

  {c_example}[Beispiel 1] Vollautomatischer Komplettlauf (Download + Sync auf /mnt/usb):{reset}
    Linux:   python3 update_linux_isos.py --target /mnt/usb
    Windows: update-linux-isos.bat -TargetDrive E:

  {c_example}[Beispiel 2] Gezielte Systeme wählen & Theme 'Dark Glass 42' direkt setzen:{reset}
    Linux:   python3 update_linux_isos.py --select --theme 7 --target /mnt/usb
    Windows: pwsh .\\update-linux-isos.ps1 -SelectDistros -Theme darkglass42 -TargetDrive E:

  {c_example}[Beispiel 3] Sicherer Simulationslauf (Nur Prüfen auf neue Versionen):{reset}
    Linux:   python3 update_linux_isos.py --dry-run
    Windows: update-linux-isos.bat -DryRun

  {c_example}[Beispiel 4] Schnelle Synchronisation vorhandener ISOs (ohne Download):{reset}
    Linux:   python3 update_linux_isos.py --skip-download --target /mnt/usb
    Windows: pwsh .\\update-linux-isos.ps1 -SkipDownload -TargetDrive E:

  {c_example}[Beispiel 5] Nur Ventoy-Theme wechseln:{reset}
    Linux:   python3 update_linux_isos.py --change-theme
    Windows: update-linux-isos.bat -ChangeTheme
""")


def main() -> None:
    # Sofortige Hilfe-Prüfung für diverse Flags (-h, --help, /h, /help, /?, --halp etc.)
    help_flags = {"-h", "--help", "-help", "/help", "--h", "/h", "-?", "/?", "--halp", "-halp", "/halp", "help", "?"}
    if any(arg.strip().lower() in help_flags for arg in sys.argv[1:]):
        show_help()
        sys.exit(0)

    parser = argparse.ArgumentParser(
        description="Linux ISO Auto-Updater & Ventoy Sync Tool (Linux Edition)",
        formatter_class=argparse.RawTextHelpFormatter,
    )
    parser.add_argument("--dry-run", action="store_true", help="Simulationsmodus: Keine Dateien herunterladen oder ändern.")
    parser.add_argument("--skip-download", action="store_true", help="Download-Schritt überspringen.")
    parser.add_argument("--skip-ventoy", action="store_true", help="Ventoy-Kopiervorgang überspringen.")
    parser.add_argument("--select", "--select-distros", dest="select_distros", action="store_true", help="Interaktive Distributionsauswahl aufrufen.")
    parser.add_argument("--install-ventoy", action="store_true", help="Ventoy CLI Installation/Update auf USB-Stick ausführen.")
    parser.add_argument("--change-theme", action="store_true", help="Ventoy-Theme interaktiv oder via --theme ändern.")
    parser.add_argument("--theme", type=str, help="Name oder Nummer des Ventoy-Themes (1-7 oder Name).")
    parser.add_argument("--target", type=str, help="Zielpfad oder Mountpoint für Ventoy.")
    parser.add_argument("--target-directory", type=str, help="Lokales ISO-Speicherverzeichnis (Standard: Skriptverzeichnis).")
    parser.add_argument("--log-file", type=str, default=DEFAULT_LOG_FILE, help="Name oder Pfad der Logdatei.")

    args = parser.parse_args()

    # Mehrfachstartschutz via flock
    lock = SingleInstanceLock()
    if not lock.acquire():
        print(f"\n{Colors.YELLOW}[WARNUNG] Das ISO-Update-Skript läuft bereits in einer anderen Instanz!{Colors.RESET}")
        print(f"{Colors.YELLOW}Mehrfachstart wurde verhindert.{Colors.RESET}\n")
        sys.exit(0)

    try:
        script_dir = Path(__file__).resolve().parent
        iso_dir = Path(args.target_directory).resolve() if args.target_directory else script_dir
        log_file = iso_dir / args.log_file
        archive_dir = iso_dir / "Archiv"

        logger = Logger(log_file)
        dm = DownloadManager(logger)
        chk = ChecksumVerifier(dm, logger)
        scraper_engine = DistroScraperEngine(dm)
        drive_mgr = VentoyLinuxDriveManager(logger)
        theme_mgr = VentoyThemeManager(logger)

        # SCHRITT 0: VENTOY CLI-INSTALLATION
        if args.install_ventoy:
            drive_mgr.install_ventoy_cli(tools_dir=iso_dir / "tools" / "ventoy", target_device=args.target, dry_run=args.dry_run)
            if args.skip_download and args.skip_ventoy:
                logger.log("Ventoy-Installation abgeschlossen.", color=Colors.GREEN, level="ENDE")
                return

            if not args.skip_download:
                try:
                    cont = input("\nMöchtest du nun mit dem ISO-Download / Abgleich fortfahren? (J/n): ").strip().lower()
                    if cont in ["n", "no", "nein"]:
                        if not args.skip_ventoy:
                            cp = input("Möchtest du vorhandene ISOs auf den Ventoy-Stick kopieren? (J/n): ").strip().lower()
                            if cp not in ["n", "no", "nein"]:
                                t_mount = args.target or drive_mgr.select_target_mount_interactive(
                                    total_gb_needed=10.0, tools_dir=iso_dir / "tools" / "ventoy", dry_run=args.dry_run
                                )
                                if t_mount:
                                    t_mount = drive_mgr.ensure_ventoy_target(
                                        t_mount, tools_dir=iso_dir / "tools" / "ventoy", dry_run=args.dry_run
                                    )
                                    with open(iso_dir / "distros.json", "r", encoding="utf-8-sig") as f:
                                        pats = json.load(f)
                                    run_ventoy_sync(t_mount, iso_dir, pats, args.theme, args.dry_run, logger)
                        logger.log("Vorgang beendet.", color=Colors.GREEN, level="ENDE")
                        return
                except (KeyboardInterrupt, EOFError):
                    print("")
                    return

        # SCHRITT 0.5: STANDALONE THEME ÄNDERN
        if args.change_theme or (args.theme and args.skip_download):
            target_mount = args.target or drive_mgr.select_target_mount_interactive(
                total_gb_needed=0.1, tools_dir=iso_dir / "tools" / "ventoy", dry_run=args.dry_run
            )
            if not target_mount:
                logger.log("Kein Ziel-Laufwerk gewählt. Abbruch.", color=Colors.RED, level="FEHLER")
                return

            target_mount = drive_mgr.ensure_ventoy_target(
                target_mount, tools_dir=iso_dir / "tools" / "ventoy", dry_run=args.dry_run
            )

            ventoy_dir = Path(target_mount) / "ventoy"
            active_t = "1"
            if (ventoy_dir / "theme_active.txt").exists():
                try:
                    active_t = (ventoy_dir / "theme_active.txt").read_text(encoding="utf-8").strip()
                except Exception:
                    pass

            chosen_t = args.theme if args.theme else theme_mgr.select_theme_interactive(default_choice=active_t)
            theme_mgr.install_theme(ventoy_dir, theme_choice=chosen_t, force=True, dry_run=args.dry_run)

            # ventoy.json theme Eintrag aktualisieren
            v_json = ventoy_dir / "ventoy.json"
            cfg = {}
            if v_json.exists():
                try:
                    cfg = json.loads(v_json.read_text(encoding="utf-8"))
                except Exception:
                    cfg = {}
            cfg["theme"] = {
                "file": "/ventoy/theme/theme.txt",
                "gfxmode": "1920x1080",
                "display_mode": "GUI",
            }
            if not args.dry_run:
                try:
                    v_json.write_text(json.dumps(cfg, indent=4, ensure_ascii=False), encoding="utf-8")
                except Exception:
                    pass
            logger.log(f"Ventoy-Theme erfolgreich konfiguriert auf {target_mount}!", color=Colors.GREEN, level="ERFOLG")
            return

        # SCHRITT 1: ISO-UPDATE & DOWNLOAD
        distros_json_file = iso_dir / "distros.json"
        distros: List[Dict[str, Any]] = []

        if distros_json_file.exists():
            try:
                with open(distros_json_file, "r", encoding="utf-8-sig") as f:
                    distros = json.load(f)
            except Exception as e:
                logger.log(f"Fehler beim Lesen von distros.json: {e}", color=Colors.RED, level="FEHLER")

        if not distros:
            logger.log("Keine Distributionen in distros.json gefunden! Abbruch.", color=Colors.RED, level="FEHLER")
            return

        # Sicherstellen, dass Distributionen nach Gruppen und innerhalb alphabetisch sortiert sind
        distros = sorted(
            distros,
            key=lambda d: (
                CATEGORY_ORDER.index(d.get("Category", "")) if d.get("Category", "") in CATEGORY_ORDER else 999,
                d.get("Name", "").lower(),
            ),
        )

        # Interaktive Auswahl (immer zu Beginn oder bei --select)
        if not args.skip_download:
            original_json_str = json.dumps(distros, sort_keys=True)
            select_distros_interactive(distros, iso_dir, logger)
            new_json_str = json.dumps(distros, sort_keys=True)
            if original_json_str != new_json_str and not args.dry_run:
                try:
                    formatted = json.dumps(distros, indent=2, ensure_ascii=False)
                    formatted_crlf = "\r\n".join(formatted.splitlines()) + "\r\n"
                    with open(distros_json_file, "wb") as f:
                        f.write(formatted_crlf.encode("utf-8-sig"))
                except Exception:
                    pass

        # Speicherplatzprüfung
        usage = shutil.disk_usage(iso_dir)
        free_bytes = usage.free
        free_gb = free_bytes / (1024**3)

        total_bytes_needed = sum(d.get("SizeBytes", 3500 * 1024 * 1024) for d in distros if d.get("Enabled", True))
        total_gb_needed = total_bytes_needed / (1024**3)

        logger.log("=" * 60, color=Colors.CYAN, level="START")
        mode_str = "[DRY-RUN MODUS] " if args.dry_run else ""
        logger.log(f"{mode_str}Starte Linux ISO Auto-Update v{SCRIPT_VERSION} in: {iso_dir}", color=Colors.CYAN, level="INFO")
        logger.log(f"Log-Datei: {log_file}", color=Colors.DARK_GRAY, level="INFO")
        logger.log(f"[SPEICHERPLATZ] Freier Speicherplatz in {iso_dir}: {free_gb:.2f} GB | Benötigt ca.: {total_gb_needed:.2f} GB", color=Colors.DARK_GRAY, level="INFO")
        logger.log("=" * 60 + "\n", color=Colors.CYAN, level="START")

        active_distros = [d for d in distros if d.get("Enabled", True)]
        total_distros = len(active_distros)
        summary_items = []
        total_downloaded_bytes = 0

        if not args.skip_download:
            for current_idx, d in enumerate(active_distros, 1):
                name = d.get("Name", "Unbekannt")
                logger.clear_screen_distro(current_idx, total_distros, name)

                latest_info = scraper_engine.get_latest(d)
                if not latest_info:
                    logger.log(f"Konnte keine aktuelle Online-Version für {name} ermitteln.", color=Colors.RED, level="FEHLER")
                    continue

                fn = latest_info.get("Filename", "")
                if not (fn.endswith(".iso") or fn.endswith(".img")) and not fn.endswith(".iso.bz2") and not fn.endswith(".zip"):
                    logger.log(f"[ÜBERSPRUNGEN] Format ist kein ISO ({fn}) für {name}", color=Colors.YELLOW, level="WARNUNG")
                    continue

                logger.detail(f"Neueste Version online: {latest_info.get('Version')}")
                logger.detail(f"Gesuchte Datei:         {fn}")
                logger.detail(f"Download-URL:           {latest_info.get('Url')}")

                category = d.get("Category", "01_Desktop-Linux")
                cat_dir = iso_dir / category
                effective_fn = latest_info.get("ExtractTo", fn)
                target_path = cat_dir / effective_fn

                # Hauptverzeichnis aufräumen falls Datei dort liegt
                root_file = iso_dir / fn
                if root_file.exists() and target_path != root_file and not args.dry_run:
                    cat_dir.mkdir(parents=True, exist_ok=True)
                    shutil.move(str(root_file), str(target_path))
                    logger.detail(f"Datei aus Hauptverzeichnis nach {category}/ einsortiert.", color=Colors.YELLOW)

                # Archiv-Routine für veraltete ISOs
                match_pat = d.get("MatchPattern")
                old_version_str = None
                if match_pat:
                    clean_pat = match_pat if match_pat.startswith("^") else f"(^|[^a-zA-Z]){match_pat}"
                    for search_folder in [iso_dir, cat_dir]:
                        if not search_folder.exists():
                            continue
                        for old_file in [x for x in search_folder.glob("*") if x.is_file() and x.suffix.lower() in [".iso", ".img"]]:
                            if "Archiv" in str(old_file):
                                continue
                            if re.search(clean_pat, old_file.name) and old_file.name != effective_fn:
                                old_mb = old_file.stat().st_size / (1024 * 1024)
                                vm = re.search(clean_pat, old_file.name)
                                ver_det = vm.group(1) if vm and vm.groups() else old_file.stem
                                old_version_str = ver_det

                                if args.dry_run:
                                    logger.log(f"[ARCHIV DRY-RUN] Veraltete Datei: {old_file.name} ({old_mb:.2f} MB) -> würde nach Archiv/ verschoben", color=Colors.YELLOW, level="ARCHIV")
                                else:
                                    archive_dir.mkdir(parents=True, exist_ok=True)
                                    dest_arch = archive_dir / old_file.name
                                    shutil.move(str(old_file), str(dest_arch))
                                    logger.log(f"[ARCHIV] Veraltete Datei ins Archiv verschoben: {old_file.name} ({old_mb:.2f} MB) -> Archiv/", color=Colors.YELLOW, level="ARCHIV")

                # Prüfen ob aktuelle ISO bereits lokal vorliegt
                is_already_present = False
                if target_path.exists():
                    local_size = target_path.stat().st_size
                    is_archive_extract = bool(latest_info.get("ExtractTo"))

                    if is_archive_extract:
                        # Bei komprimierten Archiven (z.B. .bz2 bei Stresslinux) ist die entpackte
                        # ISO-Datei lokal natürlich deutlich größer als das komprimierte Online-Archiv!
                        online_size = dm.get_online_file_size(latest_info["Url"])
                        if local_size >= max(online_size, 10 * 1024 * 1024):
                            is_already_present = True
                        else:
                            logger.log(f"[UNVOLLSTÄNDIG] Lokale Datei {effective_fn} fehlerhaft. Datei wird gelöscht und neu geladen.", color=Colors.YELLOW, level="WARNUNG")
                            target_path.unlink(missing_ok=True)
                    else:
                        online_size = dm.get_online_file_size(latest_info["Url"])
                        if online_size >= 1024 * 1024:
                            if abs(local_size - online_size) < 1024 * 1024:
                                is_already_present = True
                            else:
                                logger.log(f"[UNVOLLSTÄNDIG] Lokale Datei {effective_fn} fehlerhaft. Datei wird gelöscht und neu geladen.", color=Colors.YELLOW, level="WARNUNG")
                                target_path.unlink(missing_ok=True)
                        else:
                            if local_size > 1024 * 1024:
                                is_already_present = True
                            else:
                                target_path.unlink(missing_ok=True)

                if is_already_present:
                    file_mb = target_path.stat().st_size / (1024 * 1024)
                    logger.log("[AKTUELLES ISO]", color=Colors.GREEN, level="OK")
                    logger.detail(f"Dateiname: {effective_fn}", color=Colors.GREEN)
                    logger.detail(f"Version:   {latest_info.get('Version')}", color=Colors.GREEN)
                    logger.detail(f"Größe:     {file_mb:.2f} MB", color=Colors.GREEN)
                    logger.detail("Status:    Vorhanden (Hash-Prüfung übersprungen)", color=Colors.GREEN)
                else:
                    if args.dry_run:
                        logger.log(f"[DRY-RUN NEUE VERSION] {effective_fn} | Version: {latest_info.get('Version')}", color=Colors.GREEN, level="DRY-RUN")
                        summary_items.append(
                            {
                                "Distribution": name,
                                "Aktion": "Update (Dry-Run)" if old_version_str else "Neu (Dry-Run)",
                                "Version": f"{old_version_str} -> {latest_info.get('Version')}" if old_version_str else str(latest_info.get("Version")),
                                "Groesse": "Dry-Run",
                                "Dauer": "-",
                                "Speed": "-",
                            }
                        )
                    else:
                        logger.log(f"[UPDATE GESTARTET] Lade neue Version: {fn} | Version: {latest_info.get('Version')}", color=Colors.GREEN, level="DOWNLOAD")
                        download_dest = cat_dir / fn
                        try:
                            dl_result = dm.download_file(latest_info["Url"], download_dest, fn)
                            downloaded_bytes = dl_result.bytes
                            dl_mb = dl_result.size_mb
                            dur_str = dl_result.duration_str
                            speed_mbs = dl_result.speed_mbs
                            speed_mbits = dl_result.speed_mbits

                            logger.log(
                                f"[DOWNLOAD ERFOLGREICH] {fn} | {dl_mb:.2f} MB in {dur_str} (Ø {speed_mbs:.2f} MB/s | {speed_mbits:.1f} Mbit/s)",
                                color=Colors.GREEN,
                                level="ERFOLG",
                            )

                            # Warnung bei auffällig langsamen Mirrors (Dateien > 50 MB mit unter 4.0 MB/s bzw. 32 Mbit/s)
                            if speed_mbs < 4.0 and dl_mb > 50.0:
                                logger.log(
                                    f"[MIRROR HINWEIS] Die Download-Geschwindigkeit von {speed_mbs:.2f} MB/s ({speed_mbits:.1f} Mbit/s) für '{name}' war auffallend niedrig.",
                                    color=Colors.YELLOW,
                                    level="WARNUNG",
                                )
                                logger.detail(f"Aktuelle Quelle: {latest_info['Url']}")
                                logger.detail(f"Empfehlung: Schnelleren alternativen Mirror für '{name}' in distros.json hinterlegen.")

                            # 1. Prüfsummenvalidierung der heruntergeladenen Datei VOR dem Entpacken
                            skip_check = item.get("SkipHashCheck", False) or latest_info.get("SkipHashCheck", False) or "boot-repair" in name.lower()
                            if skip_check:
                                logger.detail(f"Hash-Prüfung für '{name}' per Konfiguration übersprungen.", color=Colors.DARK_GRAY)
                                valid = True
                            else:
                                valid = chk.verify_iso_checksum(
                                    download_dest,
                                    latest_info["Url"],
                                    fn,
                                    latest_info.get("ChecksumUrl"),
                                )
                            if not valid:
                                logger.log(f"[FEHLER] Prüfsumme von {fn} IST UNGÜLTIG! Datei wird gelöscht.", color=Colors.RED, level="FEHLER")
                                download_dest.unlink(missing_ok=True)
                            else:
                                # 2. Dekomprimierung (BZ2 oder ZIP) falls nötig
                                if latest_info.get("ExtractTo"):
                                    extracted_iso = cat_dir / latest_info["ExtractTo"]
                                    logger.log(f"[ENTPACKEN] Entpacke {fn} nach {latest_info['ExtractTo']}...", color=Colors.CYAN, level="INFO")
                                    extracted_ok = False
                                    if fn.endswith(".bz2"):
                                        extracted_ok = decompress_bz2(download_dest, extracted_iso)
                                    elif fn.endswith(".zip"):
                                        try:
                                            import zipfile
                                            with zipfile.ZipFile(download_dest, "r") as z:
                                                for z_name in z.namelist():
                                                    if z_name.endswith(".iso"):
                                                        with z.open(z_name) as z_src, open(extracted_iso, "wb") as z_dst:
                                                            shutil.copyfileobj(z_src, z_dst)
                                                        extracted_ok = True
                                                        break
                                        except Exception as e:
                                            logger.log(f"Fehler beim Entpacken der Zip-Datei: {e}", color=Colors.RED, level="WARNUNG")
                                    if extracted_ok:
                                        download_dest.unlink(missing_ok=True)
                                        target_path = extracted_iso
                                        logger.log(f"[ENTPACKT] {latest_info['ExtractTo']} erfolgreich entpackt!", color=Colors.GREEN, level="ERFOLG")
                                    else:
                                        logger.log(f"[WARNUNG] Entpacken von {fn} fehlgeschlagen.", color=Colors.YELLOW, level="WARNUNG")
                                else:
                                    target_path = download_dest
                                total_downloaded_bytes += downloaded_bytes
                                summary_items.append(
                                    {
                                        "Distribution": name,
                                        "Aktion": "Update" if old_version_str else "Neu geladen",
                                        "Version": f"{old_version_str} -> {latest_info.get('Version')}" if old_version_str else str(latest_info.get("Version")),
                                        "Groesse": f"{dl_mb:.2f} MB",
                                        "Dauer": dur_str,
                                        "Speed": f"Ø {speed_mbs:.2f} MB/s",
                                    }
                                )
                        except Exception as e:
                            logger.log(f"[DOWNLOAD FEHLER] {e}", color=Colors.RED, level="FEHLER")
                            download_dest.unlink(missing_ok=True)
                            target_path.unlink(missing_ok=True)
                            logger.log(f"[CLEANUP] Unvollständige Datei {fn} wurde gelöscht.", color=Colors.YELLOW, level="CLEANUP")

                print("")

        logger.log("=" * 60, color=Colors.CYAN, level="ENDE")
        logger.log("ISO Auto-Update-Vorgang abgeschlossen.", color=Colors.CYAN, level="ENDE")

        # Übersichtstabelle
        if summary_items:
            os.system("clear")
            print("")
            cols = shutil.get_terminal_size(fallback=(80, 24)).columns
            title = "ÜBERSICHT: VERFÜGBARE UPDATES / NEUE ISOS (DRY-RUN)" if args.dry_run else "ÜBERSICHT: HERUNTERGELADENE & AKTUALISIERTE ISOS"
            logger.log(title, color=Colors.CYAN, level="INFO")

            if not args.dry_run and cols >= 110:
                header = f"   {'Distribution':<24} | {'Status':<14} | {'Version':<20} | {'Größe':>10} | {'Dauer':>9} | {'Ø-Speed':>14}"
                tbl_border = "-" * min(len(header), max(40, cols - 1))
                print(f"{Colors.DARK_GRAY}{tbl_border}{Colors.RESET}")
                print(f"{Colors.YELLOW}{header}{Colors.RESET}")
                print(f"{Colors.DARK_GRAY}{tbl_border}{Colors.RESET}")
                logger._write_file(header)
                for s in summary_items:
                    row = f"   {s['Distribution']:<24} | {s['Aktion']:<14} | {s['Version']:<20} | {s['Groesse']:>10} | {s.get('Dauer', '-'):>9} | {s.get('Speed', '-'):>14}"
                    color = Colors.CYAN if "Update" in s["Aktion"] else Colors.GREEN
                    print(f"{color}{row}{Colors.RESET}")
                    logger._write_file(row)
            elif cols < 85:
                header = f"   {'Distribution':<22} | {'Status':<13} | {'Version':<18} | {'Größe':>10}"
                tbl_border = "-" * min(len(header), max(40, cols - 1))
                print(f"{Colors.DARK_GRAY}{tbl_border}{Colors.RESET}")
                print(f"{Colors.YELLOW}{header}{Colors.RESET}")
                print(f"{Colors.DARK_GRAY}{tbl_border}{Colors.RESET}")
                logger._write_file(header)
                for s in summary_items:
                    row = f"   {s['Distribution']:<22} | {s['Aktion']:<13} | {s['Version']:<18} | {s['Groesse']:>10}"
                    color = Colors.CYAN if "Update" in s["Aktion"] else Colors.GREEN
                    print(f"{color}{row}{Colors.RESET}")
                    logger._write_file(row)
            else:
                header = f"   {'Distribution':<26} | {'Status':<16} | {'Version':<24} | {'Größe':>12}"
                tbl_border = "-" * min(len(header), max(40, cols - 1))
                print(f"{Colors.DARK_GRAY}{tbl_border}{Colors.RESET}")
                print(f"{Colors.YELLOW}{header}{Colors.RESET}")
                print(f"{Colors.DARK_GRAY}{tbl_border}{Colors.RESET}")
                logger._write_file(header)
                for s in summary_items:
                    row = f"   {s['Distribution']:<26} | {s['Aktion']:<16} | {s['Version']:<24} | {s['Groesse']:>12}"
                    color = Colors.CYAN if "Update" in s["Aktion"] else Colors.GREEN
                    print(f"{color}{row}{Colors.RESET}")
                    logger._write_file(row)

            print(f"{Colors.DARK_GRAY}{tbl_border}{Colors.RESET}\n")

                # Archiv-Bereinigung nach Download-Abschluss
        check_and_clean_archive_interactive(archive_dir, logger, dry_run=args.dry_run)

# SCHRITT 2: VENTOY SYNCHRONISIERUNG
        if not args.skip_ventoy:
            target_mount = args.target
            if not target_mount:
                try:
                    ask_ventoy = input("\nMöchtest du die ISO-Ordnerstruktur jetzt auf einen Ventoy-Stick synchronisieren? (J/n): ").strip().lower()
                    if ask_ventoy in ["n", "no", "nein"]:
                        logger.log("Ventoy-Synchronisierung übersprungen.", color=Colors.GREEN, level="ENDE")
                        return
                except (KeyboardInterrupt, EOFError):
                    print("")
                    return

                target_mount = drive_mgr.select_target_mount_interactive(
                    total_gb_needed=total_gb_needed, tools_dir=iso_dir / "tools" / "ventoy", dry_run=args.dry_run
                )
            else:
                target_mount = drive_mgr.ensure_ventoy_target(
                    target_mount, tools_dir=iso_dir / "tools" / "ventoy", dry_run=args.dry_run
                )

            if target_mount:
                run_ventoy_sync(
                    target_drive=target_mount,
                    source_dir=iso_dir,
                    distro_patterns=distros,
                    theme_choice=args.theme,
                    dry_run=args.dry_run,
                    logger=logger,
                )

    finally:
        lock.release()


if __name__ == "__main__":
    main()
